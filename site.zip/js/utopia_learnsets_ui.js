'use strict';

/**
 * UTOPIA_LEARNSET_UI_V2_FIXED
 *
 * Connects the new Q button to the existing learnset popup.
 *
 * The original utopia_learnsets.js remains untouched.
 */

(function () {

  var BUTTON_ID = 'show-learnsets-toggle';
  var POPUP_CLASS = 'utopia-learnset-overlay';

  function getButton() {
    return document.getElementById(BUTTON_ID);
  }

  function getPopup() {
    return document.querySelector(
      '.' + POPUP_CLASS
    );
  }

  function isPopupOpen() {
    return !!getPopup();
  }

  // Update the button depending on popup visibility.

  function updateButtonText() {
    var button = getButton();

    if (!button) return;

    var opened = isPopupOpen();

    button.textContent = opened
      ? 'Q: Hide Level Up'
      : 'Q: Show Level Up';

    button.setAttribute(
      'aria-expanded',
      opened ? 'true' : 'false'
    );
  }

  // Use the already existing Q shortcut.
  // This keeps the original popup and its closing
  // behavior completely unchanged.

  function toggleExistingPopup() {
    var event = new KeyboardEvent(
      'keydown',
      {
        key: 'q',
        code: 'KeyQ',
        keyCode: 81,
        which: 81,
        bubbles: true,
        cancelable: true
      }
    );

    document.dispatchEvent(event);
  }

  function initialize() {
    var button = getButton();

    if (!button) {
      console.warn(
        'Utopia Learnset UI: Q button not found.'
      );
      return;
    }

    // Avoid registering duplicate click handlers.

    if (
      button.getAttribute(
        'data-utopia-learnset-ui-ready'
      ) === '1'
    ) {
      updateButtonText();
      return;
    }

    button.setAttribute(
      'data-utopia-learnset-ui-ready',
      '1'
    );

    button.setAttribute(
      'aria-controls',
      'utopia-learnset-popup'
    );

    button.setAttribute(
      'aria-expanded',
      'false'
    );

    button.addEventListener(
      'click',
      function (event) {
        event.preventDefault();

        toggleExistingPopup();

        updateButtonText();
      }
    );

    // Watch popup insertion and removal.
    // This also handles Q, Escape, X and outside clicks.

    var observer = new MutationObserver(
      function () {
        updateButtonText();
      }
    );

    observer.observe(
      document.body,
      {
        childList: true,
        subtree: false
      }
    );

    // Also synchronize after keyboard usage.

    document.addEventListener(
      'keyup',
      function (event) {
        if (
          event.key === 'q' ||
          event.key === 'Q' ||
          event.key === 'Escape'
        ) {
          updateButtonText();
        }
      }
    );

    updateButtonText();
  }

  if (document.readyState === 'loading') {
    document.addEventListener(
      'DOMContentLoaded',
      initialize
    );
  } else {
    initialize();
  }

})();


/* UTOPIA_LEARNSET_UI_V3 */

(function () {
  'use strict';

  function positionFooterButtons() {
    var footer = document.getElementById('sets');

    var crit = document.getElementById(
      'show-crits-toggle'
    );

    var learnsets = document.getElementById(
      'show-learnsets-toggle'
    );

    var changes = document.getElementById(
      'change-logs-button'
    );

    if (!footer || !crit || !learnsets) {
      return;
    }

    // Q must always be immediately after C.
    if (crit.nextElementSibling !== learnsets) {
      crit.insertAdjacentElement(
        'afterend',
        learnsets
      );
    }

    // UTOPIA_LEARNSET_UI_V4
    // Change Logs is the final button.
    // AI document always remains the rightmost link.
    var aiDocument = footer.querySelector(
      '.utopia-ai-document'
    );

    if (
      changes &&
      aiDocument &&
      changes.nextElementSibling !== aiDocument
    ) {
      footer.insertBefore(
        changes,
        aiDocument
      );
    }
  }

  function initializeFooterLayout() {
    var footer = document.getElementById('sets');

    if (!footer) return;

    positionFooterButtons();

    // The Change Logs button is created dynamically.
    // Observe only direct footer children.
    var observer = new MutationObserver(function () {
      positionFooterButtons();
    });

    observer.observe(footer, {
      childList: true
    });

    positionFooterButtons();
  }

  if (document.readyState === 'loading') {
    document.addEventListener(
      'DOMContentLoaded',
      initializeFooterLayout
    );
  } else {
    initializeFooterLayout();
  }

})();

