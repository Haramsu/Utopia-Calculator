/* UTOPIA_TRAINER_PAIRS_V1 */
/* UTOPIA_TRAINER_SELECTOR_V2 */
var UTOPIA_TRAINER_OPTIONS = [];
var UTOPIA_TRAINER_BY_ID = {};
var UTOPIA_TRAINER_BY_SET = {};

/* UTOPIA_DUO_NAMES_V1 */

/* UTOPIA_MEGA_DISPLAY_NAMES_V5 */
function utopiaMegaDisplayName(value) {
    var text = String(value || '');
    return text.replace(/([A-Za-zÀ-ÿ0-9 .'-]+?)\s*\[Mega ([^\]]+)\]/g, function(full, base, mega) {
        var species = base.trim();
        var form = mega.trim();
        if (form.toLowerCase().indexOf(species.toLowerCase()) === 0) {
            form = form.slice(species.length).trim();
        }
        return species + '-Mega' + (form ? '-' + form.replace(/\s+/g, '-') : '');
    });
}

function utopiaCleanLabel(value) {
  var name = String(value || '');
  /* UTOPIA_SPECIAL_TRAINER_NAMES_V1 */
  name = name.replace(/^haramsu\s+haramsu(?=\s|$)/i, 'Pokémon Trainer Haramsu');
  name = name.replace(/^toni\s+toni(?=\s|$)/i, 'Pokémon Trainer Toni');
  name = name.replace(/^casual\s+casual(?=\s|$)/i, 'Pokémon Trainer Casual');
  /* UTOPIA_TRAINER_DISPLAY_NAMES_V1 */
  name = name.replace(/^Cooltrainer(?=\s)/i, 'Ace Trainer');
  name = name.replace(/^Pokemonranger(?=\s)/i, 'Pokémon Ranger');
  name = name.replace(/^Pokemonbreeder(?=\s)/i, 'Pokémon Breeder');
  name = name.replace(/^Galactic\s+F\s+Grunt\b/i, 'Galactic Grunt Female');
  name = name.replace(/^Galactic\s+M\s+Grunt\b/i, 'Galactic Grunt Male');
  name = name.replace(/^Galactic\s+Grunt\s+F\b/i, 'Galactic Grunt Female');
  name = name.replace(/^Galactic\s+Grunt\s+M\b/i, 'Galactic Grunt Male');
  name = name.replace(/^(.+?)\s+[FM]\s+(?=\S)/, '$1 ');
  var duos = [
    'Camper Bernie & Ernie',
    'Ace Trainer Elias & Kata',
    'Swimmer Jenny & Aromalady Caroline',
    'Burglar Max & Greed',
    'Ace Trainer Kyle & Molly'
  ];
  for (var i = 0; i < duos.length; i++) {
    if (name.indexOf(duos[i] + ' (DOUBLES)') >= 0) {
      name = name.replace(duos[i] + ' (DOUBLES)', duos[i]);
      break;
    }
  }
  return utopiaMegaDisplayName(name.replace(/\s*\[Slot \d+\]/gi, ''));
}

function utopiaMakeTrainerOptions() {
  UTOPIA_TRAINER_OPTIONS = [];
  UTOPIA_TRAINER_BY_ID = {};
  UTOPIA_TRAINER_BY_SET = {};
  for (var species in SETDEX_SS) {
    if (!Object.prototype.hasOwnProperty.call(SETDEX_SS, species)) continue;
    var sets = SETDEX_SS[species];
    for (var label in sets) {
      if (!Object.prototype.hasOwnProperty.call(sets, label)) continue;
      var set = sets[label];
      if (!set.trainerId || set.trainerId === 'CYNTHIA:Cynthia:2') continue;
      var id = species + ' (' + label + ')';
      var trainer = UTOPIA_TRAINER_BY_ID[set.trainerId];
      if (!trainer) {
        trainer = {
          id: id,
          trainerId: set.trainerId,
          index: Number(set.index),
          text: utopiaCleanLabel(label),
          doubles: set.doubles === true
        };
        UTOPIA_TRAINER_BY_ID[set.trainerId] = trainer;
        UTOPIA_TRAINER_OPTIONS.push(trainer);
      }
      UTOPIA_TRAINER_BY_SET[id] = trainer;
    }
  }
  UTOPIA_TRAINER_OPTIONS.sort(function(a, b) {
    return a.index - b.index;
  });
}

function utopiaTrainerForValue(value) {
  return UTOPIA_TRAINER_BY_SET[value] || null;
}

function utopiaSyncTrainerDisplay() {
  var input = $('.opposing');
  if (!input.length) return;

  var value = input.val();
  var trainer = utopiaTrainerForValue(value);

  if (!trainer) return;

  var container = null;

  try {
    container = input.select2('container');
  } catch (error) {
    return;
  }

  if (!container || !container.length) return;

  var chosen = container.find('.select2-chosen');

  if (!chosen.length) return;

  if (chosen.text() !== trainer.text) {
    chosen.text(trainer.text);
  }
}

function utopiaSetBattleMode(doubles) {
  var target = doubles ? "#doubles-format" : "#singles-format";
  var button = $(target);
  if (!button.length) return;
  var activeMode = window.isInDoubles === true;
  if (activeMode !== doubles) {
    button.trigger("click");
  }
  if ((window.isInDoubles === true) !== doubles) {
    if (doubles) {
      switchIconSingle();
    } else {
      switchIconDouble();
    }
  }
  if (!button.prop("checked")) {
    button.prop("checked", true);
    button.trigger("change");
  }
}

function utopiaRefreshTrainerLabel() {
  var trainer = utopiaTrainerForValue($('.opposing').val());
  if (trainer) {
    var container = $('.opposing').select2('container');
    if (container && container.length) {
      container.find('.select2-chosen').text(trainer.text);
    }
  }
}

function utopiaTrainerChosen() {
  var trainer = utopiaTrainerForValue($('.opposing').val());
  if (!trainer) return;
  var nextId = String(trainer.id);
  if (window.utopiaPreviousTrainerId !== undefined && window.utopiaPreviousTrainerId !== nextId) {
    var lowerRow = document.getElementById('trainer-pok-list-opposing2');
    if (lowerRow) lowerRow.innerHTML = '';
  }
  window.utopiaPreviousTrainerId = nextId;
  nextTrainerId = trainer.index + 1;
  previousTrainerId = trainer.index - 1;
  localStorage.setItem('lasttimetrainer', trainer.index);
  utopiaSetBattleMode(trainer.doubles);
}




/* UTOPIA_ICON_MAP_START */
var UTOPIA_ICON_MAP = {"Abomasnow":{"normal":"ABOMASNOW.png","shiny":"ABOMASNOW.png","speciesKey":"ABOMASNOW:0"},"Abomasnow [Mega Abomasnow]":{"normal":"ABOMASNOW_1.png","shiny":"ABOMASNOW_1.png","speciesKey":"ABOMASNOW:1"},"Abra":{"normal":"ABRA.png","shiny":"ABRA.png","speciesKey":"ABRA:0"},"Absol":{"normal":"ABSOL.png","shiny":"ABSOL.png","speciesKey":"ABSOL:0"},"Absol [Mega Absol]":{"normal":"ABSOL_1.png","shiny":"ABSOL_1.png","speciesKey":"ABSOL:1"},"Absol [Mega Absol Z]":{"normal":"ABSOL_2.png","shiny":"ABSOL_2.png","speciesKey":"ABSOL:2"},"Accelgor":{"normal":"ACCELGOR.png","shiny":"ACCELGOR.png","speciesKey":"ACCELGOR:0"},"Aegislash":{"normal":"AEGISLASH.png","shiny":"AEGISLASH.png","speciesKey":"AEGISLASH:0"},"Aegislash [Blade Forme]":{"normal":"AEGISLASH_1.png","shiny":"AEGISLASH_1.png","speciesKey":"AEGISLASH:1"},"Aerodactyl":{"normal":"AERODACTYL.png","shiny":"AERODACTYL.png","speciesKey":"AERODACTYL:0"},"Aerodactyl [Mega Aerodactyl]":{"normal":"AERODACTYL_1.png","shiny":"AERODACTYL_1.png","speciesKey":"AERODACTYL:1"},"Aggron":{"normal":"AGGRON.png","shiny":"AGGRON.png","speciesKey":"AGGRON:0"},"Aggron [Mega Aggron]":{"normal":"AGGRON_1.png","shiny":"AGGRON_1.png","speciesKey":"AGGRON:1"},"Aipom":{"normal":"AIPOM.png","shiny":"AIPOM.png","speciesKey":"AIPOM:0"},"Alakazam":{"normal":"ALAKAZAM.png","shiny":"ALAKAZAM.png","speciesKey":"ALAKAZAM:0"},"Alakazam [Mega Alakazam]":{"normal":"ALAKAZAM_1.png","shiny":"ALAKAZAM_1.png","speciesKey":"ALAKAZAM:1"},"Alcremie":{"normal":"ALCREMIE.png","shiny":"ALCREMIE.png","speciesKey":"ALCREMIE:0"},"Alcremie [Ruby Cream]":{"normal":"ALCREMIE_7.png","shiny":"ALCREMIE_7.png","speciesKey":"ALCREMIE:7"},"Alcremie [Form 8]":{"normal":"ALCREMIE_8.png","shiny":"ALCREMIE_8.png","speciesKey":"ALCREMIE:8"},"Alcremie [Form 9]":{"normal":"ALCREMIE_9.png","shiny":"ALCREMIE_9.png","speciesKey":"ALCREMIE:9"},"Alcremie [Form 10]":{"normal":"ALCREMIE_10.png","shiny":"ALCREMIE_10.png","speciesKey":"ALCREMIE:10"},"Alcremie [Form 11]":{"normal":"ALCREMIE_11.png","shiny":"ALCREMIE_11.png","speciesKey":"ALCREMIE:11"},"Alcremie [Form 12]":{"normal":"ALCREMIE_12.png","shiny":"ALCREMIE_12.png","speciesKey":"ALCREMIE:12"},"Alcremie [Form 13]":{"normal":"ALCREMIE_13.png","shiny":"ALCREMIE_13.png","speciesKey":"ALCREMIE:13"},"Alcremie [Matcha Cream]":{"normal":"ALCREMIE_14.png","shiny":"ALCREMIE_14.png","speciesKey":"ALCREMIE:14"},"Alcremie [Form 15]":{"normal":"ALCREMIE_15.png","shiny":"ALCREMIE_15.png","speciesKey":"ALCREMIE:15"},"Alcremie [Form 16]":{"normal":"ALCREMIE_16.png","shiny":"ALCREMIE_16.png","speciesKey":"ALCREMIE:16"},"Alcremie [Form 17]":{"normal":"ALCREMIE_17.png","shiny":"ALCREMIE_17.png","speciesKey":"ALCREMIE:17"},"Alcremie [Form 18]":{"normal":"ALCREMIE_18.png","shiny":"ALCREMIE_18.png","speciesKey":"ALCREMIE:18"},"Alcremie [Form 19]":{"normal":"ALCREMIE_19.png","shiny":"ALCREMIE_19.png","speciesKey":"ALCREMIE:19"},"Alcremie [Form 20]":{"normal":"ALCREMIE_20.png","shiny":"ALCREMIE_20.png","speciesKey":"ALCREMIE:20"},"Alcremie [Mint Cream]":{"normal":"ALCREMIE_21.png","shiny":"ALCREMIE_21.png","speciesKey":"ALCREMIE:21"},"Alcremie [Form 22]":{"normal":"ALCREMIE_22.png","shiny":"ALCREMIE_22.png","speciesKey":"ALCREMIE:22"},"Alcremie [Form 23]":{"normal":"ALCREMIE_23.png","shiny":"ALCREMIE_23.png","speciesKey":"ALCREMIE:23"},"Alcremie [Form 24]":{"normal":"ALCREMIE_24.png","shiny":"ALCREMIE_24.png","speciesKey":"ALCREMIE:24"},"Alcremie [Form 25]":{"normal":"ALCREMIE_25.png","shiny":"ALCREMIE_25.png","speciesKey":"ALCREMIE:25"},"Alcremie [Form 26]":{"normal":"ALCREMIE_26.png","shiny":"ALCREMIE_26.png","speciesKey":"ALCREMIE:26"},"Alcremie [Form 27]":{"normal":"ALCREMIE_27.png","shiny":"ALCREMIE_27.png","speciesKey":"ALCREMIE:27"},"Alcremie [Lemon Cream]":{"normal":"ALCREMIE_28.png","shiny":"ALCREMIE_28.png","speciesKey":"ALCREMIE:28"},"Alcremie [Form 29]":{"normal":"ALCREMIE_29.png","shiny":"ALCREMIE_29.png","speciesKey":"ALCREMIE:29"},"Alcremie [Form 30]":{"normal":"ALCREMIE_30.png","shiny":"ALCREMIE_30.png","speciesKey":"ALCREMIE:30"},"Alcremie [Form 31]":{"normal":"ALCREMIE_31.png","shiny":"ALCREMIE_31.png","speciesKey":"ALCREMIE:31"},"Alcremie [Form 32]":{"normal":"ALCREMIE_32.png","shiny":"ALCREMIE_32.png","speciesKey":"ALCREMIE:32"},"Alcremie [Form 33]":{"normal":"ALCREMIE_33.png","shiny":"ALCREMIE_33.png","speciesKey":"ALCREMIE:33"},"Alcremie [Form 34]":{"normal":"ALCREMIE_34.png","shiny":"ALCREMIE_34.png","speciesKey":"ALCREMIE:34"},"Alcremie [Salted Cream]":{"normal":"ALCREMIE_35.png","shiny":"ALCREMIE_35.png","speciesKey":"ALCREMIE:35"},"Alcremie [Form 36]":{"normal":"ALCREMIE_36.png","shiny":"ALCREMIE_36.png","speciesKey":"ALCREMIE:36"},"Alcremie [Form 37]":{"normal":"ALCREMIE_37.png","shiny":"ALCREMIE_37.png","speciesKey":"ALCREMIE:37"},"Alcremie [Form 38]":{"normal":"ALCREMIE_38.png","shiny":"ALCREMIE_38.png","speciesKey":"ALCREMIE:38"},"Alcremie [Form 39]":{"normal":"ALCREMIE_39.png","shiny":"ALCREMIE_39.png","speciesKey":"ALCREMIE:39"},"Alcremie [Form 40]":{"normal":"ALCREMIE_40.png","shiny":"ALCREMIE_40.png","speciesKey":"ALCREMIE:40"},"Alcremie [Form 41]":{"normal":"ALCREMIE_41.png","shiny":"ALCREMIE_41.png","speciesKey":"ALCREMIE:41"},"Alcremie [Ruby Swirl]":{"normal":"ALCREMIE_42.png","shiny":"ALCREMIE_42.png","speciesKey":"ALCREMIE:42"},"Alcremie [Form 43]":{"normal":"ALCREMIE_43.png","shiny":"ALCREMIE_43.png","speciesKey":"ALCREMIE:43"},"Alcremie [Form 44]":{"normal":"ALCREMIE_44.png","shiny":"ALCREMIE_44.png","speciesKey":"ALCREMIE:44"},"Alcremie [Form 45]":{"normal":"ALCREMIE_45.png","shiny":"ALCREMIE_45.png","speciesKey":"ALCREMIE:45"},"Alcremie [Form 46]":{"normal":"ALCREMIE_46.png","shiny":"ALCREMIE_46.png","speciesKey":"ALCREMIE:46"},"Alcremie [Form 47]":{"normal":"ALCREMIE_47.png","shiny":"ALCREMIE_47.png","speciesKey":"ALCREMIE:47"},"Alcremie [Form 48]":{"normal":"ALCREMIE_48.png","shiny":"ALCREMIE_48.png","speciesKey":"ALCREMIE:48"},"Alcremie [Caramel Swirl]":{"normal":"ALCREMIE_49.png","shiny":"ALCREMIE_49.png","speciesKey":"ALCREMIE:49"},"Alcremie [Form 50]":{"normal":"ALCREMIE_50.png","shiny":"ALCREMIE_50.png","speciesKey":"ALCREMIE:50"},"Alcremie [Form 51]":{"normal":"ALCREMIE_51.png","shiny":"ALCREMIE_51.png","speciesKey":"ALCREMIE:51"},"Alcremie [Form 52]":{"normal":"ALCREMIE_52.png","shiny":"ALCREMIE_52.png","speciesKey":"ALCREMIE:52"},"Alcremie [Form 53]":{"normal":"ALCREMIE_53.png","shiny":"ALCREMIE_53.png","speciesKey":"ALCREMIE:53"},"Alcremie [Form 54]":{"normal":"ALCREMIE_54.png","shiny":"ALCREMIE_54.png","speciesKey":"ALCREMIE:54"},"Alcremie [Form 55]":{"normal":"ALCREMIE_55.png","shiny":"ALCREMIE_55.png","speciesKey":"ALCREMIE:55"},"Alcremie [Rainbow Swirl]":{"normal":"ALCREMIE_56.png","shiny":"ALCREMIE_56.png","speciesKey":"ALCREMIE:56"},"Alcremie [Form 57]":{"normal":"ALCREMIE_57.png","shiny":"ALCREMIE_57.png","speciesKey":"ALCREMIE:57"},"Alcremie [Form 58]":{"normal":"ALCREMIE_58.png","shiny":"ALCREMIE_58.png","speciesKey":"ALCREMIE:58"},"Alcremie [Form 59]":{"normal":"ALCREMIE_59.png","shiny":"ALCREMIE_59.png","speciesKey":"ALCREMIE:59"},"Alcremie [Form 60]":{"normal":"ALCREMIE_60.png","shiny":"ALCREMIE_60.png","speciesKey":"ALCREMIE:60"},"Alcremie [Form 61]":{"normal":"ALCREMIE_61.png","shiny":"ALCREMIE_61.png","speciesKey":"ALCREMIE:61"},"Alcremie [Form 62]":{"normal":"ALCREMIE_62.png","shiny":"ALCREMIE_62.png","speciesKey":"ALCREMIE:62"},"Alomomola":{"normal":"ALOMOMOLA.png","shiny":"ALOMOMOLA.png","speciesKey":"ALOMOMOLA:0"},"Altaria":{"normal":"ALTARIA.png","shiny":"ALTARIA.png","speciesKey":"ALTARIA:0"},"Altaria [Mega Altaria]":{"normal":"ALTARIA_1.png","shiny":"ALTARIA_1.png","speciesKey":"ALTARIA:1"},"Amaura":{"normal":"AMAURA.png","shiny":"AMAURA.png","speciesKey":"AMAURA:0"},"Ambipom":{"normal":"AMBIPOM.png","shiny":"AMBIPOM.png","speciesKey":"AMBIPOM:0"},"Amoonguss":{"normal":"AMOONGUSS.png","shiny":"AMOONGUSS.png","speciesKey":"AMOONGUSS:0"},"Ampharos":{"normal":"AMPHAROS.png","shiny":"AMPHAROS.png","speciesKey":"AMPHAROS:0"},"Ampharos [Mega Ampharos]":{"normal":"AMPHAROS_1.png","shiny":"AMPHAROS_1.png","speciesKey":"AMPHAROS:1"},"Annihilape":{"normal":"ANNIHILAPE.png","shiny":"ANNIHILAPE.png","speciesKey":"ANNIHILAPE:0"},"Anorith":{"normal":"ANORITH.png","shiny":"ANORITH.png","speciesKey":"ANORITH:0"},"Appletun":{"normal":"APPLETUN.png","shiny":"APPLETUN.png","speciesKey":"APPLETUN:0"},"Applin":{"normal":"APPLIN.png","shiny":"APPLIN.png","speciesKey":"APPLIN:0"},"Araquanid":{"normal":"ARAQUANID.png","shiny":"ARAQUANID.png","speciesKey":"ARAQUANID:0"},"Arbok":{"normal":"ARBOK.png","shiny":"ARBOK.png","speciesKey":"ARBOK:0"},"Arboliva":{"normal":"ARBOLIVA.png","shiny":"ARBOLIVA.png","speciesKey":"ARBOLIVA:0"},"Arcanine":{"normal":"ARCANINE.png","shiny":"ARCANINE.png","speciesKey":"ARCANINE:0"},"Arcanine [Hisuian]":{"normal":"ARCANINE_1.png","shiny":"ARCANINE_1.png","speciesKey":"ARCANINE:1"},"Arceus":{"normal":"ARCEUS.png","shiny":"ARCEUS.png","speciesKey":"ARCEUS:0"},"Arceus [Fighting Type]":{"normal":"ARCEUS_1.png","shiny":"ARCEUS_1.png","speciesKey":"ARCEUS:1"},"Arceus [Flying Type]":{"normal":"ARCEUS_2.png","shiny":"ARCEUS_2.png","speciesKey":"ARCEUS:2"},"Arceus [Poison Type]":{"normal":"ARCEUS_3.png","shiny":"ARCEUS_3.png","speciesKey":"ARCEUS:3"},"Arceus [Ground Type]":{"normal":"ARCEUS_4.png","shiny":"ARCEUS_4.png","speciesKey":"ARCEUS:4"},"Arceus [Rock Type]":{"normal":"ARCEUS_5.png","shiny":"ARCEUS_5.png","speciesKey":"ARCEUS:5"},"Arceus [Bug Type]":{"normal":"ARCEUS_6.png","shiny":"ARCEUS_6.png","speciesKey":"ARCEUS:6"},"Arceus [Ghost Type]":{"normal":"ARCEUS_7.png","shiny":"ARCEUS_7.png","speciesKey":"ARCEUS:7"},"Arceus [Steel Type]":{"normal":"ARCEUS_8.png","shiny":"ARCEUS_8.png","speciesKey":"ARCEUS:8"},"Arceus [Unknown Type]":{"normal":"ARCEUS_9.png","shiny":"ARCEUS_9.png","speciesKey":"ARCEUS:9"},"Arceus [Fire Type]":{"normal":"ARCEUS_10.png","shiny":"ARCEUS_10.png","speciesKey":"ARCEUS:10"},"Arceus [Water Type]":{"normal":"ARCEUS_11.png","shiny":"ARCEUS_11.png","speciesKey":"ARCEUS:11"},"Arceus [Grass Type]":{"normal":"ARCEUS_12.png","shiny":"ARCEUS_12.png","speciesKey":"ARCEUS:12"},"Arceus [Electric Type]":{"normal":"ARCEUS_13.png","shiny":"ARCEUS_13.png","speciesKey":"ARCEUS:13"},"Arceus [Psychic Type]":{"normal":"ARCEUS_14.png","shiny":"ARCEUS_14.png","speciesKey":"ARCEUS:14"},"Arceus [Ice Type]":{"normal":"ARCEUS_15.png","shiny":"ARCEUS_15.png","speciesKey":"ARCEUS:15"},"Arceus [Dragon Type]":{"normal":"ARCEUS_16.png","shiny":"ARCEUS_16.png","speciesKey":"ARCEUS:16"},"Arceus [Dark Type]":{"normal":"ARCEUS_17.png","shiny":"ARCEUS_17.png","speciesKey":"ARCEUS:17"},"Arceus [Fairy Type]":{"normal":"ARCEUS_18.png","shiny":"ARCEUS_18.png","speciesKey":"ARCEUS:18"},"Archaludon":{"normal":"ARCHALUDON.png","shiny":"ARCHALUDON.png","speciesKey":"ARCHALUDON:0"},"Archen":{"normal":"ARCHEN.png","shiny":"ARCHEN.png","speciesKey":"ARCHEN:0"},"Archeops":{"normal":"ARCHEOPS.png","shiny":"ARCHEOPS.png","speciesKey":"ARCHEOPS:0"},"Arctibax":{"normal":"ARCTIBAX.png","shiny":"ARCTIBAX.png","speciesKey":"ARCTIBAX:0"},"Arctovish":{"normal":"ARCTOVISH.png","shiny":"ARCTOVISH.png","speciesKey":"ARCTOVISH:0"},"Arctozolt":{"normal":"ARCTOZOLT.png","shiny":"ARCTOZOLT.png","speciesKey":"ARCTOZOLT:0"},"Ariados":{"normal":"ARIADOS.png","shiny":"ARIADOS.png","speciesKey":"ARIADOS:0"},"Armaldo":{"normal":"ARMALDO.png","shiny":"ARMALDO.png","speciesKey":"ARMALDO:0"},"Armarouge":{"normal":"ARMAROUGE.png","shiny":"ARMAROUGE.png","speciesKey":"ARMAROUGE:0"},"Aromatisse":{"normal":"AROMATISSE.png","shiny":"AROMATISSE.png","speciesKey":"AROMATISSE:0"},"Aron":{"normal":"ARON.png","shiny":"ARON.png","speciesKey":"ARON:0"},"Arrokuda":{"normal":"ARROKUDA.png","shiny":"ARROKUDA.png","speciesKey":"ARROKUDA:0"},"Articuno":{"normal":"ARTICUNO.png","shiny":"ARTICUNO.png","speciesKey":"ARTICUNO:0"},"Articuno [Galarian]":{"normal":"ARTICUNO_1.png","shiny":"ARTICUNO_1.png","speciesKey":"ARTICUNO:1"},"Audino":{"normal":"AUDINO.png","shiny":"AUDINO.png","speciesKey":"AUDINO:0"},"Audino [Mega Audino]":{"normal":"AUDINO_1.png","shiny":"AUDINO_1.png","speciesKey":"AUDINO:1"},"Aurorus":{"normal":"AURORUS.png","shiny":"AURORUS.png","speciesKey":"AURORUS:0"},"Avalugg":{"normal":"AVALUGG.png","shiny":"AVALUGG.png","speciesKey":"AVALUGG:0"},"Avalugg [Hisuian]":{"normal":"AVALUGG_1.png","shiny":"AVALUGG_1.png","speciesKey":"AVALUGG:1"},"Axew":{"normal":"AXEW.png","shiny":"AXEW.png","speciesKey":"AXEW:0"},"Azelf":{"normal":"AZELF.png","shiny":"AZELF.png","speciesKey":"AZELF:0"},"Azumarill":{"normal":"AZUMARILL.png","shiny":"AZUMARILL.png","speciesKey":"AZUMARILL:0"},"Azurill":{"normal":"AZURILL.png","shiny":"AZURILL.png","speciesKey":"AZURILL:0"},"Bagon":{"normal":"BAGON.png","shiny":"BAGON.png","speciesKey":"BAGON:0"},"Baltoy":{"normal":"BALTOY.png","shiny":"BALTOY.png","speciesKey":"BALTOY:0"},"Banette":{"normal":"BANETTE.png","shiny":"BANETTE.png","speciesKey":"BANETTE:0"},"Banette [Mega Banette]":{"normal":"BANETTE_1.png","shiny":"BANETTE_1.png","speciesKey":"BANETTE:1"},"Barbaracle":{"normal":"BARBARACLE.png","shiny":"BARBARACLE.png","speciesKey":"BARBARACLE:0"},"Barbaracle [Mega Barbaracle]":{"normal":"BARBARACLE_1.png","shiny":"BARBARACLE_1.png","speciesKey":"BARBARACLE:1"},"Barboach":{"normal":"BARBOACH.png","shiny":"BARBOACH.png","speciesKey":"BARBOACH:0"},"Barraskewda":{"normal":"BARRASKEWDA.png","shiny":"BARRASKEWDA.png","speciesKey":"BARRASKEWDA:0"},"Basculegion":{"normal":"BASCULEGION.png","shiny":"BASCULEGION.png","speciesKey":"BASCULEGION:0"},"Basculegion [Female]":{"normal":"BASCULEGION.png","shiny":"BASCULEGION.png","speciesKey":"BASCULEGION:1"},"Basculin":{"normal":"BASCULIN.png","shiny":"BASCULIN.png","speciesKey":"BASCULIN:0"},"Basculin [Blue-Striped]":{"normal":"BASCULIN_1.png","shiny":"BASCULIN_1.png","speciesKey":"BASCULIN:1"},"Basculin [White-Striped]":{"normal":"BASCULIN_2.png","shiny":"BASCULIN_2.png","speciesKey":"BASCULIN:2"},"Bastiodon":{"normal":"BASTIODON.png","shiny":"BASTIODON.png","speciesKey":"BASTIODON:0"},"Baxcalibur":{"normal":"BAXCALIBUR.png","shiny":"BAXCALIBUR.png","speciesKey":"BAXCALIBUR:0"},"Baxcalibur [Mega Baxcalibur]":{"normal":"BAXCALIBUR_1.png","shiny":"BAXCALIBUR_1.png","speciesKey":"BAXCALIBUR:1"},"Bayleef":{"normal":"BAYLEEF.png","shiny":"BAYLEEF.png","speciesKey":"BAYLEEF:0"},"Beartic":{"normal":"BEARTIC.png","shiny":"BEARTIC.png","speciesKey":"BEARTIC:0"},"Beautifly":{"normal":"BEAUTIFLY.png","shiny":"BEAUTIFLY.png","speciesKey":"BEAUTIFLY:0"},"Beedrill":{"normal":"BEEDRILL.png","shiny":"BEEDRILL.png","speciesKey":"BEEDRILL:0"},"Beedrill [Mega Beedrill]":{"normal":"BEEDRILL_1.png","shiny":"BEEDRILL_1.png","speciesKey":"BEEDRILL:1"},"Beheeyem":{"normal":"BEHEEYEM.png","shiny":"BEHEEYEM.png","speciesKey":"BEHEEYEM:0"},"Beldum":{"normal":"BELDUM.png","shiny":"BELDUM.png","speciesKey":"BELDUM:0"},"Bellibolt":{"normal":"BELLIBOLT.png","shiny":"BELLIBOLT.png","speciesKey":"BELLIBOLT:0"},"Bellossom":{"normal":"BELLOSSOM.png","shiny":"BELLOSSOM.png","speciesKey":"BELLOSSOM:0"},"Bellsprout":{"normal":"BELLSPROUT.png","shiny":"BELLSPROUT.png","speciesKey":"BELLSPROUT:0"},"Bergmite":{"normal":"BERGMITE.png","shiny":"BERGMITE.png","speciesKey":"BERGMITE:0"},"Bewear":{"normal":"BEWEAR.png","shiny":"BEWEAR.png","speciesKey":"BEWEAR:0"},"Bibarel":{"normal":"BIBAREL.png","shiny":"BIBAREL.png","speciesKey":"BIBAREL:0"},"Bidoof":{"normal":"BIDOOF.png","shiny":"BIDOOF.png","speciesKey":"BIDOOF:0"},"Binacle":{"normal":"BINACLE.png","shiny":"BINACLE.png","speciesKey":"BINACLE:0"},"Bisharp":{"normal":"BISHARP.png","shiny":"BISHARP.png","speciesKey":"BISHARP:0"},"Blacephalon":{"normal":"BLACEPHALON.png","shiny":"BLACEPHALON.png","speciesKey":"BLACEPHALON:0"},"Blastoise":{"normal":"BLASTOISE.png","shiny":"BLASTOISE.png","speciesKey":"BLASTOISE:0"},"Blastoise [Mega Blastoise]":{"normal":"BLASTOISE_1.png","shiny":"BLASTOISE_1.png","speciesKey":"BLASTOISE:1"},"Blaziken":{"normal":"BLAZIKEN.png","shiny":"BLAZIKEN.png","speciesKey":"BLAZIKEN:0"},"Blaziken [Mega Blaziken]":{"normal":"BLAZIKEN_1.png","shiny":"BLAZIKEN_1.png","speciesKey":"BLAZIKEN:1"},"Blipbug":{"normal":"BLIPBUG.png","shiny":"BLIPBUG.png","speciesKey":"BLIPBUG:0"},"Blissey":{"normal":"BLISSEY.png","shiny":"BLISSEY.png","speciesKey":"BLISSEY:0"},"Blitzle":{"normal":"BLITZLE.png","shiny":"BLITZLE.png","speciesKey":"BLITZLE:0"},"Boldore":{"normal":"BOLDORE.png","shiny":"BOLDORE.png","speciesKey":"BOLDORE:0"},"Boltund":{"normal":"BOLTUND.png","shiny":"BOLTUND.png","speciesKey":"BOLTUND:0"},"Bombirdier":{"normal":"BOMBIRDIER.png","shiny":"BOMBIRDIER.png","speciesKey":"BOMBIRDIER:0"},"Bonsly":{"normal":"BONSLY.png","shiny":"BONSLY.png","speciesKey":"BONSLY:0"},"Bouffalant":{"normal":"BOUFFALANT.png","shiny":"BOUFFALANT.png","speciesKey":"BOUFFALANT:0"},"Bounsweet":{"normal":"BOUNSWEET.png","shiny":"BOUNSWEET.png","speciesKey":"BOUNSWEET:0"},"Braixen":{"normal":"BRAIXEN.png","shiny":"BRAIXEN.png","speciesKey":"BRAIXEN:0"},"Brambleghast":{"normal":"BRAMBLEGHAST.png","shiny":"BRAMBLEGHAST.png","speciesKey":"BRAMBLEGHAST:0"},"Bramblin":{"normal":"BRAMBLIN.png","shiny":"BRAMBLIN.png","speciesKey":"BRAMBLIN:0"},"Braviary":{"normal":"BRAVIARY.png","shiny":"BRAVIARY.png","speciesKey":"BRAVIARY:0"},"Braviary [Hisuian]":{"normal":"BRAVIARY_1.png","shiny":"BRAVIARY_1.png","speciesKey":"BRAVIARY:1"},"Breloom":{"normal":"BRELOOM.png","shiny":"BRELOOM.png","speciesKey":"BRELOOM:0"},"Brionne":{"normal":"BRIONNE.png","shiny":"BRIONNE.png","speciesKey":"BRIONNE:0"},"Bronzong":{"normal":"BRONZONG.png","shiny":"BRONZONG.png","speciesKey":"BRONZONG:0"},"Bronzor":{"normal":"BRONZOR.png","shiny":"BRONZOR.png","speciesKey":"BRONZOR:0"},"Brute Bonnet":{"normal":"BRUTEBONNET.png","shiny":"BRUTEBONNET.png","speciesKey":"BRUTEBONNET:0"},"Bruxish":{"normal":"BRUXISH.png","shiny":"BRUXISH.png","speciesKey":"BRUXISH:0"},"Budew":{"normal":"BUDEW.png","shiny":"BUDEW.png","speciesKey":"BUDEW:0"},"Buizel":{"normal":"BUIZEL.png","shiny":"BUIZEL.png","speciesKey":"BUIZEL:0"},"Bulbasaur":{"normal":"BULBASAUR.png","shiny":"BULBASAUR.png","speciesKey":"BULBASAUR:0"},"Buneary":{"normal":"BUNEARY.png","shiny":"BUNEARY.png","speciesKey":"BUNEARY:0"},"Bunnelby":{"normal":"BUNNELBY.png","shiny":"BUNNELBY.png","speciesKey":"BUNNELBY:0"},"Burmy":{"normal":"BURMY.png","shiny":"BURMY.png","speciesKey":"BURMY:0"},"Burmy [Sandy Cloak]":{"normal":"BURMY_1.png","shiny":"BURMY_1.png","speciesKey":"BURMY:1"},"Burmy [Trash Cloak]":{"normal":"BURMY_2.png","shiny":"BURMY_2.png","speciesKey":"BURMY:2"},"Butterfree":{"normal":"BUTTERFREE.png","shiny":"BUTTERFREE.png","speciesKey":"BUTTERFREE:0"},"Buzzwole":{"normal":"BUZZWOLE.png","shiny":"BUZZWOLE.png","speciesKey":"BUZZWOLE:0"},"Cacnea":{"normal":"CACNEA.png","shiny":"CACNEA.png","speciesKey":"CACNEA:0"},"Cacturne":{"normal":"CACTURNE.png","shiny":"CACTURNE.png","speciesKey":"CACTURNE:0"},"Calyrex":{"normal":"CALYREX.png","shiny":"CALYREX.png","speciesKey":"CALYREX:0"},"Calyrex [Ice Rider]":{"normal":"CALYREX_1.png","shiny":"CALYREX_1.png","speciesKey":"CALYREX:1"},"Calyrex [Shadow Rider]":{"normal":"CALYREX_2.png","shiny":"CALYREX_2.png","speciesKey":"CALYREX:2"},"Camerupt":{"normal":"CAMERUPT.png","shiny":"CAMERUPT.png","speciesKey":"CAMERUPT:0"},"Camerupt [Mega Camerupt]":{"normal":"CAMERUPT_1.png","shiny":"CAMERUPT_1.png","speciesKey":"CAMERUPT:1"},"Capsakid":{"normal":"CAPSAKID.png","shiny":"CAPSAKID.png","speciesKey":"CAPSAKID:0"},"Carbink":{"normal":"CARBINK.png","shiny":"CARBINK.png","speciesKey":"CARBINK:0"},"Carkol":{"normal":"CARKOL.png","shiny":"CARKOL.png","speciesKey":"CARKOL:0"},"Carnivine":{"normal":"CARNIVINE.png","shiny":"CARNIVINE.png","speciesKey":"CARNIVINE:0"},"Carracosta":{"normal":"CARRACOSTA.png","shiny":"CARRACOSTA.png","speciesKey":"CARRACOSTA:0"},"Carvanha":{"normal":"CARVANHA.png","shiny":"CARVANHA.png","speciesKey":"CARVANHA:0"},"Cascoon":{"normal":"CASCOON.png","shiny":"CASCOON.png","speciesKey":"CASCOON:0"},"Castform":{"normal":"CASTFORM.png","shiny":"CASTFORM.png","speciesKey":"CASTFORM:0"},"Castform [Sunny Form]":{"normal":"CASTFORM_1.png","shiny":"CASTFORM_1.png","speciesKey":"CASTFORM:1"},"Castform [Rainy Form]":{"normal":"CASTFORM_2.png","shiny":"CASTFORM_2.png","speciesKey":"CASTFORM:2"},"Castform [Snowy Form]":{"normal":"CASTFORM_3.png","shiny":"CASTFORM_3.png","speciesKey":"CASTFORM:3"},"Caterpie":{"normal":"CATERPIE.png","shiny":"CATERPIE.png","speciesKey":"CATERPIE:0"},"Celebi":{"normal":"CELEBI.png","shiny":"CELEBI.png","speciesKey":"CELEBI:0"},"Celesteela":{"normal":"CELESTEELA.png","shiny":"CELESTEELA.png","speciesKey":"CELESTEELA:0"},"Centiskorch":{"normal":"CENTISKORCH.png","shiny":"CENTISKORCH.png","speciesKey":"CENTISKORCH:0"},"Ceruledge":{"normal":"CERULEDGE.png","shiny":"CERULEDGE.png","speciesKey":"CERULEDGE:0"},"Cetitan":{"normal":"CETITAN.png","shiny":"CETITAN.png","speciesKey":"CETITAN:0"},"Cetoddle":{"normal":"CETODDLE.png","shiny":"CETODDLE.png","speciesKey":"CETODDLE:0"},"Chandelure":{"normal":"CHANDELURE.png","shiny":"CHANDELURE.png","speciesKey":"CHANDELURE:0"},"Chandelure [Mega Chandelure]":{"normal":"CHANDELURE_1.png","shiny":"CHANDELURE_1.png","speciesKey":"CHANDELURE:1"},"Chansey":{"normal":"CHANSEY.png","shiny":"CHANSEY.png","speciesKey":"CHANSEY:0"},"Charcadet":{"normal":"CHARCADET.png","shiny":"CHARCADET.png","speciesKey":"CHARCADET:0"},"Charizard":{"normal":"CHARIZARD.png","shiny":"CHARIZARD.png","speciesKey":"CHARIZARD:0"},"Charizard [Mega Charizard X]":{"normal":"CHARIZARD_1.png","shiny":"CHARIZARD_1.png","speciesKey":"CHARIZARD:1"},"Charizard [Mega Charizard Y]":{"normal":"CHARIZARD_2.png","shiny":"CHARIZARD_2.png","speciesKey":"CHARIZARD:2"},"Charjabug":{"normal":"CHARJABUG.png","shiny":"CHARJABUG.png","speciesKey":"CHARJABUG:0"},"Charmander":{"normal":"CHARMANDER.png","shiny":"CHARMANDER.png","speciesKey":"CHARMANDER:0"},"Charmeleon":{"normal":"CHARMELEON.png","shiny":"CHARMELEON.png","speciesKey":"CHARMELEON:0"},"Chatot":{"normal":"CHATOT.png","shiny":"CHATOT.png","speciesKey":"CHATOT:0"},"Cherrim":{"normal":"CHERRIM.png","shiny":"CHERRIM.png","speciesKey":"CHERRIM:0"},"Cherrim [Sunshine Form]":{"normal":"CHERRIM_1.png","shiny":"CHERRIM_1.png","speciesKey":"CHERRIM:1"},"Cherubi":{"normal":"CHERUBI.png","shiny":"CHERUBI.png","speciesKey":"CHERUBI:0"},"Chesnaught":{"normal":"CHESNAUGHT.png","shiny":"CHESNAUGHT.png","speciesKey":"CHESNAUGHT:0"},"Chesnaught [Mega Chesnaught]":{"normal":"CHESNAUGHT_1.png","shiny":"CHESNAUGHT_1.png","speciesKey":"CHESNAUGHT:1"},"Chespin":{"normal":"CHESPIN.png","shiny":"CHESPIN.png","speciesKey":"CHESPIN:0"},"Chewtle":{"normal":"CHEWTLE.png","shiny":"CHEWTLE.png","speciesKey":"CHEWTLE:0"},"Chien-Pao":{"normal":"CHIENPAO.png","shiny":"CHIENPAO.png","speciesKey":"CHIENPAO:0"},"Chikorita":{"normal":"CHIKORITA.png","shiny":"CHIKORITA.png","speciesKey":"CHIKORITA:0"},"Chimchar":{"normal":"CHIMCHAR.png","shiny":"CHIMCHAR.png","speciesKey":"CHIMCHAR:0"},"Chimecho":{"normal":"CHIMECHO.png","shiny":"CHIMECHO.png","speciesKey":"CHIMECHO:0"},"Chimecho [Mega Chimecho]":{"normal":"CHIMECHO_1.png","shiny":"CHIMECHO_1.png","speciesKey":"CHIMECHO:1"},"Chinchou":{"normal":"CHINCHOU.png","shiny":"CHINCHOU.png","speciesKey":"CHINCHOU:0"},"Chingling":{"normal":"CHINGLING.png","shiny":"CHINGLING.png","speciesKey":"CHINGLING:0"},"Chi-Yu":{"normal":"CHIYU.png","shiny":"CHIYU.png","speciesKey":"CHIYU:0"},"Cinccino":{"normal":"CINCCINO.png","shiny":"CINCCINO.png","speciesKey":"CINCCINO:0"},"Cinderace":{"normal":"CINDERACE.png","shiny":"CINDERACE.png","speciesKey":"CINDERACE:0"},"Clamperl":{"normal":"CLAMPERL.png","shiny":"CLAMPERL.png","speciesKey":"CLAMPERL:0"},"Clauncher":{"normal":"CLAUNCHER.png","shiny":"CLAUNCHER.png","speciesKey":"CLAUNCHER:0"},"Clawitzer":{"normal":"CLAWITZER.png","shiny":"CLAWITZER.png","speciesKey":"CLAWITZER:0"},"Claydol":{"normal":"CLAYDOL.png","shiny":"CLAYDOL.png","speciesKey":"CLAYDOL:0"},"Clefable":{"normal":"CLEFABLE.png","shiny":"CLEFABLE.png","speciesKey":"CLEFABLE:0"},"Clefable [Mega Clefable]":{"normal":"CLEFABLE_1.png","shiny":"CLEFABLE_1.png","speciesKey":"CLEFABLE:1"},"Clefairy":{"normal":"CLEFAIRY.png","shiny":"CLEFAIRY.png","speciesKey":"CLEFAIRY:0"},"Cleffa":{"normal":"CLEFFA.png","shiny":"CLEFFA.png","speciesKey":"CLEFFA:0"},"Clobbopus":{"normal":"CLOBBOPUS.png","shiny":"CLOBBOPUS.png","speciesKey":"CLOBBOPUS:0"},"Clodsire":{"normal":"CLODSIRE.png","shiny":"CLODSIRE.png","speciesKey":"CLODSIRE:0"},"Cloyster":{"normal":"CLOYSTER.png","shiny":"CLOYSTER.png","speciesKey":"CLOYSTER:0"},"Coalossal":{"normal":"COALOSSAL.png","shiny":"COALOSSAL.png","speciesKey":"COALOSSAL:0"},"Cobalion":{"normal":"COBALION.png","shiny":"COBALION.png","speciesKey":"COBALION:0"},"Cofagrigus":{"normal":"COFAGRIGUS.png","shiny":"COFAGRIGUS.png","speciesKey":"COFAGRIGUS:0"},"Combee":{"normal":"COMBEE.png","shiny":"COMBEE.png","speciesKey":"COMBEE:0"},"Combusken":{"normal":"COMBUSKEN.png","shiny":"COMBUSKEN.png","speciesKey":"COMBUSKEN:0"},"Comfey":{"normal":"COMFEY.png","shiny":"COMFEY.png","speciesKey":"COMFEY:0"},"Conkeldurr":{"normal":"CONKELDURR.png","shiny":"CONKELDURR.png","speciesKey":"CONKELDURR:0"},"Copperajah":{"normal":"COPPERAJAH.png","shiny":"COPPERAJAH.png","speciesKey":"COPPERAJAH:0"},"Corphish":{"normal":"CORPHISH.png","shiny":"CORPHISH.png","speciesKey":"CORPHISH:0"},"Corsola":{"normal":"CORSOLA.png","shiny":"CORSOLA.png","speciesKey":"CORSOLA:0"},"Corsola [Galarian]":{"normal":"CORSOLA_1.png","shiny":"CORSOLA_1.png","speciesKey":"CORSOLA:1"},"Corviknight":{"normal":"CORVIKNIGHT.png","shiny":"CORVIKNIGHT.png","speciesKey":"CORVIKNIGHT:0"},"Corvisquire":{"normal":"CORVISQUIRE.png","shiny":"CORVISQUIRE.png","speciesKey":"CORVISQUIRE:0"},"Cosmoem":{"normal":"COSMOEM.png","shiny":"COSMOEM.png","speciesKey":"COSMOEM:0"},"Cosmog":{"normal":"COSMOG.png","shiny":"COSMOG.png","speciesKey":"COSMOG:0"},"Cottonee":{"normal":"COTTONEE.png","shiny":"COTTONEE.png","speciesKey":"COTTONEE:0"},"Crabominable":{"normal":"CRABOMINABLE.png","shiny":"CRABOMINABLE.png","speciesKey":"CRABOMINABLE:0"},"Crabominable [Mega Crabominable]":{"normal":"CRABOMINABLE_1.png","shiny":"CRABOMINABLE_1.png","speciesKey":"CRABOMINABLE:1"},"Crabrawler":{"normal":"CRABRAWLER.png","shiny":"CRABRAWLER.png","speciesKey":"CRABRAWLER:0"},"Cradily":{"normal":"CRADILY.png","shiny":"CRADILY.png","speciesKey":"CRADILY:0"},"Cramorant":{"normal":"CRAMORANT.png","shiny":"CRAMORANT.png","speciesKey":"CRAMORANT:0"},"Cramorant [Gulping Form]":{"normal":"CRAMORANT_1.png","shiny":"CRAMORANT_1.png","speciesKey":"CRAMORANT:1"},"Cramorant [Gorging Form]":{"normal":"CRAMORANT_2.png","shiny":"CRAMORANT_2.png","speciesKey":"CRAMORANT:2"},"Cranidos":{"normal":"CRANIDOS.png","shiny":"CRANIDOS.png","speciesKey":"CRANIDOS:0"},"Crawdaunt":{"normal":"CRAWDAUNT.png","shiny":"CRAWDAUNT.png","speciesKey":"CRAWDAUNT:0"},"Cresselia":{"normal":"CRESSELIA.png","shiny":"CRESSELIA.png","speciesKey":"CRESSELIA:0"},"Croagunk":{"normal":"CROAGUNK.png","shiny":"CROAGUNK.png","speciesKey":"CROAGUNK:0"},"Crobat":{"normal":"CROBAT.png","shiny":"CROBAT.png","speciesKey":"CROBAT:0"},"Crocalor":{"normal":"CROCALOR.png","shiny":"CROCALOR.png","speciesKey":"CROCALOR:0"},"Croconaw":{"normal":"CROCONAW.png","shiny":"CROCONAW.png","speciesKey":"CROCONAW:0"},"Crustle":{"normal":"CRUSTLE.png","shiny":"CRUSTLE.png","speciesKey":"CRUSTLE:0"},"Cryogonal":{"normal":"CRYOGONAL.png","shiny":"CRYOGONAL.png","speciesKey":"CRYOGONAL:0"},"Cubchoo":{"normal":"CUBCHOO.png","shiny":"CUBCHOO.png","speciesKey":"CUBCHOO:0"},"Cubone":{"normal":"CUBONE.png","shiny":"CUBONE.png","speciesKey":"CUBONE:0"},"Cufant":{"normal":"CUFANT.png","shiny":"CUFANT.png","speciesKey":"CUFANT:0"},"Cursola":{"normal":"CURSOLA.png","shiny":"CURSOLA.png","speciesKey":"CURSOLA:0"},"Cutiefly":{"normal":"CUTIEFLY.png","shiny":"CUTIEFLY.png","speciesKey":"CUTIEFLY:0"},"Cyclizar":{"normal":"CYCLIZAR.png","shiny":"CYCLIZAR.png","speciesKey":"CYCLIZAR:0"},"Cyndaquil":{"normal":"CYNDAQUIL.png","shiny":"CYNDAQUIL.png","speciesKey":"CYNDAQUIL:0"},"Dachsbun":{"normal":"DACHSBUN.png","shiny":"DACHSBUN.png","speciesKey":"DACHSBUN:0"},"Darkrai":{"normal":"DARKRAI.png","shiny":"DARKRAI.png","speciesKey":"DARKRAI:0"},"Darkrai [Mega Darkrai]":{"normal":"DARKRAI_1.png","shiny":"DARKRAI_1.png","speciesKey":"DARKRAI:1"},"Darmanitan":{"normal":"DARMANITAN.png","shiny":"DARMANITAN.png","speciesKey":"DARMANITAN:0"},"Darmanitan [Zen Mode]":{"normal":"DARMANITAN_1.png","shiny":"DARMANITAN_1.png","speciesKey":"DARMANITAN:1"},"Darmanitan [Galarian Standard Mode]":{"normal":"DARMANITAN_2.png","shiny":"DARMANITAN_2.png","speciesKey":"DARMANITAN:2"},"Darmanitan [Galarian Zen Mode]":{"normal":"DARMANITAN_3.png","shiny":"DARMANITAN_3.png","speciesKey":"DARMANITAN:3"},"Dartrix":{"normal":"DARTRIX.png","shiny":"DARTRIX.png","speciesKey":"DARTRIX:0"},"Darumaka":{"normal":"DARUMAKA.png","shiny":"DARUMAKA.png","speciesKey":"DARUMAKA:0"},"Darumaka [Galarian]":{"normal":"DARUMAKA_2.png","shiny":"DARUMAKA_2.png","speciesKey":"DARUMAKA:2"},"Decidueye":{"normal":"DECIDUEYE.png","shiny":"DECIDUEYE.png","speciesKey":"DECIDUEYE:0"},"Decidueye [Hisuian]":{"normal":"DECIDUEYE_1.png","shiny":"DECIDUEYE_1.png","speciesKey":"DECIDUEYE:1"},"Dedenne":{"normal":"DEDENNE.png","shiny":"DEDENNE.png","speciesKey":"DEDENNE:0"},"Deerling":{"normal":"DEERLING.png","shiny":"DEERLING.png","speciesKey":"DEERLING:0"},"Deerling [Summer Form]":{"normal":"DEERLING_1.png","shiny":"DEERLING_1.png","speciesKey":"DEERLING:1"},"Deerling [Autumn Form]":{"normal":"DEERLING_2.png","shiny":"DEERLING_2.png","speciesKey":"DEERLING:2"},"Deerling [Winter Form]":{"normal":"DEERLING_3.png","shiny":"DEERLING_3.png","speciesKey":"DEERLING:3"},"Deino":{"normal":"DEINO.png","shiny":"DEINO.png","speciesKey":"DEINO:0"},"Delcatty":{"normal":"DELCATTY.png","shiny":"DELCATTY.png","speciesKey":"DELCATTY:0"},"Delibird":{"normal":"DELIBIRD.png","shiny":"DELIBIRD.png","speciesKey":"DELIBIRD:0"},"Delphox":{"normal":"DELPHOX.png","shiny":"DELPHOX.png","speciesKey":"DELPHOX:0"},"Delphox [Mega Delphox]":{"normal":"DELPHOX_1.png","shiny":"DELPHOX_1.png","speciesKey":"DELPHOX:1"},"Deoxys":{"normal":"DEOXYS.png","shiny":"DEOXYS.png","speciesKey":"DEOXYS:0"},"Deoxys [Attack Forme]":{"normal":"DEOXYS_1.png","shiny":"DEOXYS_1.png","speciesKey":"DEOXYS:1"},"Deoxys [Defense Forme]":{"normal":"DEOXYS_2.png","shiny":"DEOXYS_2.png","speciesKey":"DEOXYS:2"},"Deoxys [Speed Forme]":{"normal":"DEOXYS_3.png","shiny":"DEOXYS_3.png","speciesKey":"DEOXYS:3"},"Dewgong":{"normal":"DEWGONG.png","shiny":"DEWGONG.png","speciesKey":"DEWGONG:0"},"Dewott":{"normal":"DEWOTT.png","shiny":"DEWOTT.png","speciesKey":"DEWOTT:0"},"Dewpider":{"normal":"DEWPIDER.png","shiny":"DEWPIDER.png","speciesKey":"DEWPIDER:0"},"Dhelmise":{"normal":"DHELMISE.png","shiny":"DHELMISE.png","speciesKey":"DHELMISE:0"},"Dialga":{"normal":"DIALGA.png","shiny":"DIALGA.png","speciesKey":"DIALGA:0"},"Dialga [Origin Forme]":{"normal":"DIALGA_1.png","shiny":"DIALGA_1.png","speciesKey":"DIALGA:1"},"Diancie":{"normal":"DIANCIE.png","shiny":"DIANCIE.png","speciesKey":"DIANCIE:0"},"Diancie [Mega Diancie]":{"normal":"DIANCIE_1.png","shiny":"DIANCIE_1.png","speciesKey":"DIANCIE:1"},"Diggersby":{"normal":"DIGGERSBY.png","shiny":"DIGGERSBY.png","speciesKey":"DIGGERSBY:0"},"Diglett":{"normal":"DIGLETT.png","shiny":"DIGLETT.png","speciesKey":"DIGLETT:0"},"Diglett [Alolan]":{"normal":"DIGLETT_1.png","shiny":"DIGLETT_1.png","speciesKey":"DIGLETT:1"},"Dipplin":{"normal":"DIPPLIN.png","shiny":"DIPPLIN.png","speciesKey":"DIPPLIN:0"},"Ditto":{"normal":"DITTO.png","shiny":"DITTO.png","speciesKey":"DITTO:0"},"Dodrio":{"normal":"DODRIO.png","shiny":"DODRIO.png","speciesKey":"DODRIO:0"},"Doduo":{"normal":"DODUO.png","shiny":"DODUO.png","speciesKey":"DODUO:0"},"Dolliv":{"normal":"DOLLIV.png","shiny":"DOLLIV.png","speciesKey":"DOLLIV:0"},"Dondozo":{"normal":"DONDOZO.png","shiny":"DONDOZO.png","speciesKey":"DONDOZO:0"},"Donphan":{"normal":"DONPHAN.png","shiny":"DONPHAN.png","speciesKey":"DONPHAN:0"},"Dottler":{"normal":"DOTTLER.png","shiny":"DOTTLER.png","speciesKey":"DOTTLER:0"},"Doublade":{"normal":"DOUBLADE.png","shiny":"DOUBLADE.png","speciesKey":"DOUBLADE:0"},"Dracovish":{"normal":"DRACOVISH.png","shiny":"DRACOVISH.png","speciesKey":"DRACOVISH:0"},"Dracozolt":{"normal":"DRACOZOLT.png","shiny":"DRACOZOLT.png","speciesKey":"DRACOZOLT:0"},"Dragalge":{"normal":"DRAGALGE.png","shiny":"DRAGALGE.png","speciesKey":"DRAGALGE:0"},"Dragalge [Mega Dragalge]":{"normal":"DRAGALGE_1.png","shiny":"DRAGALGE_1.png","speciesKey":"DRAGALGE:1"},"Dragapult":{"normal":"DRAGAPULT.png","shiny":"DRAGAPULT.png","speciesKey":"DRAGAPULT:0"},"Dragonair":{"normal":"DRAGONAIR.png","shiny":"DRAGONAIR.png","speciesKey":"DRAGONAIR:0"},"Dragonite":{"normal":"DRAGONITE.png","shiny":"DRAGONITE.png","speciesKey":"DRAGONITE:0"},"Dragonite [Mega Dragonite]":{"normal":"DRAGONITE_1.png","shiny":"DRAGONITE_1.png","speciesKey":"DRAGONITE:1"},"Drakloak":{"normal":"DRAKLOAK.png","shiny":"DRAKLOAK.png","speciesKey":"DRAKLOAK:0"},"Drampa":{"normal":"DRAMPA.png","shiny":"DRAMPA.png","speciesKey":"DRAMPA:0"},"Drampa [Mega Drampa]":{"normal":"DRAMPA_1.png","shiny":"DRAMPA_1.png","speciesKey":"DRAMPA:1"},"Drapion":{"normal":"DRAPION.png","shiny":"DRAPION.png","speciesKey":"DRAPION:0"},"Dratini":{"normal":"DRATINI.png","shiny":"DRATINI.png","speciesKey":"DRATINI:0"},"Drednaw":{"normal":"DREDNAW.png","shiny":"DREDNAW.png","speciesKey":"DREDNAW:0"},"Dreepy":{"normal":"DREEPY.png","shiny":"DREEPY.png","speciesKey":"DREEPY:0"},"Drifblim":{"normal":"DRIFBLIM.png","shiny":"DRIFBLIM.png","speciesKey":"DRIFBLIM:0"},"Drifloon":{"normal":"DRIFLOON.png","shiny":"DRIFLOON.png","speciesKey":"DRIFLOON:0"},"Drilbur":{"normal":"DRILBUR.png","shiny":"DRILBUR.png","speciesKey":"DRILBUR:0"},"Drizzile":{"normal":"DRIZZILE.png","shiny":"DRIZZILE.png","speciesKey":"DRIZZILE:0"},"Drowzee":{"normal":"DROWZEE.png","shiny":"DROWZEE.png","speciesKey":"DROWZEE:0"},"Druddigon":{"normal":"DRUDDIGON.png","shiny":"DRUDDIGON.png","speciesKey":"DRUDDIGON:0"},"Dubwool":{"normal":"DUBWOOL.png","shiny":"DUBWOOL.png","speciesKey":"DUBWOOL:0"},"Ducklett":{"normal":"DUCKLETT.png","shiny":"DUCKLETT.png","speciesKey":"DUCKLETT:0"},"Dudunsparce":{"normal":"DUDUNSPARCE.png","shiny":"DUDUNSPARCE.png","speciesKey":"DUDUNSPARCE:0"},"Dudunsparce [Three-Segment Form]":{"normal":"DUDUNSPARCE_1.png","shiny":"DUDUNSPARCE_1.png","speciesKey":"DUDUNSPARCE:1"},"Dugtrio":{"normal":"DUGTRIO.png","shiny":"DUGTRIO.png","speciesKey":"DUGTRIO:0"},"Dugtrio [Alolan]":{"normal":"DUGTRIO_1.png","shiny":"DUGTRIO_1.png","speciesKey":"DUGTRIO:1"},"Dunsparce":{"normal":"DUNSPARCE.png","shiny":"DUNSPARCE.png","speciesKey":"DUNSPARCE:0"},"Duosion":{"normal":"DUOSION.png","shiny":"DUOSION.png","speciesKey":"DUOSION:0"},"Duraludon":{"normal":"DURALUDON.png","shiny":"DURALUDON.png","speciesKey":"DURALUDON:0"},"Durant":{"normal":"DURANT.png","shiny":"DURANT.png","speciesKey":"DURANT:0"},"Dusclops":{"normal":"DUSCLOPS.png","shiny":"DUSCLOPS.png","speciesKey":"DUSCLOPS:0"},"Dusknoir":{"normal":"DUSKNOIR.png","shiny":"DUSKNOIR.png","speciesKey":"DUSKNOIR:0"},"Duskull":{"normal":"DUSKULL.png","shiny":"DUSKULL.png","speciesKey":"DUSKULL:0"},"Dustox":{"normal":"DUSTOX.png","shiny":"DUSTOX.png","speciesKey":"DUSTOX:0"},"Dwebble":{"normal":"DWEBBLE.png","shiny":"DWEBBLE.png","speciesKey":"DWEBBLE:0"},"Eelektrik":{"normal":"EELEKTRIK.png","shiny":"EELEKTRIK.png","speciesKey":"EELEKTRIK:0"},"Eelektross":{"normal":"EELEKTROSS.png","shiny":"EELEKTROSS.png","speciesKey":"EELEKTROSS:0"},"Eelektross [Mega Eelektross]":{"normal":"EELEKTROSS_1.png","shiny":"EELEKTROSS_1.png","speciesKey":"EELEKTROSS:1"},"Eevee":{"normal":"EEVEE.png","shiny":"EEVEE.png","speciesKey":"EEVEE:0"},"Eiscue":{"normal":"EISCUE.png","shiny":"EISCUE.png","speciesKey":"EISCUE:0"},"Eiscue [Noice Face]":{"normal":"EISCUE_1.png","shiny":"EISCUE_1.png","speciesKey":"EISCUE:1"},"Ekans":{"normal":"EKANS.png","shiny":"EKANS.png","speciesKey":"EKANS:0"},"Eldegoss":{"normal":"ELDEGOSS.png","shiny":"ELDEGOSS.png","speciesKey":"ELDEGOSS:0"},"Electabuzz":{"normal":"ELECTABUZZ.png","shiny":"ELECTABUZZ.png","speciesKey":"ELECTABUZZ:0"},"Electivire":{"normal":"ELECTIVIRE.png","shiny":"ELECTIVIRE.png","speciesKey":"ELECTIVIRE:0"},"Electrike":{"normal":"ELECTRIKE.png","shiny":"ELECTRIKE.png","speciesKey":"ELECTRIKE:0"},"Electrode":{"normal":"ELECTRODE.png","shiny":"ELECTRODE.png","speciesKey":"ELECTRODE:0"},"Electrode [Hisuian]":{"normal":"ELECTRODE_1.png","shiny":"ELECTRODE_1.png","speciesKey":"ELECTRODE:1"},"Elekid":{"normal":"ELEKID.png","shiny":"ELEKID.png","speciesKey":"ELEKID:0"},"Elgyem":{"normal":"ELGYEM.png","shiny":"ELGYEM.png","speciesKey":"ELGYEM:0"},"Emboar":{"normal":"EMBOAR.png","shiny":"EMBOAR.png","speciesKey":"EMBOAR:0"},"Emboar [Mega Emboar]":{"normal":"EMBOAR_1.png","shiny":"EMBOAR_1.png","speciesKey":"EMBOAR:1"},"Emolga":{"normal":"EMOLGA.png","shiny":"EMOLGA.png","speciesKey":"EMOLGA:0"},"Empoleon":{"normal":"EMPOLEON.png","shiny":"EMPOLEON.png","speciesKey":"EMPOLEON:0"},"Enamorus":{"normal":"ENAMORUS.png","shiny":"ENAMORUS.png","speciesKey":"ENAMORUS:0"},"Enamorus [Therian Form]":{"normal":"ENAMORUS_1.png","shiny":"ENAMORUS_1.png","speciesKey":"ENAMORUS:1"},"Entei":{"normal":"ENTEI.png","shiny":"ENTEI.png","speciesKey":"ENTEI:0"},"Escavalier":{"normal":"ESCAVALIER.png","shiny":"ESCAVALIER.png","speciesKey":"ESCAVALIER:0"},"Espathra":{"normal":"ESPATHRA.png","shiny":"ESPATHRA.png","speciesKey":"ESPATHRA:0"},"Espeon":{"normal":"ESPEON.png","shiny":"ESPEON.png","speciesKey":"ESPEON:0"},"Espurr":{"normal":"ESPURR.png","shiny":"ESPURR.png","speciesKey":"ESPURR:0"},"Eternatus":{"normal":"ETERNATUS.png","shiny":"ETERNATUS.png","speciesKey":"ETERNATUS:0"},"Excadrill":{"normal":"EXCADRILL.png","shiny":"EXCADRILL.png","speciesKey":"EXCADRILL:0"},"Excadrill [Mega Excadrill]":{"normal":"EXCADRILL_1.png","shiny":"EXCADRILL_1.png","speciesKey":"EXCADRILL:1"},"Exeggcute":{"normal":"EXEGGCUTE.png","shiny":"EXEGGCUTE.png","speciesKey":"EXEGGCUTE:0"},"Exeggutor":{"normal":"EXEGGUTOR.png","shiny":"EXEGGUTOR.png","speciesKey":"EXEGGUTOR:0"},"Exeggutor [Alolan]":{"normal":"EXEGGUTOR_1.png","shiny":"EXEGGUTOR_1.png","speciesKey":"EXEGGUTOR:1"},"Exploud":{"normal":"EXPLOUD.png","shiny":"EXPLOUD.png","speciesKey":"EXPLOUD:0"},"Falinks":{"normal":"FALINKS.png","shiny":"FALINKS.png","speciesKey":"FALINKS:0"},"Falinks [Mega Falinks]":{"normal":"FALINKS_1.png","shiny":"FALINKS_1.png","speciesKey":"FALINKS:1"},"Farfetch'd":{"normal":"FARFETCHD.png","shiny":"FARFETCHD.png","speciesKey":"FARFETCHD:0"},"Farfetch'd [Galarian]":{"normal":"FARFETCHD_1.png","shiny":"FARFETCHD_1.png","speciesKey":"FARFETCHD:1"},"Farigiraf":{"normal":"FARIGIRAF.png","shiny":"FARIGIRAF.png","speciesKey":"FARIGIRAF:0"},"Fearow":{"normal":"FEAROW.png","shiny":"FEAROW.png","speciesKey":"FEAROW:0"},"Feebas":{"normal":"FEEBAS.png","shiny":"FEEBAS.png","speciesKey":"FEEBAS:0"},"Fennekin":{"normal":"FENNEKIN.png","shiny":"FENNEKIN.png","speciesKey":"FENNEKIN:0"},"Feraligatr":{"normal":"FERALIGATR.png","shiny":"FERALIGATR.png","speciesKey":"FERALIGATR:0"},"Feraligatr [Mega Feraligatr]":{"normal":"FERALIGATR_1.png","shiny":"FERALIGATR_1.png","speciesKey":"FERALIGATR:1"},"Ferroseed":{"normal":"FERROSEED.png","shiny":"FERROSEED.png","speciesKey":"FERROSEED:0"},"Ferrothorn":{"normal":"FERROTHORN.png","shiny":"FERROTHORN.png","speciesKey":"FERROTHORN:0"},"Fezandipiti":{"normal":"FEZANDIPITI.png","shiny":"FEZANDIPITI.png","speciesKey":"FEZANDIPITI:0"},"Fidough":{"normal":"FIDOUGH.png","shiny":"FIDOUGH.png","speciesKey":"FIDOUGH:0"},"Finizen":{"normal":"FINIZEN.png","shiny":"FINIZEN.png","speciesKey":"FINIZEN:0"},"Finneon":{"normal":"FINNEON.png","shiny":"FINNEON.png","speciesKey":"FINNEON:0"},"Flaaffy":{"normal":"FLAAFFY.png","shiny":"FLAAFFY.png","speciesKey":"FLAAFFY:0"},"Flabébé":{"normal":"FLABEBE.png","shiny":"FLABEBE.png","speciesKey":"FLABEBE:0"},"Flabébé [Yellow Flower]":{"normal":"FLABEBE_1.png","shiny":"FLABEBE_1.png","speciesKey":"FLABEBE:1"},"Flabébé [Orange Flower]":{"normal":"FLABEBE_2.png","shiny":"FLABEBE_2.png","speciesKey":"FLABEBE:2"},"Flabébé [Blue Flower]":{"normal":"FLABEBE_3.png","shiny":"FLABEBE_3.png","speciesKey":"FLABEBE:3"},"Flabébé [White Flower]":{"normal":"FLABEBE_4.png","shiny":"FLABEBE_4.png","speciesKey":"FLABEBE:4"},"Flamigo":{"normal":"FLAMIGO.png","shiny":"FLAMIGO.png","speciesKey":"FLAMIGO:0"},"Flapple":{"normal":"FLAPPLE.png","shiny":"FLAPPLE.png","speciesKey":"FLAPPLE:0"},"Flareon":{"normal":"FLAREON.png","shiny":"FLAREON.png","speciesKey":"FLAREON:0"},"Fletchinder":{"normal":"FLETCHINDER.png","shiny":"FLETCHINDER.png","speciesKey":"FLETCHINDER:0"},"Fletchling":{"normal":"FLETCHLING.png","shiny":"FLETCHLING.png","speciesKey":"FLETCHLING:0"},"Flittle":{"normal":"FLITTLE.png","shiny":"FLITTLE.png","speciesKey":"FLITTLE:0"},"Floatzel":{"normal":"FLOATZEL.png","shiny":"FLOATZEL.png","speciesKey":"FLOATZEL:0"},"Floette":{"normal":"FLOETTE.png","shiny":"FLOETTE.png","speciesKey":"FLOETTE:0"},"Floette [Yellow Flower]":{"normal":"FLOETTE_1.png","shiny":"FLOETTE_1.png","speciesKey":"FLOETTE:1"},"Floette [Orange Flower]":{"normal":"FLOETTE_2.png","shiny":"FLOETTE_2.png","speciesKey":"FLOETTE:2"},"Floette [Blue Flower]":{"normal":"FLOETTE_3.png","shiny":"FLOETTE_3.png","speciesKey":"FLOETTE:3"},"Floette [White Flower]":{"normal":"FLOETTE_4.png","shiny":"FLOETTE_4.png","speciesKey":"FLOETTE:4"},"Floette [Eternal Flower]":{"normal":"FLOETTE.png","shiny":"FLOETTE_5.png","speciesKey":"FLOETTE:5"},"Floette [Mega Floette]":{"normal":"FLOETTE_6.png","shiny":"FLOETTE_6.png","speciesKey":"FLOETTE:6"},"Floragato":{"normal":"FLORAGATO.png","shiny":"FLORAGATO.png","speciesKey":"FLORAGATO:0"},"Florges":{"normal":"FLORGES.png","shiny":"FLORGES.png","speciesKey":"FLORGES:0"},"Florges [Yellow Flower]":{"normal":"FLORGES_1.png","shiny":"FLORGES_1.png","speciesKey":"FLORGES:1"},"Florges [Orange Flower]":{"normal":"FLORGES_2.png","shiny":"FLORGES_2.png","speciesKey":"FLORGES:2"},"Florges [Blue Flower]":{"normal":"FLORGES_3.png","shiny":"FLORGES_3.png","speciesKey":"FLORGES:3"},"Florges [White Flower]":{"normal":"FLORGES_4.png","shiny":"FLORGES_4.png","speciesKey":"FLORGES:4"},"Flutter Mane":{"normal":"FLUTTERMANE.png","shiny":"FLUTTERMANE.png","speciesKey":"FLUTTERMANE:0"},"Flygon":{"normal":"FLYGON.png","shiny":"FLYGON.png","speciesKey":"FLYGON:0"},"Fomantis":{"normal":"FOMANTIS.png","shiny":"FOMANTIS.png","speciesKey":"FOMANTIS:0"},"Foongus":{"normal":"FOONGUS.png","shiny":"FOONGUS.png","speciesKey":"FOONGUS:0"},"Forretress":{"normal":"FORRETRESS.png","shiny":"FORRETRESS.png","speciesKey":"FORRETRESS:0"},"Fraxure":{"normal":"FRAXURE.png","shiny":"FRAXURE.png","speciesKey":"FRAXURE:0"},"Frigibax":{"normal":"FRIGIBAX.png","shiny":"FRIGIBAX.png","speciesKey":"FRIGIBAX:0"},"Frillish":{"normal":"FRILLISH.png","shiny":"FRILLISH.png","speciesKey":"FRILLISH:0"},"Froakie":{"normal":"FROAKIE.png","shiny":"FROAKIE.png","speciesKey":"FROAKIE:0"},"Frogadier":{"normal":"FROGADIER.png","shiny":"FROGADIER.png","speciesKey":"FROGADIER:0"},"Froslass":{"normal":"FROSLASS.png","shiny":"FROSLASS.png","speciesKey":"FROSLASS:0"},"Froslass [Mega Froslass]":{"normal":"FROSLASS_1.png","shiny":"FROSLASS_1.png","speciesKey":"FROSLASS:1"},"Frosmoth":{"normal":"FROSMOTH.png","shiny":"FROSMOTH.png","speciesKey":"FROSMOTH:0"},"Fuecoco":{"normal":"FUECOCO.png","shiny":"FUECOCO.png","speciesKey":"FUECOCO:0"},"Furfrou":{"normal":"FURFROU.png","shiny":"FURFROU.png","speciesKey":"FURFROU:0"},"Furfrou [Heart Trim]":{"normal":"FURFROU_1.png","shiny":"FURFROU_1.png","speciesKey":"FURFROU:1"},"Furfrou [Star Trim]":{"normal":"FURFROU_2.png","shiny":"FURFROU_2.png","speciesKey":"FURFROU:2"},"Furfrou [Diamond Trim]":{"normal":"FURFROU_3.png","shiny":"FURFROU_3.png","speciesKey":"FURFROU:3"},"Furfrou [Debutante Trim]":{"normal":"FURFROU_4.png","shiny":"FURFROU_4.png","speciesKey":"FURFROU:4"},"Furfrou [Matron Trim]":{"normal":"FURFROU_5.png","shiny":"FURFROU_5.png","speciesKey":"FURFROU:5"},"Furfrou [Dandy Trim]":{"normal":"FURFROU_6.png","shiny":"FURFROU_6.png","speciesKey":"FURFROU:6"},"Furfrou [La Reine Trim]":{"normal":"FURFROU_7.png","shiny":"FURFROU_7.png","speciesKey":"FURFROU:7"},"Furfrou [Kabuki Trim]":{"normal":"FURFROU_8.png","shiny":"FURFROU_8.png","speciesKey":"FURFROU:8"},"Furfrou [Pharaoh Trim]":{"normal":"FURFROU_9.png","shiny":"FURFROU_9.png","speciesKey":"FURFROU:9"},"Furret":{"normal":"FURRET.png","shiny":"FURRET.png","speciesKey":"FURRET:0"},"Gabite":{"normal":"GABITE.png","shiny":"GABITE.png","speciesKey":"GABITE:0"},"Gallade":{"normal":"GALLADE.png","shiny":"GALLADE.png","speciesKey":"GALLADE:0"},"Gallade [Mega Gallade]":{"normal":"GALLADE_1.png","shiny":"GALLADE_1.png","speciesKey":"GALLADE:1"},"Galvantula":{"normal":"GALVANTULA.png","shiny":"GALVANTULA.png","speciesKey":"GALVANTULA:0"},"Garbodor":{"normal":"GARBODOR.png","shiny":"GARBODOR.png","speciesKey":"GARBODOR:0"},"Garchomp":{"normal":"GARCHOMP.png","shiny":"GARCHOMP.png","speciesKey":"GARCHOMP:0"},"Garchomp [Mega Garchomp]":{"normal":"GARCHOMP_1.png","shiny":"GARCHOMP_1.png","speciesKey":"GARCHOMP:1"},"Garchomp [Mega Garchomp Z]":{"normal":"GARCHOMP_2.png","shiny":"GARCHOMP_2.png","speciesKey":"GARCHOMP:2"},"Gardevoir":{"normal":"GARDEVOIR.png","shiny":"GARDEVOIR.png","speciesKey":"GARDEVOIR:0"},"Gardevoir [Mega Gardevoir]":{"normal":"GARDEVOIR_1.png","shiny":"GARDEVOIR_1.png","speciesKey":"GARDEVOIR:1"},"Garganacl":{"normal":"GARGANACL.png","shiny":"GARGANACL.png","speciesKey":"GARGANACL:0"},"Gastly":{"normal":"GASTLY.png","shiny":"GASTLY.png","speciesKey":"GASTLY:0"},"Gastrodon":{"normal":"GASTRODON.png","shiny":"GASTRODON.png","speciesKey":"GASTRODON:0"},"Gastrodon [East Sea]":{"normal":"GASTRODON_1.png","shiny":"GASTRODON_1.png","speciesKey":"GASTRODON:1"},"Genesect":{"normal":"GENESECT.png","shiny":"GENESECT.png","speciesKey":"GENESECT:0"},"Genesect [Shock Drive]":{"normal":"GENESECT.png","shiny":"GENESECT.png","speciesKey":"GENESECT:1"},"Genesect [Burn Drive]":{"normal":"GENESECT.png","shiny":"GENESECT.png","speciesKey":"GENESECT:2"},"Genesect [Chill Drive]":{"normal":"GENESECT.png","shiny":"GENESECT.png","speciesKey":"GENESECT:3"},"Genesect [Douse Drive]":{"normal":"GENESECT.png","shiny":"GENESECT.png","speciesKey":"GENESECT:4"},"Gengar":{"normal":"GENGAR.png","shiny":"GENGAR.png","speciesKey":"GENGAR:0"},"Gengar [Mega Gengar]":{"normal":"GENGAR_1.png","shiny":"GENGAR_1.png","speciesKey":"GENGAR:1"},"Geodude":{"normal":"GEODUDE.png","shiny":"GEODUDE.png","speciesKey":"GEODUDE:0"},"Geodude [Alolan]":{"normal":"GEODUDE_1.png","shiny":"GEODUDE_1.png","speciesKey":"GEODUDE:1"},"Gholdengo":{"normal":"GHOLDENGO.png","shiny":"GHOLDENGO.png","speciesKey":"GHOLDENGO:0"},"Gible":{"normal":"GIBLE.png","shiny":"GIBLE.png","speciesKey":"GIBLE:0"},"Gigalith":{"normal":"GIGALITH.png","shiny":"GIGALITH.png","speciesKey":"GIGALITH:0"},"Gimmighoul":{"normal":"GIMMIGHOUL.png","shiny":"GIMMIGHOUL.png","speciesKey":"GIMMIGHOUL:0"},"Gimmighoul [Roaming Form]":{"normal":"GIMMIGHOUL_1.png","shiny":"GIMMIGHOUL_1.png","speciesKey":"GIMMIGHOUL:1"},"Girafarig":{"normal":"GIRAFARIG.png","shiny":"GIRAFARIG.png","speciesKey":"GIRAFARIG:0"},"Giratina":{"normal":"GIRATINA.png","shiny":"GIRATINA.png","speciesKey":"GIRATINA:0"},"Giratina [Origin Forme]":{"normal":"GIRATINA_1.png","shiny":"GIRATINA_1.png","speciesKey":"GIRATINA:1"},"Glaceon":{"normal":"GLACEON.png","shiny":"GLACEON.png","speciesKey":"GLACEON:0"},"Glalie":{"normal":"GLALIE.png","shiny":"GLALIE.png","speciesKey":"GLALIE:0"},"Glalie [Mega Glalie]":{"normal":"GLALIE_1.png","shiny":"GLALIE_1.png","speciesKey":"GLALIE:1"},"Glameow":{"normal":"GLAMEOW.png","shiny":"GLAMEOW.png","speciesKey":"GLAMEOW:0"},"Glastrier":{"normal":"GLASTRIER.png","shiny":"GLASTRIER.png","speciesKey":"GLASTRIER:0"},"Gligar":{"normal":"GLIGAR.png","shiny":"GLIGAR.png","speciesKey":"GLIGAR:0"},"Glimmet":{"normal":"GLIMMET.png","shiny":"GLIMMET.png","speciesKey":"GLIMMET:0"},"Glimmora":{"normal":"GLIMMORA.png","shiny":"GLIMMORA.png","speciesKey":"GLIMMORA:0"},"Glimmora [Mega Glimmora]":{"normal":"GLIMMORA_1.png","shiny":"GLIMMORA_1.png","speciesKey":"GLIMMORA:1"},"Gliscor":{"normal":"GLISCOR.png","shiny":"GLISCOR.png","speciesKey":"GLISCOR:0"},"Gloom":{"normal":"GLOOM.png","shiny":"GLOOM.png","speciesKey":"GLOOM:0"},"Gogoat":{"normal":"GOGOAT.png","shiny":"GOGOAT.png","speciesKey":"GOGOAT:0"},"Golbat":{"normal":"GOLBAT.png","shiny":"GOLBAT.png","speciesKey":"GOLBAT:0"},"Goldeen":{"normal":"GOLDEEN.png","shiny":"GOLDEEN.png","speciesKey":"GOLDEEN:0"},"Golduck":{"normal":"GOLDUCK.png","shiny":"GOLDUCK.png","speciesKey":"GOLDUCK:0"},"Golem":{"normal":"GOLEM.png","shiny":"GOLEM.png","speciesKey":"GOLEM:0"},"Golem [Alolan]":{"normal":"GOLEM_1.png","shiny":"GOLEM_1.png","speciesKey":"GOLEM:1"},"Golett":{"normal":"GOLETT.png","shiny":"GOLETT.png","speciesKey":"GOLETT:0"},"Golisopod":{"normal":"GOLISOPOD.png","shiny":"GOLISOPOD.png","speciesKey":"GOLISOPOD:0"},"Golisopod [Mega Golisopod]":{"normal":"GOLISOPOD_1.png","shiny":"GOLISOPOD_1.png","speciesKey":"GOLISOPOD:1"},"Golurk":{"normal":"GOLURK.png","shiny":"GOLURK.png","speciesKey":"GOLURK:0"},"Golurk [Mega Golurk]":{"normal":"GOLURK_1.png","shiny":"GOLURK_1.png","speciesKey":"GOLURK:1"},"Goodra":{"normal":"GOODRA.png","shiny":"GOODRA.png","speciesKey":"GOODRA:0"},"Goodra [Hisuian]":{"normal":"GOODRA_1.png","shiny":"GOODRA_1.png","speciesKey":"GOODRA:1"},"Goomy":{"normal":"GOOMY.png","shiny":"GOOMY.png","speciesKey":"GOOMY:0"},"Gorebyss":{"normal":"GOREBYSS.png","shiny":"GOREBYSS.png","speciesKey":"GOREBYSS:0"},"Gossifleur":{"normal":"GOSSIFLEUR.png","shiny":"GOSSIFLEUR.png","speciesKey":"GOSSIFLEUR:0"},"Gothita":{"normal":"GOTHITA.png","shiny":"GOTHITA.png","speciesKey":"GOTHITA:0"},"Gothitelle":{"normal":"GOTHITELLE.png","shiny":"GOTHITELLE.png","speciesKey":"GOTHITELLE:0"},"Gothorita":{"normal":"GOTHORITA.png","shiny":"GOTHORITA.png","speciesKey":"GOTHORITA:0"},"Gouging Fire":{"normal":"GOUGINGFIRE.png","shiny":"GOUGINGFIRE.png","speciesKey":"GOUGINGFIRE:0"},"Gourgeist":{"normal":"GOURGEIST.png","shiny":"GOURGEIST.png","speciesKey":"GOURGEIST:0"},"Gourgeist [Average Size]":{"normal":"GOURGEIST.png","shiny":"GOURGEIST.png","speciesKey":"GOURGEIST:1"},"Gourgeist [Large Size]":{"normal":"GOURGEIST.png","shiny":"GOURGEIST.png","speciesKey":"GOURGEIST:2"},"Gourgeist [Super Size]":{"normal":"GOURGEIST.png","shiny":"GOURGEIST.png","speciesKey":"GOURGEIST:3"},"Grafaiai":{"normal":"GRAFAIAI.png","shiny":"GRAFAIAI.png","speciesKey":"GRAFAIAI:0"},"Granbull":{"normal":"GRANBULL.png","shiny":"GRANBULL.png","speciesKey":"GRANBULL:0"},"Grapploct":{"normal":"GRAPPLOCT.png","shiny":"GRAPPLOCT.png","speciesKey":"GRAPPLOCT:0"},"Graveler":{"normal":"GRAVELER.png","shiny":"GRAVELER.png","speciesKey":"GRAVELER:0"},"Graveler [Alolan]":{"normal":"GRAVELER_1.png","shiny":"GRAVELER_1.png","speciesKey":"GRAVELER:1"},"Great Tusk":{"normal":"GREATTUSK.png","shiny":"GREATTUSK.png","speciesKey":"GREATTUSK:0"},"Greavard":{"normal":"GREAVARD.png","shiny":"GREAVARD.png","speciesKey":"GREAVARD:0"},"Greedent":{"normal":"GREEDENT.png","shiny":"GREEDENT.png","speciesKey":"GREEDENT:0"},"Greninja":{"normal":"GRENINJA.png","shiny":"GRENINJA.png","speciesKey":"GRENINJA:0"},"Greninja [Form 1]":{"normal":"GRENINJA.png","shiny":"GRENINJA.png","speciesKey":"GRENINJA:1"},"Greninja [Ash-Greninja]":{"normal":"GRENINJA_2.png","shiny":"GRENINJA_2.png","speciesKey":"GRENINJA:2"},"Greninja [Mega Greninja]":{"normal":"GRENINJA_3.png","shiny":"GRENINJA_3.png","speciesKey":"GRENINJA:3"},"Grimer":{"normal":"GRIMER.png","shiny":"GRIMER.png","speciesKey":"GRIMER:0"},"Grimer [Alolan]":{"normal":"GRIMER_1.png","shiny":"GRIMER_1.png","speciesKey":"GRIMER:1"},"Grimmsnarl":{"normal":"GRIMMSNARL.png","shiny":"GRIMMSNARL.png","speciesKey":"GRIMMSNARL:0"},"Grookey":{"normal":"GROOKEY.png","shiny":"GROOKEY.png","speciesKey":"GROOKEY:0"},"Grotle":{"normal":"GROTLE.png","shiny":"GROTLE.png","speciesKey":"GROTLE:0"},"Groudon":{"normal":"GROUDON.png","shiny":"GROUDON.png","speciesKey":"GROUDON:0"},"Groudon [Primal Groudon]":{"normal":"GROUDON_1.png","shiny":"GROUDON_1.png","speciesKey":"GROUDON:1"},"Grovyle":{"normal":"GROVYLE.png","shiny":"GROVYLE.png","speciesKey":"GROVYLE:0"},"Growlithe":{"normal":"GROWLITHE.png","shiny":"GROWLITHE.png","speciesKey":"GROWLITHE:0"},"Growlithe [Hisuian]":{"normal":"GROWLITHE_1.png","shiny":"GROWLITHE_1.png","speciesKey":"GROWLITHE:1"},"Grubbin":{"normal":"GRUBBIN.png","shiny":"GRUBBIN.png","speciesKey":"GRUBBIN:0"},"Grumpig":{"normal":"GRUMPIG.png","shiny":"GRUMPIG.png","speciesKey":"GRUMPIG:0"},"Gulpin":{"normal":"GULPIN.png","shiny":"GULPIN.png","speciesKey":"GULPIN:0"},"Gumshoos":{"normal":"GUMSHOOS.png","shiny":"GUMSHOOS.png","speciesKey":"GUMSHOOS:0"},"Gurdurr":{"normal":"GURDURR.png","shiny":"GURDURR.png","speciesKey":"GURDURR:0"},"Guzzlord":{"normal":"GUZZLORD.png","shiny":"GUZZLORD.png","speciesKey":"GUZZLORD:0"},"Gyarados":{"normal":"GYARADOS.png","shiny":"GYARADOS.png","speciesKey":"GYARADOS:0"},"Gyarados [Mega Gyarados]":{"normal":"GYARADOS_1.png","shiny":"GYARADOS_1.png","speciesKey":"GYARADOS:1"},"Hakamo-o":{"normal":"HAKAMOO.png","shiny":"HAKAMOO.png","speciesKey":"HAKAMOO:0"},"Happiny":{"normal":"HAPPINY.png","shiny":"HAPPINY.png","speciesKey":"HAPPINY:0"},"Hariyama":{"normal":"HARIYAMA.png","shiny":"HARIYAMA.png","speciesKey":"HARIYAMA:0"},"Hatenna":{"normal":"HATENNA.png","shiny":"HATENNA.png","speciesKey":"HATENNA:0"},"Hatterene":{"normal":"HATTERENE.png","shiny":"HATTERENE.png","speciesKey":"HATTERENE:0"},"Hattrem":{"normal":"HATTREM.png","shiny":"HATTREM.png","speciesKey":"HATTREM:0"},"Haunter":{"normal":"HAUNTER.png","shiny":"HAUNTER.png","speciesKey":"HAUNTER:0"},"Hawlucha":{"normal":"HAWLUCHA.png","shiny":"HAWLUCHA.png","speciesKey":"HAWLUCHA:0"},"Hawlucha [Mega Hawlucha]":{"normal":"HAWLUCHA_1.png","shiny":"HAWLUCHA_1.png","speciesKey":"HAWLUCHA:1"},"Haxorus":{"normal":"HAXORUS.png","shiny":"HAXORUS.png","speciesKey":"HAXORUS:0"},"Heatmor":{"normal":"HEATMOR.png","shiny":"HEATMOR.png","speciesKey":"HEATMOR:0"},"Heatran":{"normal":"HEATRAN.png","shiny":"HEATRAN.png","speciesKey":"HEATRAN:0"},"Heatran [Mega Heatran]":{"normal":"HEATRAN_1.png","shiny":"HEATRAN_1.png","speciesKey":"HEATRAN:1"},"Heliolisk":{"normal":"HELIOLISK.png","shiny":"HELIOLISK.png","speciesKey":"HELIOLISK:0"},"Helioptile":{"normal":"HELIOPTILE.png","shiny":"HELIOPTILE.png","speciesKey":"HELIOPTILE:0"},"Heracross":{"normal":"HERACROSS.png","shiny":"HERACROSS.png","speciesKey":"HERACROSS:0"},"Heracross [Mega Heracross]":{"normal":"HERACROSS_1.png","shiny":"HERACROSS_1.png","speciesKey":"HERACROSS:1"},"Herdier":{"normal":"HERDIER.png","shiny":"HERDIER.png","speciesKey":"HERDIER:0"},"Hippopotas":{"normal":"HIPPOPOTAS.png","shiny":"HIPPOPOTAS.png","speciesKey":"HIPPOPOTAS:0"},"Hippowdon":{"normal":"HIPPOWDON.png","shiny":"HIPPOWDON.png","speciesKey":"HIPPOWDON:0"},"Hitmonchan":{"normal":"HITMONCHAN.png","shiny":"HITMONCHAN.png","speciesKey":"HITMONCHAN:0"},"Hitmonlee":{"normal":"HITMONLEE.png","shiny":"HITMONLEE.png","speciesKey":"HITMONLEE:0"},"Hitmontop":{"normal":"HITMONTOP.png","shiny":"HITMONTOP.png","speciesKey":"HITMONTOP:0"},"Honchkrow":{"normal":"HONCHKROW.png","shiny":"HONCHKROW.png","speciesKey":"HONCHKROW:0"},"Honedge":{"normal":"HONEDGE.png","shiny":"HONEDGE.png","speciesKey":"HONEDGE:0"},"Ho-Oh":{"normal":"HOOH.png","shiny":"HOOH.png","speciesKey":"HOOH:0"},"Hoopa":{"normal":"HOOPA.png","shiny":"HOOPA.png","speciesKey":"HOOPA:0"},"Hoopa [Hoopa Unbound]":{"normal":"HOOPA_1.png","shiny":"HOOPA_1.png","speciesKey":"HOOPA:1"},"Hoothoot":{"normal":"HOOTHOOT.png","shiny":"HOOTHOOT.png","speciesKey":"HOOTHOOT:0"},"Hoppip":{"normal":"HOPPIP.png","shiny":"HOPPIP.png","speciesKey":"HOPPIP:0"},"Horsea":{"normal":"HORSEA.png","shiny":"HORSEA.png","speciesKey":"HORSEA:0"},"Houndoom":{"normal":"HOUNDOOM.png","shiny":"HOUNDOOM.png","speciesKey":"HOUNDOOM:0"},"Houndoom [Mega Houndoom]":{"normal":"HOUNDOOM_1.png","shiny":"HOUNDOOM_1.png","speciesKey":"HOUNDOOM:1"},"Houndour":{"normal":"HOUNDOUR.png","shiny":"HOUNDOUR.png","speciesKey":"HOUNDOUR:0"},"Houndstone":{"normal":"HOUNDSTONE.png","shiny":"HOUNDSTONE.png","speciesKey":"HOUNDSTONE:0"},"Huntail":{"normal":"HUNTAIL.png","shiny":"HUNTAIL.png","speciesKey":"HUNTAIL:0"},"Hydrapple":{"normal":"HYDRAPPLE.png","shiny":"HYDRAPPLE.png","speciesKey":"HYDRAPPLE:0"},"Hydreigon":{"normal":"HYDREIGON.png","shiny":"HYDREIGON.png","speciesKey":"HYDREIGON:0"},"Hypno":{"normal":"HYPNO.png","shiny":"HYPNO.png","speciesKey":"HYPNO:0"},"Igglybuff":{"normal":"IGGLYBUFF.png","shiny":"IGGLYBUFF.png","speciesKey":"IGGLYBUFF:0"},"Illumise":{"normal":"ILLUMISE.png","shiny":"ILLUMISE.png","speciesKey":"ILLUMISE:0"},"Impidimp":{"normal":"IMPIDIMP.png","shiny":"IMPIDIMP.png","speciesKey":"IMPIDIMP:0"},"Incineroar":{"normal":"INCINEROAR.png","shiny":"INCINEROAR.png","speciesKey":"INCINEROAR:0"},"Indeedee":{"normal":"INDEEDEE.png","shiny":"INDEEDEE.png","speciesKey":"INDEEDEE:0"},"Indeedee [Female]":{"normal":"INDEEDEE_1.png","shiny":"INDEEDEE_1.png","speciesKey":"INDEEDEE:1"},"Infernape":{"normal":"INFERNAPE.png","shiny":"INFERNAPE.png","speciesKey":"INFERNAPE:0"},"Inkay":{"normal":"INKAY.png","shiny":"INKAY.png","speciesKey":"INKAY:0"},"Inteleon":{"normal":"INTELEON.png","shiny":"INTELEON.png","speciesKey":"INTELEON:0"},"Iron Boulder":{"normal":"IRONBOULDER.png","shiny":"IRONBOULDER.png","speciesKey":"IRONBOULDER:0"},"Iron Bundle":{"normal":"IRONBUNDLE.png","shiny":"IRONBUNDLE.png","speciesKey":"IRONBUNDLE:0"},"Iron Crown":{"normal":"IRONCROWN.png","shiny":"IRONCROWN.png","speciesKey":"IRONCROWN:0"},"Iron Hands":{"normal":"IRONHANDS.png","shiny":"IRONHANDS.png","speciesKey":"IRONHANDS:0"},"Iron Jugulis":{"normal":"IRONJUGULIS.png","shiny":"IRONJUGULIS.png","speciesKey":"IRONJUGULIS:0"},"Iron Leaves":{"normal":"IRONLEAVES.png","shiny":"IRONLEAVES.png","speciesKey":"IRONLEAVES:0"},"Iron Moth":{"normal":"IRONMOTH.png","shiny":"IRONMOTH.png","speciesKey":"IRONMOTH:0"},"Iron Thorns":{"normal":"IRONTHORNS.png","shiny":"IRONTHORNS.png","speciesKey":"IRONTHORNS:0"},"Iron Treads":{"normal":"IRONTREADS.png","shiny":"IRONTREADS.png","speciesKey":"IRONTREADS:0"},"Iron Valiant":{"normal":"IRONVALIANT.png","shiny":"IRONVALIANT.png","speciesKey":"IRONVALIANT:0"},"Ivysaur":{"normal":"IVYSAUR.png","shiny":"IVYSAUR.png","speciesKey":"IVYSAUR:0"},"Jangmo-o":{"normal":"JANGMOO.png","shiny":"JANGMOO.png","speciesKey":"JANGMOO:0"},"Jellicent":{"normal":"JELLICENT.png","shiny":"JELLICENT.png","speciesKey":"JELLICENT:0"},"Jigglypuff":{"normal":"JIGGLYPUFF.png","shiny":"JIGGLYPUFF.png","speciesKey":"JIGGLYPUFF:0"},"Jirachi":{"normal":"JIRACHI.png","shiny":"JIRACHI.png","speciesKey":"JIRACHI:0"},"Jolteon":{"normal":"JOLTEON.png","shiny":"JOLTEON.png","speciesKey":"JOLTEON:0"},"Joltik":{"normal":"JOLTIK.png","shiny":"JOLTIK.png","speciesKey":"JOLTIK:0"},"Jumpluff":{"normal":"JUMPLUFF.png","shiny":"JUMPLUFF.png","speciesKey":"JUMPLUFF:0"},"Jynx":{"normal":"JYNX.png","shiny":"JYNX.png","speciesKey":"JYNX:0"},"Kabuto":{"normal":"KABUTO.png","shiny":"KABUTO.png","speciesKey":"KABUTO:0"},"Kabutops":{"normal":"KABUTOPS.png","shiny":"KABUTOPS.png","speciesKey":"KABUTOPS:0"},"Kadabra":{"normal":"KADABRA.png","shiny":"KADABRA.png","speciesKey":"KADABRA:0"},"Kakuna":{"normal":"KAKUNA.png","shiny":"KAKUNA.png","speciesKey":"KAKUNA:0"},"Kangaskhan":{"normal":"KANGASKHAN.png","shiny":"KANGASKHAN.png","speciesKey":"KANGASKHAN:0"},"Kangaskhan [Mega Kangaskhan]":{"normal":"KANGASKHAN_1.png","shiny":"KANGASKHAN_1.png","speciesKey":"KANGASKHAN:1"},"Karrablast":{"normal":"KARRABLAST.png","shiny":"KARRABLAST.png","speciesKey":"KARRABLAST:0"},"Kartana":{"normal":"KARTANA.png","shiny":"KARTANA.png","speciesKey":"KARTANA:0"},"Kecleon":{"normal":"KECLEON.png","shiny":"KECLEON.png","speciesKey":"KECLEON:0"},"Keldeo":{"normal":"KELDEO.png","shiny":"KELDEO.png","speciesKey":"KELDEO:0"},"Keldeo [Resolute Form]":{"normal":"KELDEO_1.png","shiny":"KELDEO_1.png","speciesKey":"KELDEO:1"},"Kilowattrel":{"normal":"KILOWATTREL.png","shiny":"KILOWATTREL.png","speciesKey":"KILOWATTREL:0"},"Kingambit":{"normal":"KINGAMBIT.png","shiny":"KINGAMBIT.png","speciesKey":"KINGAMBIT:0"},"Kingdra":{"normal":"KINGDRA.png","shiny":"KINGDRA.png","speciesKey":"KINGDRA:0"},"Kingler":{"normal":"KINGLER.png","shiny":"KINGLER.png","speciesKey":"KINGLER:0"},"Kirlia":{"normal":"KIRLIA.png","shiny":"KIRLIA.png","speciesKey":"KIRLIA:0"},"Klang":{"normal":"KLANG.png","shiny":"KLANG.png","speciesKey":"KLANG:0"},"Klawf":{"normal":"KLAWF.png","shiny":"KLAWF.png","speciesKey":"KLAWF:0"},"Kleavor":{"normal":"KLEAVOR.png","shiny":"KLEAVOR.png","speciesKey":"KLEAVOR:0"},"Klefki":{"normal":"KLEFKI.png","shiny":"KLEFKI.png","speciesKey":"KLEFKI:0"},"Klink":{"normal":"KLINK.png","shiny":"KLINK.png","speciesKey":"KLINK:0"},"Klinklang":{"normal":"KLINKLANG.png","shiny":"KLINKLANG.png","speciesKey":"KLINKLANG:0"},"Koffing":{"normal":"KOFFING.png","shiny":"KOFFING.png","speciesKey":"KOFFING:0"},"Komala":{"normal":"KOMALA.png","shiny":"KOMALA.png","speciesKey":"KOMALA:0"},"Kommo-o":{"normal":"KOMMOO.png","shiny":"KOMMOO.png","speciesKey":"KOMMOO:0"},"Koraidon":{"normal":"KORAIDON.png","shiny":"KORAIDON.png","speciesKey":"KORAIDON:0"},"Krabby":{"normal":"KRABBY.png","shiny":"KRABBY.png","speciesKey":"KRABBY:0"},"Kricketot":{"normal":"KRICKETOT.png","shiny":"KRICKETOT.png","speciesKey":"KRICKETOT:0"},"Kricketune":{"normal":"KRICKETUNE.png","shiny":"KRICKETUNE.png","speciesKey":"KRICKETUNE:0"},"Krokorok":{"normal":"KROKOROK.png","shiny":"KROKOROK.png","speciesKey":"KROKOROK:0"},"Krookodile":{"normal":"KROOKODILE.png","shiny":"KROOKODILE.png","speciesKey":"KROOKODILE:0"},"Kubfu":{"normal":"KUBFU.png","shiny":"KUBFU.png","speciesKey":"KUBFU:0"},"Kyogre":{"normal":"KYOGRE.png","shiny":"KYOGRE.png","speciesKey":"KYOGRE:0"},"Kyogre [Primal Kyogre]":{"normal":"KYOGRE_1.png","shiny":"KYOGRE_1.png","speciesKey":"KYOGRE:1"},"Kyurem":{"normal":"KYUREM.png","shiny":"KYUREM.png","speciesKey":"KYUREM:0"},"Kyurem [White Kyurem]":{"normal":"KYUREM_1.png","shiny":"KYUREM_1.png","speciesKey":"KYUREM:1"},"Kyurem [Black Kyurem]":{"normal":"KYUREM_2.png","shiny":"KYUREM_2.png","speciesKey":"KYUREM:2"},"Kyurem [Form 3]":{"normal":"KYUREM_3.png","shiny":"KYUREM_3.png","speciesKey":"KYUREM:3"},"Kyurem [Form 4]":{"normal":"KYUREM_4.png","shiny":"KYUREM_4.png","speciesKey":"KYUREM:4"},"Lairon":{"normal":"LAIRON.png","shiny":"LAIRON.png","speciesKey":"LAIRON:0"},"Lampent":{"normal":"LAMPENT.png","shiny":"LAMPENT.png","speciesKey":"LAMPENT:0"},"Landorus":{"normal":"LANDORUS.png","shiny":"LANDORUS.png","speciesKey":"LANDORUS:0"},"Landorus [Therian Forme]":{"normal":"LANDORUS_1.png","shiny":"LANDORUS_1.png","speciesKey":"LANDORUS:1"},"Lanturn":{"normal":"LANTURN.png","shiny":"LANTURN.png","speciesKey":"LANTURN:0"},"Lapras":{"normal":"LAPRAS.png","shiny":"LAPRAS.png","speciesKey":"LAPRAS:0"},"Larvesta":{"normal":"LARVESTA.png","shiny":"LARVESTA.png","speciesKey":"LARVESTA:0"},"Larvitar":{"normal":"LARVITAR.png","shiny":"LARVITAR.png","speciesKey":"LARVITAR:0"},"Latias":{"normal":"LATIAS.png","shiny":"LATIAS.png","speciesKey":"LATIAS:0"},"Latias [Mega Latias]":{"normal":"LATIAS_1.png","shiny":"LATIAS_1.png","speciesKey":"LATIAS:1"},"Latios":{"normal":"LATIOS.png","shiny":"LATIOS.png","speciesKey":"LATIOS:0"},"Latios [Mega Latios]":{"normal":"LATIOS_1.png","shiny":"LATIOS_1.png","speciesKey":"LATIOS:1"},"Leafeon":{"normal":"LEAFEON.png","shiny":"LEAFEON.png","speciesKey":"LEAFEON:0"},"Leavanny":{"normal":"LEAVANNY.png","shiny":"LEAVANNY.png","speciesKey":"LEAVANNY:0"},"Lechonk":{"normal":"LECHONK.png","shiny":"LECHONK.png","speciesKey":"LECHONK:0"},"Ledian":{"normal":"LEDIAN.png","shiny":"LEDIAN.png","speciesKey":"LEDIAN:0"},"Ledyba":{"normal":"LEDYBA.png","shiny":"LEDYBA.png","speciesKey":"LEDYBA:0"},"Lickilicky":{"normal":"LICKILICKY.png","shiny":"LICKILICKY.png","speciesKey":"LICKILICKY:0"},"Lickitung":{"normal":"LICKITUNG.png","shiny":"LICKITUNG.png","speciesKey":"LICKITUNG:0"},"Liepard":{"normal":"LIEPARD.png","shiny":"LIEPARD.png","speciesKey":"LIEPARD:0"},"Lileep":{"normal":"LILEEP.png","shiny":"LILEEP.png","speciesKey":"LILEEP:0"},"Lilligant":{"normal":"LILLIGANT.png","shiny":"LILLIGANT.png","speciesKey":"LILLIGANT:0"},"Lilligant [Hisuian]":{"normal":"LILLIGANT_1.png","shiny":"LILLIGANT_1.png","speciesKey":"LILLIGANT:1"},"Lillipup":{"normal":"LILLIPUP.png","shiny":"LILLIPUP.png","speciesKey":"LILLIPUP:0"},"Linoone":{"normal":"LINOONE.png","shiny":"LINOONE.png","speciesKey":"LINOONE:0"},"Linoone [Galarian]":{"normal":"LINOONE_1.png","shiny":"LINOONE_1.png","speciesKey":"LINOONE:1"},"Litleo":{"normal":"LITLEO.png","shiny":"LITLEO.png","speciesKey":"LITLEO:0"},"Litten":{"normal":"LITTEN.png","shiny":"LITTEN.png","speciesKey":"LITTEN:0"},"Litwick":{"normal":"LITWICK.png","shiny":"LITWICK.png","speciesKey":"LITWICK:0"},"Lokix":{"normal":"LOKIX.png","shiny":"LOKIX.png","speciesKey":"LOKIX:0"},"Lombre":{"normal":"LOMBRE.png","shiny":"LOMBRE.png","speciesKey":"LOMBRE:0"},"Lopunny":{"normal":"LOPUNNY.png","shiny":"LOPUNNY.png","speciesKey":"LOPUNNY:0"},"Lopunny [Mega Lopunny]":{"normal":"LOPUNNY_1.png","shiny":"LOPUNNY_1.png","speciesKey":"LOPUNNY:1"},"Lotad":{"normal":"LOTAD.png","shiny":"LOTAD.png","speciesKey":"LOTAD:0"},"Loudred":{"normal":"LOUDRED.png","shiny":"LOUDRED.png","speciesKey":"LOUDRED:0"},"Lucario":{"normal":"LUCARIO.png","shiny":"LUCARIO.png","speciesKey":"LUCARIO:0"},"Lucario [Mega Lucario]":{"normal":"LUCARIO_1.png","shiny":"LUCARIO_1.png","speciesKey":"LUCARIO:1"},"Lucario [Mega Lucario Z]":{"normal":"LUCARIO_2.png","shiny":"LUCARIO_2.png","speciesKey":"LUCARIO:2"},"Ludicolo":{"normal":"LUDICOLO.png","shiny":"LUDICOLO.png","speciesKey":"LUDICOLO:0"},"Lugia":{"normal":"LUGIA.png","shiny":"LUGIA.png","speciesKey":"LUGIA:0"},"Lumineon":{"normal":"LUMINEON.png","shiny":"LUMINEON.png","speciesKey":"LUMINEON:0"},"Lunala":{"normal":"LUNALA.png","shiny":"LUNALA.png","speciesKey":"LUNALA:0"},"Lunatone":{"normal":"LUNATONE.png","shiny":"LUNATONE.png","speciesKey":"LUNATONE:0"},"Lurantis":{"normal":"LURANTIS.png","shiny":"LURANTIS.png","speciesKey":"LURANTIS:0"},"Luvdisc":{"normal":"LUVDISC.png","shiny":"LUVDISC.png","speciesKey":"LUVDISC:0"},"Luxio":{"normal":"LUXIO.png","shiny":"LUXIO.png","speciesKey":"LUXIO:0"},"Luxray":{"normal":"LUXRAY.png","shiny":"LUXRAY.png","speciesKey":"LUXRAY:0"},"Lycanroc":{"normal":"LYCANROC.png","shiny":"LYCANROC.png","speciesKey":"LYCANROC:0"},"Lycanroc [Midnight Form]":{"normal":"LYCANROC_1.png","shiny":"LYCANROC_1.png","speciesKey":"LYCANROC:1"},"Lycanroc [Dusk Form]":{"normal":"LYCANROC_2.png","shiny":"LYCANROC_2.png","speciesKey":"LYCANROC:2"},"Mabosstiff":{"normal":"MABOSSTIFF.png","shiny":"MABOSSTIFF.png","speciesKey":"MABOSSTIFF:0"},"Machamp":{"normal":"MACHAMP.png","shiny":"MACHAMP.png","speciesKey":"MACHAMP:0"},"Machoke":{"normal":"MACHOKE.png","shiny":"MACHOKE.png","speciesKey":"MACHOKE:0"},"Machop":{"normal":"MACHOP.png","shiny":"MACHOP.png","speciesKey":"MACHOP:0"},"Magby":{"normal":"MAGBY.png","shiny":"MAGBY.png","speciesKey":"MAGBY:0"},"Magcargo":{"normal":"MAGCARGO.png","shiny":"MAGCARGO.png","speciesKey":"MAGCARGO:0"},"Magearna":{"normal":"MAGEARNA.png","shiny":"MAGEARNA.png","speciesKey":"MAGEARNA:0"},"Magearna [Original Color]":{"normal":"MAGEARNA_1.png","shiny":"MAGEARNA_1.png","speciesKey":"MAGEARNA:1"},"Magearna [Mega Magearna]":{"normal":"MAGEARNA_2.png","shiny":"MAGEARNA_2.png","speciesKey":"MAGEARNA:2"},"Magearna [Mega Magearna (Original Color)]":{"normal":"MAGEARNA_3.png","shiny":"MAGEARNA_3.png","speciesKey":"MAGEARNA:3"},"Magikarp":{"normal":"MAGIKARP.png","shiny":"MAGIKARP.png","speciesKey":"MAGIKARP:0"},"Magmar":{"normal":"MAGMAR.png","shiny":"MAGMAR.png","speciesKey":"MAGMAR:0"},"Magmortar":{"normal":"MAGMORTAR.png","shiny":"MAGMORTAR.png","speciesKey":"MAGMORTAR:0"},"Magnemite":{"normal":"MAGNEMITE.png","shiny":"MAGNEMITE.png","speciesKey":"MAGNEMITE:0"},"Magneton":{"normal":"MAGNETON.png","shiny":"MAGNETON.png","speciesKey":"MAGNETON:0"},"Magnezone":{"normal":"MAGNEZONE.png","shiny":"MAGNEZONE.png","speciesKey":"MAGNEZONE:0"},"Makuhita":{"normal":"MAKUHITA.png","shiny":"MAKUHITA.png","speciesKey":"MAKUHITA:0"},"Malamar":{"normal":"MALAMAR.png","shiny":"MALAMAR.png","speciesKey":"MALAMAR:0"},"Malamar [Mega Malamar]":{"normal":"MALAMAR_1.png","shiny":"MALAMAR_1.png","speciesKey":"MALAMAR:1"},"Mamoswine":{"normal":"MAMOSWINE.png","shiny":"MAMOSWINE.png","speciesKey":"MAMOSWINE:0"},"Manaphy":{"normal":"MANAPHY.png","shiny":"MANAPHY.png","speciesKey":"MANAPHY:0"},"Mandibuzz":{"normal":"MANDIBUZZ.png","shiny":"MANDIBUZZ.png","speciesKey":"MANDIBUZZ:0"},"Manectric":{"normal":"MANECTRIC.png","shiny":"MANECTRIC.png","speciesKey":"MANECTRIC:0"},"Manectric [Mega Manectric]":{"normal":"MANECTRIC_1.png","shiny":"MANECTRIC_1.png","speciesKey":"MANECTRIC:1"},"Mankey":{"normal":"MANKEY.png","shiny":"MANKEY.png","speciesKey":"MANKEY:0"},"Mantine":{"normal":"MANTINE.png","shiny":"MANTINE.png","speciesKey":"MANTINE:0"},"Mantyke":{"normal":"MANTYKE.png","shiny":"MANTYKE.png","speciesKey":"MANTYKE:0"},"Maractus":{"normal":"MARACTUS.png","shiny":"MARACTUS.png","speciesKey":"MARACTUS:0"},"Mareanie":{"normal":"MAREANIE.png","shiny":"MAREANIE.png","speciesKey":"MAREANIE:0"},"Mareep":{"normal":"MAREEP.png","shiny":"MAREEP.png","speciesKey":"MAREEP:0"},"Marill":{"normal":"MARILL.png","shiny":"MARILL.png","speciesKey":"MARILL:0"},"Marowak":{"normal":"MAROWAK.png","shiny":"MAROWAK.png","speciesKey":"MAROWAK:0"},"Marowak [Alolan]":{"normal":"MAROWAK_1.png","shiny":"MAROWAK_1.png","speciesKey":"MAROWAK:1"},"Marshadow":{"normal":"MARSHADOW.png","shiny":"MARSHADOW.png","speciesKey":"MARSHADOW:0"},"Marshtomp":{"normal":"MARSHTOMP.png","shiny":"MARSHTOMP.png","speciesKey":"MARSHTOMP:0"},"Maschiff":{"normal":"MASCHIFF.png","shiny":"MASCHIFF.png","speciesKey":"MASCHIFF:0"},"Masquerain":{"normal":"MASQUERAIN.png","shiny":"MASQUERAIN.png","speciesKey":"MASQUERAIN:0"},"Maushold":{"normal":"MAUSHOLD.png","shiny":"MAUSHOLD.png","speciesKey":"MAUSHOLD:0"},"Maushold [Family of Three]":{"normal":"MAUSHOLD_1.png","shiny":"MAUSHOLD_1.png","speciesKey":"MAUSHOLD:1"},"Mawile":{"normal":"MAWILE.png","shiny":"MAWILE.png","speciesKey":"MAWILE:0"},"Mawile [Mega Mawile]":{"normal":"MAWILE_1.png","shiny":"MAWILE_1.png","speciesKey":"MAWILE:1"},"Medicham":{"normal":"MEDICHAM.png","shiny":"MEDICHAM.png","speciesKey":"MEDICHAM:0"},"Medicham [Mega Medicham]":{"normal":"MEDICHAM_1.png","shiny":"MEDICHAM_1.png","speciesKey":"MEDICHAM:1"},"Meditite":{"normal":"MEDITITE.png","shiny":"MEDITITE.png","speciesKey":"MEDITITE:0"},"Meganium":{"normal":"MEGANIUM.png","shiny":"MEGANIUM.png","speciesKey":"MEGANIUM:0"},"Meganium [Mega Meganium]":{"normal":"MEGANIUM_1.png","shiny":"MEGANIUM_1.png","speciesKey":"MEGANIUM:1"},"Melmetal":{"normal":"MELMETAL.png","shiny":"MELMETAL.png","speciesKey":"MELMETAL:0"},"Meloetta":{"normal":"MELOETTA.png","shiny":"MELOETTA.png","speciesKey":"MELOETTA:0"},"Meloetta [Pirouette Forme]":{"normal":"MELOETTA_1.png","shiny":"MELOETTA_1.png","speciesKey":"MELOETTA:1"},"Meltan":{"normal":"MELTAN.png","shiny":"MELTAN.png","speciesKey":"MELTAN:0"},"Meowscarada":{"normal":"MEOWSCARADA.png","shiny":"MEOWSCARADA.png","speciesKey":"MEOWSCARADA:0"},"Meowstic":{"normal":"MEOWSTIC.png","shiny":"MEOWSTIC.png","speciesKey":"MEOWSTIC:0"},"Meowstic [Female]":{"normal":"MEOWSTIC_1.png","shiny":"MEOWSTIC_1.png","speciesKey":"MEOWSTIC:1"},"Meowstic [Mega Meowstic]":{"normal":"MEOWSTIC_2.png","shiny":"MEOWSTIC_2.png","speciesKey":"MEOWSTIC:2"},"Meowstic [Form 3]":{"normal":"MEOWSTIC_3.png","shiny":"MEOWSTIC_3.png","speciesKey":"MEOWSTIC:3"},"Meowth":{"normal":"MEOWTH.png","shiny":"MEOWTH.png","speciesKey":"MEOWTH:0"},"Meowth [Alolan]":{"normal":"MEOWTH_1.png","shiny":"MEOWTH_1.png","speciesKey":"MEOWTH:1"},"Meowth [Galarian]":{"normal":"MEOWTH_2.png","shiny":"MEOWTH_2.png","speciesKey":"MEOWTH:2"},"Mesprit":{"normal":"MESPRIT.png","shiny":"MESPRIT.png","speciesKey":"MESPRIT:0"},"Metagross":{"normal":"METAGROSS.png","shiny":"METAGROSS.png","speciesKey":"METAGROSS:0"},"Metagross [Mega Metagross]":{"normal":"METAGROSS_1.png","shiny":"METAGROSS_1.png","speciesKey":"METAGROSS:1"},"Metang":{"normal":"METANG.png","shiny":"METANG.png","speciesKey":"METANG:0"},"Metapod":{"normal":"METAPOD.png","shiny":"METAPOD.png","speciesKey":"METAPOD:0"},"Mew":{"normal":"MEW.png","shiny":"MEW.png","speciesKey":"MEW:0"},"Mewtwo":{"normal":"MEWTWO.png","shiny":"MEWTWO.png","speciesKey":"MEWTWO:0"},"Mewtwo [Mega Mewtwo X]":{"normal":"MEWTWO_1.png","shiny":"MEWTWO_1.png","speciesKey":"MEWTWO:1"},"Mewtwo [Mega Mewtwo Y]":{"normal":"MEWTWO_2.png","shiny":"MEWTWO_2.png","speciesKey":"MEWTWO:2"},"Mienfoo":{"normal":"MIENFOO.png","shiny":"MIENFOO.png","speciesKey":"MIENFOO:0"},"Mienshao":{"normal":"MIENSHAO.png","shiny":"MIENSHAO.png","speciesKey":"MIENSHAO:0"},"Mightyena":{"normal":"MIGHTYENA.png","shiny":"MIGHTYENA.png","speciesKey":"MIGHTYENA:0"},"Milcery":{"normal":"MILCERY.png","shiny":"MILCERY.png","speciesKey":"MILCERY:0"},"Milotic":{"normal":"MILOTIC.png","shiny":"MILOTIC.png","speciesKey":"MILOTIC:0"},"Miltank":{"normal":"MILTANK.png","shiny":"MILTANK.png","speciesKey":"MILTANK:0"},"Mime Jr.":{"normal":"MIMEJR.png","shiny":"MIMEJR.png","speciesKey":"MIMEJR:0"},"Mimikyu":{"normal":"MIMIKYU.png","shiny":"MIMIKYU.png","speciesKey":"MIMIKYU:0"},"Mimikyu [Busted Form]":{"normal":"MIMIKYU_1.png","shiny":"MIMIKYU_1.png","speciesKey":"MIMIKYU:1"},"Minccino":{"normal":"MINCCINO.png","shiny":"MINCCINO.png","speciesKey":"MINCCINO:0"},"Minior":{"normal":"MINIOR.png","shiny":"MINIOR.png","speciesKey":"MINIOR:0"},"Minior [Red Core]":{"normal":"MINIOR_7.png","shiny":"MINIOR_7.png","speciesKey":"MINIOR:7"},"Minior [Orange Core]":{"normal":"MINIOR_8.png","shiny":"MINIOR_8.png","speciesKey":"MINIOR:8"},"Minior [Yellow Core]":{"normal":"MINIOR_9.png","shiny":"MINIOR_9.png","speciesKey":"MINIOR:9"},"Minior [Green Core]":{"normal":"MINIOR_10.png","shiny":"MINIOR_10.png","speciesKey":"MINIOR:10"},"Minior [Blue Core]":{"normal":"MINIOR_11.png","shiny":"MINIOR_11.png","speciesKey":"MINIOR:11"},"Minior [Indigo Core]":{"normal":"MINIOR_12.png","shiny":"MINIOR_12.png","speciesKey":"MINIOR:12"},"Minior [Violet Core]":{"normal":"MINIOR_13.png","shiny":"MINIOR_13.png","speciesKey":"MINIOR:13"},"Minun":{"normal":"MINUN.png","shiny":"MINUN.png","speciesKey":"MINUN:0"},"Miraidon":{"normal":"MIRAIDON.png","shiny":"MIRAIDON.png","speciesKey":"MIRAIDON:0"},"Misdreavus":{"normal":"MISDREAVUS.png","shiny":"MISDREAVUS.png","speciesKey":"MISDREAVUS:0"},"Mismagius":{"normal":"MISMAGIUS.png","shiny":"MISMAGIUS.png","speciesKey":"MISMAGIUS:0"},"Moltres":{"normal":"MOLTRES.png","shiny":"MOLTRES.png","speciesKey":"MOLTRES:0"},"Moltres [Galarian]":{"normal":"MOLTRES_1.png","shiny":"MOLTRES_1.png","speciesKey":"MOLTRES:1"},"Monferno":{"normal":"MONFERNO.png","shiny":"MONFERNO.png","speciesKey":"MONFERNO:0"},"Morelull":{"normal":"MORELULL.png","shiny":"MORELULL.png","speciesKey":"MORELULL:0"},"Morgrem":{"normal":"MORGREM.png","shiny":"MORGREM.png","speciesKey":"MORGREM:0"},"Morpeko":{"normal":"MORPEKO.png","shiny":"MORPEKO.png","speciesKey":"MORPEKO:0"},"Morpeko [Hangry Mode]":{"normal":"MORPEKO_1.png","shiny":"MORPEKO_1.png","speciesKey":"MORPEKO:1"},"Mothim":{"normal":"MOTHIM.png","shiny":"MOTHIM.png","speciesKey":"MOTHIM:0"},"Mr. Mime":{"normal":"MRMIME.png","shiny":"MRMIME.png","speciesKey":"MRMIME:0"},"Mr. Mime [Galarian]":{"normal":"MRMIME_1.png","shiny":"MRMIME_1.png","speciesKey":"MRMIME:1"},"Mr. Rime":{"normal":"MRRIME.png","shiny":"MRRIME.png","speciesKey":"MRRIME:0"},"Mudbray":{"normal":"MUDBRAY.png","shiny":"MUDBRAY.png","speciesKey":"MUDBRAY:0"},"Mudkip":{"normal":"MUDKIP.png","shiny":"MUDKIP.png","speciesKey":"MUDKIP:0"},"Mudsdale":{"normal":"MUDSDALE.png","shiny":"MUDSDALE.png","speciesKey":"MUDSDALE:0"},"Muk":{"normal":"MUK.png","shiny":"MUK.png","speciesKey":"MUK:0"},"Muk [Alolan]":{"normal":"MUK_1.png","shiny":"MUK_1.png","speciesKey":"MUK:1"},"Munchlax":{"normal":"MUNCHLAX.png","shiny":"MUNCHLAX.png","speciesKey":"MUNCHLAX:0"},"Munkidori":{"normal":"MUNKIDORI.png","shiny":"MUNKIDORI.png","speciesKey":"MUNKIDORI:0"},"Munna":{"normal":"MUNNA.png","shiny":"MUNNA.png","speciesKey":"MUNNA:0"},"Murkrow":{"normal":"MURKROW.png","shiny":"MURKROW.png","speciesKey":"MURKROW:0"},"Musharna":{"normal":"MUSHARNA.png","shiny":"MUSHARNA.png","speciesKey":"MUSHARNA:0"},"Nacli":{"normal":"NACLI.png","shiny":"NACLI.png","speciesKey":"NACLI:0"},"Naclstack":{"normal":"NACLSTACK.png","shiny":"NACLSTACK.png","speciesKey":"NACLSTACK:0"},"Naganadel":{"normal":"NAGANADEL.png","shiny":"NAGANADEL.png","speciesKey":"NAGANADEL:0"},"Natu":{"normal":"NATU.png","shiny":"NATU.png","speciesKey":"NATU:0"},"Necrozma":{"normal":"NECROZMA.png","shiny":"NECROZMA.png","speciesKey":"NECROZMA:0"},"Necrozma [Dusk Mane]":{"normal":"NECROZMA_1.png","shiny":"NECROZMA_1.png","speciesKey":"NECROZMA:1"},"Necrozma [Dawn Wings]":{"normal":"NECROZMA_2.png","shiny":"NECROZMA_2.png","speciesKey":"NECROZMA:2"},"Necrozma [Ultra Necrozma]":{"normal":"NECROZMA_3.png","shiny":"NECROZMA_3.png","speciesKey":"NECROZMA:3"},"Necrozma [Form 4]":{"normal":"NECROZMA_4.png","shiny":"NECROZMA_4.png","speciesKey":"NECROZMA:4"},"Nickit":{"normal":"NICKIT.png","shiny":"NICKIT.png","speciesKey":"NICKIT:0"},"Nidoking":{"normal":"NIDOKING.png","shiny":"NIDOKING.png","speciesKey":"NIDOKING:0"},"Nidoqueen":{"normal":"NIDOQUEEN.png","shiny":"NIDOQUEEN.png","speciesKey":"NIDOQUEEN:0"},"Nidoran♀":{"normal":"NIDORANfE.png","shiny":"NIDORANfE.png","speciesKey":"NIDORANfE:0"},"Nidoran♂":{"normal":"NIDORANmA.png","shiny":"NIDORANmA.png","speciesKey":"NIDORANmA:0"},"Nidorina":{"normal":"NIDORINA.png","shiny":"NIDORINA.png","speciesKey":"NIDORINA:0"},"Nidorino":{"normal":"NIDORINO.png","shiny":"NIDORINO.png","speciesKey":"NIDORINO:0"},"Nihilego":{"normal":"NIHILEGO.png","shiny":"NIHILEGO.png","speciesKey":"NIHILEGO:0"},"Nincada":{"normal":"NINCADA.png","shiny":"NINCADA.png","speciesKey":"NINCADA:0"},"Ninetales":{"normal":"NINETALES.png","shiny":"NINETALES.png","speciesKey":"NINETALES:0"},"Ninetales [Alolan]":{"normal":"NINETALES_1.png","shiny":"NINETALES_1.png","speciesKey":"NINETALES:1"},"Ninjask":{"normal":"NINJASK.png","shiny":"NINJASK.png","speciesKey":"NINJASK:0"},"Noctowl":{"normal":"NOCTOWL.png","shiny":"NOCTOWL.png","speciesKey":"NOCTOWL:0"},"Noibat":{"normal":"NOIBAT.png","shiny":"NOIBAT.png","speciesKey":"NOIBAT:0"},"Noivern":{"normal":"NOIVERN.png","shiny":"NOIVERN.png","speciesKey":"NOIVERN:0"},"Nosepass":{"normal":"NOSEPASS.png","shiny":"NOSEPASS.png","speciesKey":"NOSEPASS:0"},"Numel":{"normal":"NUMEL.png","shiny":"NUMEL.png","speciesKey":"NUMEL:0"},"Nuzleaf":{"normal":"NUZLEAF.png","shiny":"NUZLEAF.png","speciesKey":"NUZLEAF:0"},"Nymble":{"normal":"NYMBLE.png","shiny":"NYMBLE.png","speciesKey":"NYMBLE:0"},"Obstagoon":{"normal":"OBSTAGOON.png","shiny":"OBSTAGOON.png","speciesKey":"OBSTAGOON:0"},"Octillery":{"normal":"OCTILLERY.png","shiny":"OCTILLERY.png","speciesKey":"OCTILLERY:0"},"Oddish":{"normal":"ODDISH.png","shiny":"ODDISH.png","speciesKey":"ODDISH:0"},"Ogerpon":{"normal":"OGERPON.png","shiny":"OGERPON.png","speciesKey":"OGERPON:0"},"Ogerpon [Wellspring Mask]":{"normal":"OGERPON_1.png","shiny":"OGERPON_1.png","speciesKey":"OGERPON:1"},"Ogerpon [Hearthflame Mask]":{"normal":"OGERPON_2.png","shiny":"OGERPON_2.png","speciesKey":"OGERPON:2"},"Ogerpon [Cornerstone Mask]":{"normal":"OGERPON_3.png","shiny":"OGERPON_3.png","speciesKey":"OGERPON:3"},"Ogerpon [Form 4]":{"normal":"OGERPON_4.png","shiny":"OGERPON_4.png","speciesKey":"OGERPON:4"},"Ogerpon [Wellspring Mask] [Form 5]":{"normal":"OGERPON_5.png","shiny":"OGERPON_5.png","speciesKey":"OGERPON:5"},"Ogerpon [Hearthflame Mask] [Form 6]":{"normal":"OGERPON_6.png","shiny":"OGERPON_6.png","speciesKey":"OGERPON:6"},"Ogerpon [Cornerstone Mask] [Form 7]":{"normal":"OGERPON_7.png","shiny":"OGERPON_7.png","speciesKey":"OGERPON:7"},"Ogerpon [Terastal Teal Mask]":{"normal":"OGERPON_8.png","shiny":"OGERPON_8.png","speciesKey":"OGERPON:8"},"Ogerpon [Terastal Wellspring Mask]":{"normal":"OGERPON_9.png","shiny":"OGERPON_9.png","speciesKey":"OGERPON:9"},"Ogerpon [Terastal Hearthflame Mask]":{"normal":"OGERPON_10.png","shiny":"OGERPON_10.png","speciesKey":"OGERPON:10"},"Ogerpon [Terastal Cornerstone Mask]":{"normal":"OGERPON_11.png","shiny":"OGERPON_11.png","speciesKey":"OGERPON:11"},"Oinkologne":{"normal":"OINKOLOGNE.png","shiny":"OINKOLOGNE.png","speciesKey":"OINKOLOGNE:0"},"Oinkologne [Female]":{"normal":"OINKOLOGNE_1.png","shiny":"OINKOLOGNE_1.png","speciesKey":"OINKOLOGNE:1"},"Okidogi":{"normal":"OKIDOGI.png","shiny":"OKIDOGI.png","speciesKey":"OKIDOGI:0"},"Omanyte":{"normal":"OMANYTE.png","shiny":"OMANYTE.png","speciesKey":"OMANYTE:0"},"Omastar":{"normal":"OMASTAR.png","shiny":"OMASTAR.png","speciesKey":"OMASTAR:0"},"Onix":{"normal":"ONIX.png","shiny":"ONIX.png","speciesKey":"ONIX:0"},"Oranguru":{"normal":"ORANGURU.png","shiny":"ORANGURU.png","speciesKey":"ORANGURU:0"},"Orbeetle":{"normal":"ORBEETLE.png","shiny":"ORBEETLE.png","speciesKey":"ORBEETLE:0"},"Oricorio":{"normal":"ORICORIO.png","shiny":"ORICORIO.png","speciesKey":"ORICORIO:0"},"Oricorio [Pom-Pom Style]":{"normal":"ORICORIO_1.png","shiny":"ORICORIO_1.png","speciesKey":"ORICORIO:1"},"Oricorio [Pa'u Style]":{"normal":"ORICORIO_2.png","shiny":"ORICORIO_2.png","speciesKey":"ORICORIO:2"},"Oricorio [Sensu Style]":{"normal":"ORICORIO_3.png","shiny":"ORICORIO_3.png","speciesKey":"ORICORIO:3"},"Orthworm":{"normal":"ORTHWORM.png","shiny":"ORTHWORM.png","speciesKey":"ORTHWORM:0"},"Oshawott":{"normal":"OSHAWOTT.png","shiny":"OSHAWOTT.png","speciesKey":"OSHAWOTT:0"},"Overqwil":{"normal":"OVERQWIL.png","shiny":"OVERQWIL.png","speciesKey":"OVERQWIL:0"},"Pachirisu":{"normal":"PACHIRISU.png","shiny":"PACHIRISU.png","speciesKey":"PACHIRISU:0"},"Palafin":{"normal":"PALAFIN.png","shiny":"PALAFIN.png","speciesKey":"PALAFIN:0"},"Palafin [Hero Form]":{"normal":"PALAFIN_1.png","shiny":"PALAFIN_1.png","speciesKey":"PALAFIN:1"},"Palkia":{"normal":"PALKIA.png","shiny":"PALKIA.png","speciesKey":"PALKIA:0"},"Palkia [Origin Forme]":{"normal":"PALKIA_1.png","shiny":"PALKIA_1.png","speciesKey":"PALKIA:1"},"Palossand":{"normal":"PALOSSAND.png","shiny":"PALOSSAND.png","speciesKey":"PALOSSAND:0"},"Palpitoad":{"normal":"PALPITOAD.png","shiny":"PALPITOAD.png","speciesKey":"PALPITOAD:0"},"Pancham":{"normal":"PANCHAM.png","shiny":"PANCHAM.png","speciesKey":"PANCHAM:0"},"Pangoro":{"normal":"PANGORO.png","shiny":"PANGORO.png","speciesKey":"PANGORO:0"},"Panpour":{"normal":"PANPOUR.png","shiny":"PANPOUR.png","speciesKey":"PANPOUR:0"},"Pansage":{"normal":"PANSAGE.png","shiny":"PANSAGE.png","speciesKey":"PANSAGE:0"},"Pansear":{"normal":"PANSEAR.png","shiny":"PANSEAR.png","speciesKey":"PANSEAR:0"},"Paras":{"normal":"PARAS.png","shiny":"PARAS.png","speciesKey":"PARAS:0"},"Parasect":{"normal":"PARASECT.png","shiny":"PARASECT.png","speciesKey":"PARASECT:0"},"Passimian":{"normal":"PASSIMIAN.png","shiny":"PASSIMIAN.png","speciesKey":"PASSIMIAN:0"},"Patrat":{"normal":"PATRAT.png","shiny":"PATRAT.png","speciesKey":"PATRAT:0"},"Pawmi":{"normal":"PAWMI.png","shiny":"PAWMI.png","speciesKey":"PAWMI:0"},"Pawmo":{"normal":"PAWMO.png","shiny":"PAWMO.png","speciesKey":"PAWMO:0"},"Pawmot":{"normal":"PAWMOT.png","shiny":"PAWMOT.png","speciesKey":"PAWMOT:0"},"Pawniard":{"normal":"PAWNIARD.png","shiny":"PAWNIARD.png","speciesKey":"PAWNIARD:0"},"Pecharunt":{"normal":"PECHARUNT.png","shiny":"PECHARUNT.png","speciesKey":"PECHARUNT:0"},"Pelipper":{"normal":"PELIPPER.png","shiny":"PELIPPER.png","speciesKey":"PELIPPER:0"},"Perrserker":{"normal":"PERRSERKER.png","shiny":"PERRSERKER.png","speciesKey":"PERRSERKER:0"},"Persian":{"normal":"PERSIAN.png","shiny":"PERSIAN.png","speciesKey":"PERSIAN:0"},"Persian [Alolan]":{"normal":"PERSIAN_1.png","shiny":"PERSIAN_1.png","speciesKey":"PERSIAN:1"},"Petilil":{"normal":"PETILIL.png","shiny":"PETILIL.png","speciesKey":"PETILIL:0"},"Phanpy":{"normal":"PHANPY.png","shiny":"PHANPY.png","speciesKey":"PHANPY:0"},"Phantump":{"normal":"PHANTUMP.png","shiny":"PHANTUMP.png","speciesKey":"PHANTUMP:0"},"Pheromosa":{"normal":"PHEROMOSA.png","shiny":"PHEROMOSA.png","speciesKey":"PHEROMOSA:0"},"Phione":{"normal":"PHIONE.png","shiny":"PHIONE.png","speciesKey":"PHIONE:0"},"Pichu":{"normal":"PICHU.png","shiny":"PICHU.png","speciesKey":"PICHU:0"},"Pichu [Spiky-Eared]":{"normal":"PICHU.png","shiny":"PICHU.png","speciesKey":"PICHU:2"},"Pidgeot":{"normal":"PIDGEOT.png","shiny":"PIDGEOT.png","speciesKey":"PIDGEOT:0"},"Pidgeot [Mega Pidgeot]":{"normal":"PIDGEOT_1.png","shiny":"PIDGEOT_1.png","speciesKey":"PIDGEOT:1"},"Pidgeotto":{"normal":"PIDGEOTTO.png","shiny":"PIDGEOTTO.png","speciesKey":"PIDGEOTTO:0"},"Pidgey":{"normal":"PIDGEY.png","shiny":"PIDGEY.png","speciesKey":"PIDGEY:0"},"Pidove":{"normal":"PIDOVE.png","shiny":"PIDOVE.png","speciesKey":"PIDOVE:0"},"Pignite":{"normal":"PIGNITE.png","shiny":"PIGNITE.png","speciesKey":"PIGNITE:0"},"Pikachu":{"normal":"PIKACHU.png","shiny":"PIKACHU.png","speciesKey":"PIKACHU:0"},"Pikipek":{"normal":"PIKIPEK.png","shiny":"PIKIPEK.png","speciesKey":"PIKIPEK:0"},"Piloswine":{"normal":"PILOSWINE.png","shiny":"PILOSWINE.png","speciesKey":"PILOSWINE:0"},"Pincurchin":{"normal":"PINCURCHIN.png","shiny":"PINCURCHIN.png","speciesKey":"PINCURCHIN:0"},"Pineco":{"normal":"PINECO.png","shiny":"PINECO.png","speciesKey":"PINECO:0"},"Pinsir":{"normal":"PINSIR.png","shiny":"PINSIR.png","speciesKey":"PINSIR:0"},"Pinsir [Mega Pinsir]":{"normal":"PINSIR_1.png","shiny":"PINSIR_1.png","speciesKey":"PINSIR:1"},"Piplup":{"normal":"PIPLUP.png","shiny":"PIPLUP.png","speciesKey":"PIPLUP:0"},"Plusle":{"normal":"PLUSLE.png","shiny":"PLUSLE.png","speciesKey":"PLUSLE:0"},"Poipole":{"normal":"POIPOLE.png","shiny":"POIPOLE.png","speciesKey":"POIPOLE:0"},"Politoed":{"normal":"POLITOED.png","shiny":"POLITOED.png","speciesKey":"POLITOED:0"},"Poliwag":{"normal":"POLIWAG.png","shiny":"POLIWAG.png","speciesKey":"POLIWAG:0"},"Poliwhirl":{"normal":"POLIWHIRL.png","shiny":"POLIWHIRL.png","speciesKey":"POLIWHIRL:0"},"Poliwrath":{"normal":"POLIWRATH.png","shiny":"POLIWRATH.png","speciesKey":"POLIWRATH:0"},"Poltchageist":{"normal":"POLTCHAGEIST.png","shiny":"POLTCHAGEIST.png","speciesKey":"POLTCHAGEIST:0"},"Poltchageist [Artisan Form]":{"normal":"POLTCHAGEIST.png","shiny":"POLTCHAGEIST.png","speciesKey":"POLTCHAGEIST:1"},"Polteageist":{"normal":"POLTEAGEIST.png","shiny":"POLTEAGEIST.png","speciesKey":"POLTEAGEIST:0"},"Polteageist [Antique Form]":{"normal":"POLTEAGEIST.png","shiny":"POLTEAGEIST.png","speciesKey":"POLTEAGEIST:1"},"Ponyta":{"normal":"PONYTA.png","shiny":"PONYTA.png","speciesKey":"PONYTA:0"},"Ponyta [Galarian]":{"normal":"PONYTA_1.png","shiny":"PONYTA_1.png","speciesKey":"PONYTA:1"},"Poochyena":{"normal":"POOCHYENA.png","shiny":"POOCHYENA.png","speciesKey":"POOCHYENA:0"},"Popplio":{"normal":"POPPLIO.png","shiny":"POPPLIO.png","speciesKey":"POPPLIO:0"},"Porygon":{"normal":"PORYGON.png","shiny":"PORYGON.png","speciesKey":"PORYGON:0"},"Porygon2":{"normal":"PORYGON2.png","shiny":"PORYGON2.png","speciesKey":"PORYGON2:0"},"Porygon-Z":{"normal":"PORYGONZ.png","shiny":"PORYGONZ.png","speciesKey":"PORYGONZ:0"},"Primarina":{"normal":"PRIMARINA.png","shiny":"PRIMARINA.png","speciesKey":"PRIMARINA:0"},"Primeape":{"normal":"PRIMEAPE.png","shiny":"PRIMEAPE.png","speciesKey":"PRIMEAPE:0"},"Prinplup":{"normal":"PRINPLUP.png","shiny":"PRINPLUP.png","speciesKey":"PRINPLUP:0"},"Probopass":{"normal":"PROBOPASS.png","shiny":"PROBOPASS.png","speciesKey":"PROBOPASS:0"},"Psyduck":{"normal":"PSYDUCK.png","shiny":"PSYDUCK.png","speciesKey":"PSYDUCK:0"},"Pumpkaboo":{"normal":"PUMPKABOO.png","shiny":"PUMPKABOO.png","speciesKey":"PUMPKABOO:0"},"Pumpkaboo [Average Size]":{"normal":"PUMPKABOO.png","shiny":"PUMPKABOO.png","speciesKey":"PUMPKABOO:1"},"Pumpkaboo [Large Size]":{"normal":"PUMPKABOO.png","shiny":"PUMPKABOO.png","speciesKey":"PUMPKABOO:2"},"Pumpkaboo [Super Size]":{"normal":"PUMPKABOO.png","shiny":"PUMPKABOO.png","speciesKey":"PUMPKABOO:3"},"Pupitar":{"normal":"PUPITAR.png","shiny":"PUPITAR.png","speciesKey":"PUPITAR:0"},"Purrloin":{"normal":"PURRLOIN.png","shiny":"PURRLOIN.png","speciesKey":"PURRLOIN:0"},"Purugly":{"normal":"PURUGLY.png","shiny":"PURUGLY.png","speciesKey":"PURUGLY:0"},"Pyroar":{"normal":"PYROAR.png","shiny":"PYROAR.png","speciesKey":"PYROAR:0"},"Pyroar [Mega Pyroar]":{"normal":"PYROAR_1.png","shiny":"PYROAR_1.png","speciesKey":"PYROAR:1"},"Pyukumuku":{"normal":"PYUKUMUKU.png","shiny":"PYUKUMUKU.png","speciesKey":"PYUKUMUKU:0"},"Quagsire":{"normal":"QUAGSIRE.png","shiny":"QUAGSIRE.png","speciesKey":"QUAGSIRE:0"},"Quaquaval":{"normal":"QUAQUAVAL.png","shiny":"QUAQUAVAL.png","speciesKey":"QUAQUAVAL:0"},"Quaxly":{"normal":"QUAXLY.png","shiny":"QUAXLY.png","speciesKey":"QUAXLY:0"},"Quaxwell":{"normal":"QUAXWELL.png","shiny":"QUAXWELL.png","speciesKey":"QUAXWELL:0"},"Quilava":{"normal":"QUILAVA.png","shiny":"QUILAVA.png","speciesKey":"QUILAVA:0"},"Quilladin":{"normal":"QUILLADIN.png","shiny":"QUILLADIN.png","speciesKey":"QUILLADIN:0"},"Qwilfish":{"normal":"QWILFISH.png","shiny":"QWILFISH.png","speciesKey":"QWILFISH:0"},"Qwilfish [Hisuian]":{"normal":"QWILFISH_1.png","shiny":"QWILFISH_1.png","speciesKey":"QWILFISH:1"},"Raboot":{"normal":"RABOOT.png","shiny":"RABOOT.png","speciesKey":"RABOOT:0"},"Rabsca":{"normal":"RABSCA.png","shiny":"RABSCA.png","speciesKey":"RABSCA:0"},"Raging Bolt":{"normal":"RAGINGBOLT.png","shiny":"RAGINGBOLT.png","speciesKey":"RAGINGBOLT:0"},"Raichu":{"normal":"RAICHU.png","shiny":"RAICHU.png","speciesKey":"RAICHU:0"},"Raichu [Alolan]":{"normal":"RAICHU_1.png","shiny":"RAICHU_1.png","speciesKey":"RAICHU:1"},"Raichu [Mega Raichu X]":{"normal":"RAICHU_2.png","shiny":"RAICHU_2.png","speciesKey":"RAICHU:2"},"Raichu [Mega Raichu Y]":{"normal":"RAICHU_3.png","shiny":"RAICHU_3.png","speciesKey":"RAICHU:3"},"Raikou":{"normal":"RAIKOU.png","shiny":"RAIKOU.png","speciesKey":"RAIKOU:0"},"Ralts":{"normal":"RALTS.png","shiny":"RALTS.png","speciesKey":"RALTS:0"},"Rampardos":{"normal":"RAMPARDOS.png","shiny":"RAMPARDOS.png","speciesKey":"RAMPARDOS:0"},"Rapidash":{"normal":"RAPIDASH.png","shiny":"RAPIDASH.png","speciesKey":"RAPIDASH:0"},"Rapidash [Galarian]":{"normal":"RAPIDASH_1.png","shiny":"RAPIDASH_1.png","speciesKey":"RAPIDASH:1"},"Raticate":{"normal":"RATICATE.png","shiny":"RATICATE.png","speciesKey":"RATICATE:0"},"Raticate [Alolan]":{"normal":"RATICATE_1.png","shiny":"RATICATE_1.png","speciesKey":"RATICATE:1"},"Rattata":{"normal":"RATTATA.png","shiny":"RATTATA.png","speciesKey":"RATTATA:0"},"Rattata [Alolan]":{"normal":"RATTATA_1.png","shiny":"RATTATA_1.png","speciesKey":"RATTATA:1"},"Rayquaza":{"normal":"RAYQUAZA.png","shiny":"RAYQUAZA.png","speciesKey":"RAYQUAZA:0"},"Rayquaza [Mega Rayquaza]":{"normal":"RAYQUAZA_1.png","shiny":"RAYQUAZA_1.png","speciesKey":"RAYQUAZA:1"},"Regice":{"normal":"REGICE.png","shiny":"REGICE.png","speciesKey":"REGICE:0"},"Regidrago":{"normal":"REGIDRAGO.png","shiny":"REGIDRAGO.png","speciesKey":"REGIDRAGO:0"},"Regieleki":{"normal":"REGIELEKI.png","shiny":"REGIELEKI.png","speciesKey":"REGIELEKI:0"},"Regigigas":{"normal":"REGIGIGAS.png","shiny":"REGIGIGAS.png","speciesKey":"REGIGIGAS:0"},"Regirock":{"normal":"REGIROCK.png","shiny":"REGIROCK.png","speciesKey":"REGIROCK:0"},"Registeel":{"normal":"REGISTEEL.png","shiny":"REGISTEEL.png","speciesKey":"REGISTEEL:0"},"Relicanth":{"normal":"RELICANTH.png","shiny":"RELICANTH.png","speciesKey":"RELICANTH:0"},"Rellor":{"normal":"RELLOR.png","shiny":"RELLOR.png","speciesKey":"RELLOR:0"},"Remoraid":{"normal":"REMORAID.png","shiny":"REMORAID.png","speciesKey":"REMORAID:0"},"Reshiram":{"normal":"RESHIRAM.png","shiny":"RESHIRAM.png","speciesKey":"RESHIRAM:0"},"Reuniclus":{"normal":"REUNICLUS.png","shiny":"REUNICLUS.png","speciesKey":"REUNICLUS:0"},"Revavroom":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:0"},"Revavroom [Form 1]":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:1"},"Revavroom [Form 2]":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:2"},"Revavroom [Form 3]":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:3"},"Revavroom [Form 4]":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:4"},"Revavroom [Form 5]":{"normal":"REVAVROOM.png","shiny":"REVAVROOM.png","speciesKey":"REVAVROOM:5"},"Rhydon":{"normal":"RHYDON.png","shiny":"RHYDON.png","speciesKey":"RHYDON:0"},"Rhyhorn":{"normal":"RHYHORN.png","shiny":"RHYHORN.png","speciesKey":"RHYHORN:0"},"Rhyperior":{"normal":"RHYPERIOR.png","shiny":"RHYPERIOR.png","speciesKey":"RHYPERIOR:0"},"Ribombee":{"normal":"RIBOMBEE.png","shiny":"RIBOMBEE.png","speciesKey":"RIBOMBEE:0"},"Rillaboom":{"normal":"RILLABOOM.png","shiny":"RILLABOOM.png","speciesKey":"RILLABOOM:0"},"Riolu":{"normal":"RIOLU.png","shiny":"RIOLU.png","speciesKey":"RIOLU:0"},"Roaring Moon":{"normal":"ROARINGMOON.png","shiny":"ROARINGMOON.png","speciesKey":"ROARINGMOON:0"},"Rockruff":{"normal":"ROCKRUFF.png","shiny":"ROCKRUFF.png","speciesKey":"ROCKRUFF:0"},"Rockruff [Form 2]":{"normal":"ROCKRUFF.png","shiny":"ROCKRUFF.png","speciesKey":"ROCKRUFF:2"},"Roggenrola":{"normal":"ROGGENROLA.png","shiny":"ROGGENROLA.png","speciesKey":"ROGGENROLA:0"},"Rolycoly":{"normal":"ROLYCOLY.png","shiny":"ROLYCOLY.png","speciesKey":"ROLYCOLY:0"},"Rookidee":{"normal":"ROOKIDEE.png","shiny":"ROOKIDEE.png","speciesKey":"ROOKIDEE:0"},"Roselia":{"normal":"ROSELIA.png","shiny":"ROSELIA.png","speciesKey":"ROSELIA:0"},"Roserade":{"normal":"ROSERADE.png","shiny":"ROSERADE.png","speciesKey":"ROSERADE:0"},"Rotom":{"normal":"ROTOM.png","shiny":"ROTOM.png","speciesKey":"ROTOM:0"},"Rotom [Heat Rotom]":{"normal":"ROTOM_1.png","shiny":"ROTOM_1.png","speciesKey":"ROTOM:1"},"Rotom [Wash Rotom]":{"normal":"ROTOM_2.png","shiny":"ROTOM_2.png","speciesKey":"ROTOM:2"},"Rotom [Frost Rotom]":{"normal":"ROTOM_3.png","shiny":"ROTOM_3.png","speciesKey":"ROTOM:3"},"Rotom [Fan Rotom]":{"normal":"ROTOM_4.png","shiny":"ROTOM_4.png","speciesKey":"ROTOM:4"},"Rotom [Mow Rotom]":{"normal":"ROTOM_5.png","shiny":"ROTOM_5.png","speciesKey":"ROTOM:5"},"Rowlet":{"normal":"ROWLET.png","shiny":"ROWLET.png","speciesKey":"ROWLET:0"},"Rufflet":{"normal":"RUFFLET.png","shiny":"RUFFLET.png","speciesKey":"RUFFLET:0"},"Runerigus":{"normal":"RUNERIGUS.png","shiny":"RUNERIGUS.png","speciesKey":"RUNERIGUS:0"},"Sableye":{"normal":"SABLEYE.png","shiny":"SABLEYE.png","speciesKey":"SABLEYE:0"},"Sableye [Mega Sableye]":{"normal":"SABLEYE_1.png","shiny":"SABLEYE_1.png","speciesKey":"SABLEYE:1"},"Salamence":{"normal":"SALAMENCE.png","shiny":"SALAMENCE.png","speciesKey":"SALAMENCE:0"},"Salamence [Mega Salamence]":{"normal":"SALAMENCE_1.png","shiny":"SALAMENCE_1.png","speciesKey":"SALAMENCE:1"},"Salandit":{"normal":"SALANDIT.png","shiny":"SALANDIT.png","speciesKey":"SALANDIT:0"},"Salazzle":{"normal":"SALAZZLE.png","shiny":"SALAZZLE.png","speciesKey":"SALAZZLE:0"},"Samurott":{"normal":"SAMUROTT.png","shiny":"SAMUROTT.png","speciesKey":"SAMUROTT:0"},"Samurott [Hisuian]":{"normal":"SAMUROTT_1.png","shiny":"SAMUROTT_1.png","speciesKey":"SAMUROTT:1"},"Sandaconda":{"normal":"SANDACONDA.png","shiny":"SANDACONDA.png","speciesKey":"SANDACONDA:0"},"Sandile":{"normal":"SANDILE.png","shiny":"SANDILE.png","speciesKey":"SANDILE:0"},"Sandshrew":{"normal":"SANDSHREW.png","shiny":"SANDSHREW.png","speciesKey":"SANDSHREW:0"},"Sandshrew [Alolan]":{"normal":"SANDSHREW_1.png","shiny":"SANDSHREW_1.png","speciesKey":"SANDSHREW:1"},"Sandslash":{"normal":"SANDSLASH.png","shiny":"SANDSLASH.png","speciesKey":"SANDSLASH:0"},"Sandslash [Alolan]":{"normal":"SANDSLASH_1.png","shiny":"SANDSLASH_1.png","speciesKey":"SANDSLASH:1"},"Sandygast":{"normal":"SANDYGAST.png","shiny":"SANDYGAST.png","speciesKey":"SANDYGAST:0"},"Sandy Shocks":{"normal":"SANDYSHOCKS.png","shiny":"SANDYSHOCKS.png","speciesKey":"SANDYSHOCKS:0"},"Sawk":{"normal":"SAWK.png","shiny":"SAWK.png","speciesKey":"SAWK:0"},"Sawsbuck":{"normal":"SAWSBUCK.png","shiny":"SAWSBUCK.png","speciesKey":"SAWSBUCK:0"},"Sawsbuck [Summer Form]":{"normal":"SAWSBUCK_1.png","shiny":"SAWSBUCK_1.png","speciesKey":"SAWSBUCK:1"},"Sawsbuck [Autumn Form]":{"normal":"SAWSBUCK_2.png","shiny":"SAWSBUCK_2.png","speciesKey":"SAWSBUCK:2"},"Sawsbuck [Winter Form]":{"normal":"SAWSBUCK_3.png","shiny":"SAWSBUCK_3.png","speciesKey":"SAWSBUCK:3"},"Scatterbug":{"normal":"SCATTERBUG.png","shiny":"SCATTERBUG.png","speciesKey":"SCATTERBUG:0"},"Sceptile":{"normal":"SCEPTILE.png","shiny":"SCEPTILE.png","speciesKey":"SCEPTILE:0"},"Sceptile [Mega Sceptile]":{"normal":"SCEPTILE_1.png","shiny":"SCEPTILE_1.png","speciesKey":"SCEPTILE:1"},"Scizor":{"normal":"SCIZOR.png","shiny":"SCIZOR.png","speciesKey":"SCIZOR:0"},"Scizor [Mega Scizor]":{"normal":"SCIZOR_1.png","shiny":"SCIZOR_1.png","speciesKey":"SCIZOR:1"},"Scolipede":{"normal":"SCOLIPEDE.png","shiny":"SCOLIPEDE.png","speciesKey":"SCOLIPEDE:0"},"Scolipede [Mega Scolipede]":{"normal":"SCOLIPEDE_1.png","shiny":"SCOLIPEDE_1.png","speciesKey":"SCOLIPEDE:1"},"Scorbunny":{"normal":"SCORBUNNY.png","shiny":"SCORBUNNY.png","speciesKey":"SCORBUNNY:0"},"Scovillain":{"normal":"SCOVILLAIN.png","shiny":"SCOVILLAIN.png","speciesKey":"SCOVILLAIN:0"},"Scovillain [Mega Scovillain]":{"normal":"SCOVILLAIN_1.png","shiny":"SCOVILLAIN_1.png","speciesKey":"SCOVILLAIN:1"},"Scrafty":{"normal":"SCRAFTY.png","shiny":"SCRAFTY.png","speciesKey":"SCRAFTY:0"},"Scrafty [Mega Scrafty]":{"normal":"SCRAFTY_1.png","shiny":"SCRAFTY_1.png","speciesKey":"SCRAFTY:1"},"Scraggy":{"normal":"SCRAGGY.png","shiny":"SCRAGGY.png","speciesKey":"SCRAGGY:0"},"Scream Tail":{"normal":"SCREAMTAIL.png","shiny":"SCREAMTAIL.png","speciesKey":"SCREAMTAIL:0"},"Scyther":{"normal":"SCYTHER.png","shiny":"SCYTHER.png","speciesKey":"SCYTHER:0"},"Seadra":{"normal":"SEADRA.png","shiny":"SEADRA.png","speciesKey":"SEADRA:0"},"Seaking":{"normal":"SEAKING.png","shiny":"SEAKING.png","speciesKey":"SEAKING:0"},"Sealeo":{"normal":"SEALEO.png","shiny":"SEALEO.png","speciesKey":"SEALEO:0"},"Seedot":{"normal":"SEEDOT.png","shiny":"SEEDOT.png","speciesKey":"SEEDOT:0"},"Seel":{"normal":"SEEL.png","shiny":"SEEL.png","speciesKey":"SEEL:0"},"Seismitoad":{"normal":"SEISMITOAD.png","shiny":"SEISMITOAD.png","speciesKey":"SEISMITOAD:0"},"Sentret":{"normal":"SENTRET.png","shiny":"SENTRET.png","speciesKey":"SENTRET:0"},"Serperior":{"normal":"SERPERIOR.png","shiny":"SERPERIOR.png","speciesKey":"SERPERIOR:0"},"Servine":{"normal":"SERVINE.png","shiny":"SERVINE.png","speciesKey":"SERVINE:0"},"Seviper":{"normal":"SEVIPER.png","shiny":"SEVIPER.png","speciesKey":"SEVIPER:0"},"Sewaddle":{"normal":"SEWADDLE.png","shiny":"SEWADDLE.png","speciesKey":"SEWADDLE:0"},"Sharpedo":{"normal":"SHARPEDO.png","shiny":"SHARPEDO.png","speciesKey":"SHARPEDO:0"},"Sharpedo [Mega Sharpedo]":{"normal":"SHARPEDO_1.png","shiny":"SHARPEDO_1.png","speciesKey":"SHARPEDO:1"},"Shaymin":{"normal":"SHAYMIN.png","shiny":"SHAYMIN.png","speciesKey":"SHAYMIN:0"},"Shaymin [Sky Forme]":{"normal":"SHAYMIN_1.png","shiny":"SHAYMIN_1.png","speciesKey":"SHAYMIN:1"},"Shedinja":{"normal":"SHEDINJA.png","shiny":"SHEDINJA.png","speciesKey":"SHEDINJA:0"},"Shelgon":{"normal":"SHELGON.png","shiny":"SHELGON.png","speciesKey":"SHELGON:0"},"Shellder":{"normal":"SHELLDER.png","shiny":"SHELLDER.png","speciesKey":"SHELLDER:0"},"Shellos":{"normal":"SHELLOS.png","shiny":"SHELLOS.png","speciesKey":"SHELLOS:0"},"Shellos [East Sea]":{"normal":"SHELLOS_1.png","shiny":"SHELLOS_1.png","speciesKey":"SHELLOS:1"},"Shelmet":{"normal":"SHELMET.png","shiny":"SHELMET.png","speciesKey":"SHELMET:0"},"Shieldon":{"normal":"SHIELDON.png","shiny":"SHIELDON.png","speciesKey":"SHIELDON:0"},"Shiftry":{"normal":"SHIFTRY.png","shiny":"SHIFTRY.png","speciesKey":"SHIFTRY:0"},"Shiinotic":{"normal":"SHIINOTIC.png","shiny":"SHIINOTIC.png","speciesKey":"SHIINOTIC:0"},"Shinx":{"normal":"SHINX.png","shiny":"SHINX.png","speciesKey":"SHINX:0"},"Shroodle":{"normal":"SHROODLE.png","shiny":"SHROODLE.png","speciesKey":"SHROODLE:0"},"Shroomish":{"normal":"SHROOMISH.png","shiny":"SHROOMISH.png","speciesKey":"SHROOMISH:0"},"Shuckle":{"normal":"SHUCKLE.png","shiny":"SHUCKLE.png","speciesKey":"SHUCKLE:0"},"Shuppet":{"normal":"SHUPPET.png","shiny":"SHUPPET.png","speciesKey":"SHUPPET:0"},"Sigilyph":{"normal":"SIGILYPH.png","shiny":"SIGILYPH.png","speciesKey":"SIGILYPH:0"},"Silcoon":{"normal":"SILCOON.png","shiny":"SILCOON.png","speciesKey":"SILCOON:0"},"Silicobra":{"normal":"SILICOBRA.png","shiny":"SILICOBRA.png","speciesKey":"SILICOBRA:0"},"Silvally":{"normal":"SILVALLY.png","shiny":"SILVALLY.png","speciesKey":"SILVALLY:0"},"Silvally [Type: Fighting]":{"normal":"SILVALLY_1.png","shiny":"SILVALLY_1.png","speciesKey":"SILVALLY:1"},"Silvally [Type: Flying]":{"normal":"SILVALLY_2.png","shiny":"SILVALLY_2.png","speciesKey":"SILVALLY:2"},"Silvally [Type: Poison]":{"normal":"SILVALLY_3.png","shiny":"SILVALLY_3.png","speciesKey":"SILVALLY:3"},"Silvally [Type: Ground]":{"normal":"SILVALLY_4.png","shiny":"SILVALLY_4.png","speciesKey":"SILVALLY:4"},"Silvally [Type: Rock]":{"normal":"SILVALLY_5.png","shiny":"SILVALLY_5.png","speciesKey":"SILVALLY:5"},"Silvally [Type: Bug]":{"normal":"SILVALLY_6.png","shiny":"SILVALLY_6.png","speciesKey":"SILVALLY:6"},"Silvally [Type: Ghost]":{"normal":"SILVALLY_7.png","shiny":"SILVALLY_7.png","speciesKey":"SILVALLY:7"},"Silvally [Type: Steel]":{"normal":"SILVALLY_8.png","shiny":"SILVALLY_8.png","speciesKey":"SILVALLY:8"},"Silvally [Type: Unknown]":{"normal":"SILVALLY.png","shiny":"SILVALLY.png","speciesKey":"SILVALLY:9"},"Silvally [Type: Fire]":{"normal":"SILVALLY_10.png","shiny":"SILVALLY_10.png","speciesKey":"SILVALLY:10"},"Silvally [Type: Water]":{"normal":"SILVALLY_11.png","shiny":"SILVALLY_11.png","speciesKey":"SILVALLY:11"},"Silvally [Type: Grass]":{"normal":"SILVALLY_12.png","shiny":"SILVALLY_12.png","speciesKey":"SILVALLY:12"},"Silvally [Type: Electric]":{"normal":"SILVALLY_13.png","shiny":"SILVALLY_13.png","speciesKey":"SILVALLY:13"},"Silvally [Type: Psychic]":{"normal":"SILVALLY_14.png","shiny":"SILVALLY_14.png","speciesKey":"SILVALLY:14"},"Silvally [Type: Ice]":{"normal":"SILVALLY_15.png","shiny":"SILVALLY_15.png","speciesKey":"SILVALLY:15"},"Silvally [Type: Dragon]":{"normal":"SILVALLY_16.png","shiny":"SILVALLY_16.png","speciesKey":"SILVALLY:16"},"Silvally [Type: Dark]":{"normal":"SILVALLY_17.png","shiny":"SILVALLY_17.png","speciesKey":"SILVALLY:17"},"Silvally [Type: Fairy]":{"normal":"SILVALLY_18.png","shiny":"SILVALLY_18.png","speciesKey":"SILVALLY:18"},"Simipour":{"normal":"SIMIPOUR.png","shiny":"SIMIPOUR.png","speciesKey":"SIMIPOUR:0"},"Simisage":{"normal":"SIMISAGE.png","shiny":"SIMISAGE.png","speciesKey":"SIMISAGE:0"},"Simisear":{"normal":"SIMISEAR.png","shiny":"SIMISEAR.png","speciesKey":"SIMISEAR:0"},"Sinistcha":{"normal":"SINISTCHA.png","shiny":"SINISTCHA.png","speciesKey":"SINISTCHA:0"},"Sinistcha [Masterpiece Form]":{"normal":"SINISTCHA.png","shiny":"SINISTCHA.png","speciesKey":"SINISTCHA:1"},"Sinistea":{"normal":"SINISTEA.png","shiny":"SINISTEA.png","speciesKey":"SINISTEA:0"},"Sinistea [Antique Form]":{"normal":"SINISTEA.png","shiny":"SINISTEA.png","speciesKey":"SINISTEA:1"},"Sirfetch'd":{"normal":"SIRFETCHD.png","shiny":"SIRFETCHD.png","speciesKey":"SIRFETCHD:0"},"Sizzlipede":{"normal":"SIZZLIPEDE.png","shiny":"SIZZLIPEDE.png","speciesKey":"SIZZLIPEDE:0"},"Skarmory":{"normal":"SKARMORY.png","shiny":"SKARMORY.png","speciesKey":"SKARMORY:0"},"Skarmory [Mega Skarmory]":{"normal":"SKARMORY_1.png","shiny":"SKARMORY_1.png","speciesKey":"SKARMORY:1"},"Skeledirge":{"normal":"SKELEDIRGE.png","shiny":"SKELEDIRGE.png","speciesKey":"SKELEDIRGE:0"},"Skiddo":{"normal":"SKIDDO.png","shiny":"SKIDDO.png","speciesKey":"SKIDDO:0"},"Skiploom":{"normal":"SKIPLOOM.png","shiny":"SKIPLOOM.png","speciesKey":"SKIPLOOM:0"},"Skitty":{"normal":"SKITTY.png","shiny":"SKITTY.png","speciesKey":"SKITTY:0"},"Skorupi":{"normal":"SKORUPI.png","shiny":"SKORUPI.png","speciesKey":"SKORUPI:0"},"Skrelp":{"normal":"SKRELP.png","shiny":"SKRELP.png","speciesKey":"SKRELP:0"},"Skuntank":{"normal":"SKUNTANK.png","shiny":"SKUNTANK.png","speciesKey":"SKUNTANK:0"},"Skwovet":{"normal":"SKWOVET.png","shiny":"SKWOVET.png","speciesKey":"SKWOVET:0"},"Slaking":{"normal":"SLAKING.png","shiny":"SLAKING.png","speciesKey":"SLAKING:0"},"Slakoth":{"normal":"SLAKOTH.png","shiny":"SLAKOTH.png","speciesKey":"SLAKOTH:0"},"Sliggoo":{"normal":"SLIGGOO.png","shiny":"SLIGGOO.png","speciesKey":"SLIGGOO:0"},"Sliggoo [Hisuian]":{"normal":"SLIGGOO_1.png","shiny":"SLIGGOO_1.png","speciesKey":"SLIGGOO:1"},"Slither Wing":{"normal":"SLITHERWING.png","shiny":"SLITHERWING.png","speciesKey":"SLITHERWING:0"},"Slowbro":{"normal":"SLOWBRO.png","shiny":"SLOWBRO.png","speciesKey":"SLOWBRO:0"},"Slowbro [Galarian]":{"normal":"SLOWBRO_1.png","shiny":"SLOWBRO_1.png","speciesKey":"SLOWBRO:1"},"Slowbro [Mega Slowbro]":{"normal":"SLOWBRO_2.png","shiny":"SLOWBRO_2.png","speciesKey":"SLOWBRO:2"},"Slowking":{"normal":"SLOWKING.png","shiny":"SLOWKING.png","speciesKey":"SLOWKING:0"},"Slowking [Galarian]":{"normal":"SLOWKING_1.png","shiny":"SLOWKING_1.png","speciesKey":"SLOWKING:1"},"Slowpoke":{"normal":"SLOWPOKE.png","shiny":"SLOWPOKE.png","speciesKey":"SLOWPOKE:0"},"Slowpoke [Galarian]":{"normal":"SLOWPOKE_1.png","shiny":"SLOWPOKE_1.png","speciesKey":"SLOWPOKE:1"},"Slugma":{"normal":"SLUGMA.png","shiny":"SLUGMA.png","speciesKey":"SLUGMA:0"},"Slurpuff":{"normal":"SLURPUFF.png","shiny":"SLURPUFF.png","speciesKey":"SLURPUFF:0"},"Smeargle":{"normal":"SMEARGLE.png","shiny":"SMEARGLE.png","speciesKey":"SMEARGLE:0"},"Smoliv":{"normal":"SMOLIV.png","shiny":"SMOLIV.png","speciesKey":"SMOLIV:0"},"Smoochum":{"normal":"SMOOCHUM.png","shiny":"SMOOCHUM.png","speciesKey":"SMOOCHUM:0"},"Sneasel":{"normal":"SNEASEL.png","shiny":"SNEASEL.png","speciesKey":"SNEASEL:0"},"Sneasel [Hisuian]":{"normal":"SNEASEL_1.png","shiny":"SNEASEL_1.png","speciesKey":"SNEASEL:1"},"Sneasler":{"normal":"SNEASLER.png","shiny":"SNEASLER.png","speciesKey":"SNEASLER:0"},"Snivy":{"normal":"SNIVY.png","shiny":"SNIVY.png","speciesKey":"SNIVY:0"},"Snom":{"normal":"SNOM.png","shiny":"SNOM.png","speciesKey":"SNOM:0"},"Snorlax":{"normal":"SNORLAX.png","shiny":"SNORLAX.png","speciesKey":"SNORLAX:0"},"Snorunt":{"normal":"SNORUNT.png","shiny":"SNORUNT.png","speciesKey":"SNORUNT:0"},"Snover":{"normal":"SNOVER.png","shiny":"SNOVER.png","speciesKey":"SNOVER:0"},"Snubbull":{"normal":"SNUBBULL.png","shiny":"SNUBBULL.png","speciesKey":"SNUBBULL:0"},"Sobble":{"normal":"SOBBLE.png","shiny":"SOBBLE.png","speciesKey":"SOBBLE:0"},"Solgaleo":{"normal":"SOLGALEO.png","shiny":"SOLGALEO.png","speciesKey":"SOLGALEO:0"},"Solosis":{"normal":"SOLOSIS.png","shiny":"SOLOSIS.png","speciesKey":"SOLOSIS:0"},"Solrock":{"normal":"SOLROCK.png","shiny":"SOLROCK.png","speciesKey":"SOLROCK:0"},"Spearow":{"normal":"SPEAROW.png","shiny":"SPEAROW.png","speciesKey":"SPEAROW:0"},"Spectrier":{"normal":"SPECTRIER.png","shiny":"SPECTRIER.png","speciesKey":"SPECTRIER:0"},"Spewpa":{"normal":"SPEWPA.png","shiny":"SPEWPA.png","speciesKey":"SPEWPA:0"},"Spheal":{"normal":"SPHEAL.png","shiny":"SPHEAL.png","speciesKey":"SPHEAL:0"},"Spidops":{"normal":"SPIDOPS.png","shiny":"SPIDOPS.png","speciesKey":"SPIDOPS:0"},"Spinarak":{"normal":"SPINARAK.png","shiny":"SPINARAK.png","speciesKey":"SPINARAK:0"},"Spinda":{"normal":"SPINDA.png","shiny":"SPINDA.png","speciesKey":"SPINDA:0"},"Spiritomb":{"normal":"SPIRITOMB.png","shiny":"SPIRITOMB.png","speciesKey":"SPIRITOMB:0"},"Spoink":{"normal":"SPOINK.png","shiny":"SPOINK.png","speciesKey":"SPOINK:0"},"Sprigatito":{"normal":"SPRIGATITO.png","shiny":"SPRIGATITO.png","speciesKey":"SPRIGATITO:0"},"Spritzee":{"normal":"SPRITZEE.png","shiny":"SPRITZEE.png","speciesKey":"SPRITZEE:0"},"Squawkabilly":{"normal":"SQUAWKABILLY.png","shiny":"SQUAWKABILLY.png","speciesKey":"SQUAWKABILLY:0"},"Squawkabilly [Blue Plumage]":{"normal":"SQUAWKABILLY_1.png","shiny":"SQUAWKABILLY_1.png","speciesKey":"SQUAWKABILLY:1"},"Squawkabilly [Yellow Plumage]":{"normal":"SQUAWKABILLY_2.png","shiny":"SQUAWKABILLY_2.png","speciesKey":"SQUAWKABILLY:2"},"Squawkabilly [White Plumage]":{"normal":"SQUAWKABILLY_3.png","shiny":"SQUAWKABILLY_3.png","speciesKey":"SQUAWKABILLY:3"},"Squirtle":{"normal":"SQUIRTLE.png","shiny":"SQUIRTLE.png","speciesKey":"SQUIRTLE:0"},"Stakataka":{"normal":"STAKATAKA.png","shiny":"STAKATAKA.png","speciesKey":"STAKATAKA:0"},"Stantler":{"normal":"STANTLER.png","shiny":"STANTLER.png","speciesKey":"STANTLER:0"},"Staraptor":{"normal":"STARAPTOR.png","shiny":"STARAPTOR.png","speciesKey":"STARAPTOR:0"},"Staraptor [Mega Staraptor]":{"normal":"STARAPTOR_1.png","shiny":"STARAPTOR_1.png","speciesKey":"STARAPTOR:1"},"Staravia":{"normal":"STARAVIA.png","shiny":"STARAVIA.png","speciesKey":"STARAVIA:0"},"Starly":{"normal":"STARLY.png","shiny":"STARLY.png","speciesKey":"STARLY:0"},"Starmie":{"normal":"STARMIE.png","shiny":"STARMIE.png","speciesKey":"STARMIE:0"},"Starmie [Mega Starmie]":{"normal":"STARMIE_1.png","shiny":"STARMIE_1.png","speciesKey":"STARMIE:1"},"Staryu":{"normal":"STARYU.png","shiny":"STARYU.png","speciesKey":"STARYU:0"},"Steelix":{"normal":"STEELIX.png","shiny":"STEELIX.png","speciesKey":"STEELIX:0"},"Steelix [Mega Steelix]":{"normal":"STEELIX_1.png","shiny":"STEELIX_1.png","speciesKey":"STEELIX:1"},"Steenee":{"normal":"STEENEE.png","shiny":"STEENEE.png","speciesKey":"STEENEE:0"},"Stonjourner":{"normal":"STONJOURNER.png","shiny":"STONJOURNER.png","speciesKey":"STONJOURNER:0"},"Stoutland":{"normal":"STOUTLAND.png","shiny":"STOUTLAND.png","speciesKey":"STOUTLAND:0"},"Stufful":{"normal":"STUFFUL.png","shiny":"STUFFUL.png","speciesKey":"STUFFUL:0"},"Stunfisk":{"normal":"STUNFISK.png","shiny":"STUNFISK.png","speciesKey":"STUNFISK:0"},"Stunfisk [Galarian]":{"normal":"STUNFISK_1.png","shiny":"STUNFISK_1.png","speciesKey":"STUNFISK:1"},"Stunky":{"normal":"STUNKY.png","shiny":"STUNKY.png","speciesKey":"STUNKY:0"},"Sudowoodo":{"normal":"SUDOWOODO.png","shiny":"SUDOWOODO.png","speciesKey":"SUDOWOODO:0"},"Suicune":{"normal":"SUICUNE.png","shiny":"SUICUNE.png","speciesKey":"SUICUNE:0"},"Sunflora":{"normal":"SUNFLORA.png","shiny":"SUNFLORA.png","speciesKey":"SUNFLORA:0"},"Sunkern":{"normal":"SUNKERN.png","shiny":"SUNKERN.png","speciesKey":"SUNKERN:0"},"Surskit":{"normal":"SURSKIT.png","shiny":"SURSKIT.png","speciesKey":"SURSKIT:0"},"Swablu":{"normal":"SWABLU.png","shiny":"SWABLU.png","speciesKey":"SWABLU:0"},"Swadloon":{"normal":"SWADLOON.png","shiny":"SWADLOON.png","speciesKey":"SWADLOON:0"},"Swalot":{"normal":"SWALOT.png","shiny":"SWALOT.png","speciesKey":"SWALOT:0"},"Swampert":{"normal":"SWAMPERT.png","shiny":"SWAMPERT.png","speciesKey":"SWAMPERT:0"},"Swampert [Mega Swampert]":{"normal":"SWAMPERT_1.png","shiny":"SWAMPERT_1.png","speciesKey":"SWAMPERT:1"},"Swanna":{"normal":"SWANNA.png","shiny":"SWANNA.png","speciesKey":"SWANNA:0"},"Swellow":{"normal":"SWELLOW.png","shiny":"SWELLOW.png","speciesKey":"SWELLOW:0"},"Swinub":{"normal":"SWINUB.png","shiny":"SWINUB.png","speciesKey":"SWINUB:0"},"Swirlix":{"normal":"SWIRLIX.png","shiny":"SWIRLIX.png","speciesKey":"SWIRLIX:0"},"Swoobat":{"normal":"SWOOBAT.png","shiny":"SWOOBAT.png","speciesKey":"SWOOBAT:0"},"Sylveon":{"normal":"SYLVEON.png","shiny":"SYLVEON.png","speciesKey":"SYLVEON:0"},"Tadbulb":{"normal":"TADBULB.png","shiny":"TADBULB.png","speciesKey":"TADBULB:0"},"Taillow":{"normal":"TAILLOW.png","shiny":"TAILLOW.png","speciesKey":"TAILLOW:0"},"Talonflame":{"normal":"TALONFLAME.png","shiny":"TALONFLAME.png","speciesKey":"TALONFLAME:0"},"Tandemaus":{"normal":"TANDEMAUS.png","shiny":"TANDEMAUS.png","speciesKey":"TANDEMAUS:0"},"Tangela":{"normal":"TANGELA.png","shiny":"TANGELA.png","speciesKey":"TANGELA:0"},"Tangrowth":{"normal":"TANGROWTH.png","shiny":"TANGROWTH.png","speciesKey":"TANGROWTH:0"},"Tapu Bulu":{"normal":"TAPUBULU.png","shiny":"TAPUBULU.png","speciesKey":"TAPUBULU:0"},"Tapu Fini":{"normal":"TAPUFINI.png","shiny":"TAPUFINI.png","speciesKey":"TAPUFINI:0"},"Tapu Koko":{"normal":"TAPUKOKO.png","shiny":"TAPUKOKO.png","speciesKey":"TAPUKOKO:0"},"Tapu Lele":{"normal":"TAPULELE.png","shiny":"TAPULELE.png","speciesKey":"TAPULELE:0"},"Tarountula":{"normal":"TAROUNTULA.png","shiny":"TAROUNTULA.png","speciesKey":"TAROUNTULA:0"},"Tatsugiri":{"normal":"TATSUGIRI.png","shiny":"TATSUGIRI.png","speciesKey":"TATSUGIRI:0"},"Tatsugiri [Droopy Form]":{"normal":"TATSUGIRI_1.png","shiny":"TATSUGIRI_1.png","speciesKey":"TATSUGIRI:1"},"Tatsugiri [Stretchy Form]":{"normal":"TATSUGIRI_2.png","shiny":"TATSUGIRI_2.png","speciesKey":"TATSUGIRI:2"},"Tatsugiri [Mega Tatsugiri (Curly Form)]":{"normal":"TATSUGIRI_3.png","shiny":"TATSUGIRI_3.png","speciesKey":"TATSUGIRI:3"},"Tatsugiri [Mega Tatsugiri (Droopy Form)]":{"normal":"TATSUGIRI_4.png","shiny":"TATSUGIRI_4.png","speciesKey":"TATSUGIRI:4"},"Tatsugiri [Mega Tatsugiri (Stretchy Form)]":{"normal":"TATSUGIRI_5.png","shiny":"TATSUGIRI_5.png","speciesKey":"TATSUGIRI:5"},"Tauros":{"normal":"TAUROS.png","shiny":"TAUROS.png","speciesKey":"TAUROS:0"},"Tauros [Paldean (Combat Breed)]":{"normal":"TAUROS_1.png","shiny":"TAUROS_1.png","speciesKey":"TAUROS:1"},"Tauros [Paldean (Blaze Breed)]":{"normal":"TAUROS_2.png","shiny":"TAUROS_2.png","speciesKey":"TAUROS:2"},"Tauros [Paldean (Aqua Breed)]":{"normal":"TAUROS_3.png","shiny":"TAUROS_3.png","speciesKey":"TAUROS:3"},"Teddiursa":{"normal":"TEDDIURSA.png","shiny":"TEDDIURSA.png","speciesKey":"TEDDIURSA:0"},"Tentacool":{"normal":"TENTACOOL.png","shiny":"TENTACOOL.png","speciesKey":"TENTACOOL:0"},"Tentacruel":{"normal":"TENTACRUEL.png","shiny":"TENTACRUEL.png","speciesKey":"TENTACRUEL:0"},"Tepig":{"normal":"TEPIG.png","shiny":"TEPIG.png","speciesKey":"TEPIG:0"},"Terapagos":{"normal":"TERAPAGOS.png","shiny":"TERAPAGOS.png","speciesKey":"TERAPAGOS:0"},"Terapagos [Terastal Form]":{"normal":"TERAPAGOS_1.png","shiny":"TERAPAGOS_1.png","speciesKey":"TERAPAGOS:1"},"Terapagos [Stellar Form]":{"normal":"TERAPAGOS_2.png","shiny":"TERAPAGOS_2.png","speciesKey":"TERAPAGOS:2"},"Terrakion":{"normal":"TERRAKION.png","shiny":"TERRAKION.png","speciesKey":"TERRAKION:0"},"Thievul":{"normal":"THIEVUL.png","shiny":"THIEVUL.png","speciesKey":"THIEVUL:0"},"Throh":{"normal":"THROH.png","shiny":"THROH.png","speciesKey":"THROH:0"},"Thundurus":{"normal":"THUNDURUS.png","shiny":"THUNDURUS.png","speciesKey":"THUNDURUS:0"},"Thundurus [Therian Forme]":{"normal":"THUNDURUS_1.png","shiny":"THUNDURUS_1.png","speciesKey":"THUNDURUS:1"},"Thwackey":{"normal":"THWACKEY.png","shiny":"THWACKEY.png","speciesKey":"THWACKEY:0"},"Timburr":{"normal":"TIMBURR.png","shiny":"TIMBURR.png","speciesKey":"TIMBURR:0"},"Ting-Lu":{"normal":"TINGLU.png","shiny":"TINGLU.png","speciesKey":"TINGLU:0"},"Tinkatink":{"normal":"TINKATINK.png","shiny":"TINKATINK.png","speciesKey":"TINKATINK:0"},"Tinkaton":{"normal":"TINKATON.png","shiny":"TINKATON.png","speciesKey":"TINKATON:0"},"Tinkatuff":{"normal":"TINKATUFF.png","shiny":"TINKATUFF.png","speciesKey":"TINKATUFF:0"},"Tirtouga":{"normal":"TIRTOUGA.png","shiny":"TIRTOUGA.png","speciesKey":"TIRTOUGA:0"},"Toedscool":{"normal":"TOEDSCOOL.png","shiny":"TOEDSCOOL.png","speciesKey":"TOEDSCOOL:0"},"Toedscruel":{"normal":"TOEDSCRUEL.png","shiny":"TOEDSCRUEL.png","speciesKey":"TOEDSCRUEL:0"},"Togedemaru":{"normal":"TOGEDEMARU.png","shiny":"TOGEDEMARU.png","speciesKey":"TOGEDEMARU:0"},"Togekiss":{"normal":"TOGEKISS.png","shiny":"TOGEKISS.png","speciesKey":"TOGEKISS:0"},"Togepi":{"normal":"TOGEPI.png","shiny":"TOGEPI.png","speciesKey":"TOGEPI:0"},"Togetic":{"normal":"TOGETIC.png","shiny":"TOGETIC.png","speciesKey":"TOGETIC:0"},"Torchic":{"normal":"TORCHIC.png","shiny":"TORCHIC.png","speciesKey":"TORCHIC:0"},"Torkoal":{"normal":"TORKOAL.png","shiny":"TORKOAL.png","speciesKey":"TORKOAL:0"},"Tornadus":{"normal":"TORNADUS.png","shiny":"TORNADUS.png","speciesKey":"TORNADUS:0"},"Tornadus [Therian Forme]":{"normal":"TORNADUS_1.png","shiny":"TORNADUS_1.png","speciesKey":"TORNADUS:1"},"Torracat":{"normal":"TORRACAT.png","shiny":"TORRACAT.png","speciesKey":"TORRACAT:0"},"Torterra":{"normal":"TORTERRA.png","shiny":"TORTERRA.png","speciesKey":"TORTERRA:0"},"Totodile":{"normal":"TOTODILE.png","shiny":"TOTODILE.png","speciesKey":"TOTODILE:0"},"Toucannon":{"normal":"TOUCANNON.png","shiny":"TOUCANNON.png","speciesKey":"TOUCANNON:0"},"Toxapex":{"normal":"TOXAPEX.png","shiny":"TOXAPEX.png","speciesKey":"TOXAPEX:0"},"Toxel":{"normal":"TOXEL.png","shiny":"TOXEL.png","speciesKey":"TOXEL:0"},"Toxicroak":{"normal":"TOXICROAK.png","shiny":"TOXICROAK.png","speciesKey":"TOXICROAK:0"},"Toxtricity":{"normal":"TOXTRICITY.png","shiny":"TOXTRICITY.png","speciesKey":"TOXTRICITY:0"},"Toxtricity [Low Key Form]":{"normal":"TOXTRICITY_1.png","shiny":"TOXTRICITY_1.png","speciesKey":"TOXTRICITY:1"},"Tranquill":{"normal":"TRANQUILL.png","shiny":"TRANQUILL.png","speciesKey":"TRANQUILL:0"},"Trapinch":{"normal":"TRAPINCH.png","shiny":"TRAPINCH.png","speciesKey":"TRAPINCH:0"},"Treecko":{"normal":"TREECKO.png","shiny":"TREECKO.png","speciesKey":"TREECKO:0"},"Trevenant":{"normal":"TREVENANT.png","shiny":"TREVENANT.png","speciesKey":"TREVENANT:0"},"Tropius":{"normal":"TROPIUS.png","shiny":"TROPIUS.png","speciesKey":"TROPIUS:0"},"Trubbish":{"normal":"TRUBBISH.png","shiny":"TRUBBISH.png","speciesKey":"TRUBBISH:0"},"Trumbeak":{"normal":"TRUMBEAK.png","shiny":"TRUMBEAK.png","speciesKey":"TRUMBEAK:0"},"Tsareena":{"normal":"TSAREENA.png","shiny":"TSAREENA.png","speciesKey":"TSAREENA:0"},"Turtonator":{"normal":"TURTONATOR.png","shiny":"TURTONATOR.png","speciesKey":"TURTONATOR:0"},"Turtwig":{"normal":"TURTWIG.png","shiny":"TURTWIG.png","speciesKey":"TURTWIG:0"},"Tympole":{"normal":"TYMPOLE.png","shiny":"TYMPOLE.png","speciesKey":"TYMPOLE:0"},"Tynamo":{"normal":"TYNAMO.png","shiny":"TYNAMO.png","speciesKey":"TYNAMO:0"},"Type: Null":{"normal":"TYPENULL.png","shiny":"TYPENULL.png","speciesKey":"TYPENULL:0"},"Typhlosion":{"normal":"TYPHLOSION.png","shiny":"TYPHLOSION.png","speciesKey":"TYPHLOSION:0"},"Typhlosion [Hisuian]":{"normal":"TYPHLOSION_1.png","shiny":"TYPHLOSION_1.png","speciesKey":"TYPHLOSION:1"},"Tyranitar":{"normal":"TYRANITAR.png","shiny":"TYRANITAR.png","speciesKey":"TYRANITAR:0"},"Tyranitar [Mega Tyranitar]":{"normal":"TYRANITAR_1.png","shiny":"TYRANITAR_1.png","speciesKey":"TYRANITAR:1"},"Tyrantrum":{"normal":"TYRANTRUM.png","shiny":"TYRANTRUM.png","speciesKey":"TYRANTRUM:0"},"Tyrogue":{"normal":"TYROGUE.png","shiny":"TYROGUE.png","speciesKey":"TYROGUE:0"},"Tyrunt":{"normal":"TYRUNT.png","shiny":"TYRUNT.png","speciesKey":"TYRUNT:0"},"Umbreon":{"normal":"UMBREON.png","shiny":"UMBREON.png","speciesKey":"UMBREON:0"},"Unfezant":{"normal":"UNFEZANT.png","shiny":"UNFEZANT.png","speciesKey":"UNFEZANT:0"},"Unown":{"normal":"UNOWN.png","shiny":"UNOWN.png","speciesKey":"UNOWN:0"},"Unown [B]":{"normal":"UNOWN_1.png","shiny":"UNOWN_1.png","speciesKey":"UNOWN:1"},"Unown [C]":{"normal":"UNOWN_2.png","shiny":"UNOWN_2.png","speciesKey":"UNOWN:2"},"Unown [D]":{"normal":"UNOWN_3.png","shiny":"UNOWN_3.png","speciesKey":"UNOWN:3"},"Unown [E]":{"normal":"UNOWN_4.png","shiny":"UNOWN_4.png","speciesKey":"UNOWN:4"},"Unown [F]":{"normal":"UNOWN_5.png","shiny":"UNOWN_5.png","speciesKey":"UNOWN:5"},"Unown [G]":{"normal":"UNOWN_6.png","shiny":"UNOWN_6.png","speciesKey":"UNOWN:6"},"Unown [H]":{"normal":"UNOWN_7.png","shiny":"UNOWN_7.png","speciesKey":"UNOWN:7"},"Unown [I]":{"normal":"UNOWN_8.png","shiny":"UNOWN_8.png","speciesKey":"UNOWN:8"},"Unown [J]":{"normal":"UNOWN_9.png","shiny":"UNOWN_9.png","speciesKey":"UNOWN:9"},"Unown [K]":{"normal":"UNOWN_10.png","shiny":"UNOWN_10.png","speciesKey":"UNOWN:10"},"Unown [L]":{"normal":"UNOWN_11.png","shiny":"UNOWN_11.png","speciesKey":"UNOWN:11"},"Unown [M]":{"normal":"UNOWN_12.png","shiny":"UNOWN_12.png","speciesKey":"UNOWN:12"},"Unown [N]":{"normal":"UNOWN_13.png","shiny":"UNOWN_13.png","speciesKey":"UNOWN:13"},"Unown [O]":{"normal":"UNOWN_14.png","shiny":"UNOWN_14.png","speciesKey":"UNOWN:14"},"Unown [P]":{"normal":"UNOWN_15.png","shiny":"UNOWN_15.png","speciesKey":"UNOWN:15"},"Unown [Q]":{"normal":"UNOWN_16.png","shiny":"UNOWN_16.png","speciesKey":"UNOWN:16"},"Unown [R]":{"normal":"UNOWN_17.png","shiny":"UNOWN_17.png","speciesKey":"UNOWN:17"},"Unown [S]":{"normal":"UNOWN_18.png","shiny":"UNOWN_18.png","speciesKey":"UNOWN:18"},"Unown [T]":{"normal":"UNOWN_19.png","shiny":"UNOWN_19.png","speciesKey":"UNOWN:19"},"Unown [U]":{"normal":"UNOWN_20.png","shiny":"UNOWN_20.png","speciesKey":"UNOWN:20"},"Unown [V]":{"normal":"UNOWN_21.png","shiny":"UNOWN_21.png","speciesKey":"UNOWN:21"},"Unown [W]":{"normal":"UNOWN_22.png","shiny":"UNOWN_22.png","speciesKey":"UNOWN:22"},"Unown [X]":{"normal":"UNOWN_23.png","shiny":"UNOWN_23.png","speciesKey":"UNOWN:23"},"Unown [Y]":{"normal":"UNOWN_24.png","shiny":"UNOWN_24.png","speciesKey":"UNOWN:24"},"Unown [Z]":{"normal":"UNOWN_25.png","shiny":"UNOWN_25.png","speciesKey":"UNOWN:25"},"Unown [?]":{"normal":"UNOWN_26.png","shiny":"UNOWN_26.png","speciesKey":"UNOWN:26"},"Unown [!]":{"normal":"UNOWN_27.png","shiny":"UNOWN_27.png","speciesKey":"UNOWN:27"},"Ursaluna":{"normal":"URSALUNA.png","shiny":"URSALUNA.png","speciesKey":"URSALUNA:0"},"Ursaluna [Bloodmoon Ursaluna]":{"normal":"URSALUNA_1.png","shiny":"URSALUNA_1.png","speciesKey":"URSALUNA:1"},"Ursaring":{"normal":"URSARING.png","shiny":"URSARING.png","speciesKey":"URSARING:0"},"Urshifu":{"normal":"URSHIFU.png","shiny":"URSHIFU.png","speciesKey":"URSHIFU:0"},"Urshifu [Rapid Strike Style]":{"normal":"URSHIFU_1.png","shiny":"URSHIFU_1.png","speciesKey":"URSHIFU:1"},"Uxie":{"normal":"UXIE.png","shiny":"UXIE.png","speciesKey":"UXIE:0"},"Vanillish":{"normal":"VANILLISH.png","shiny":"VANILLISH.png","speciesKey":"VANILLISH:0"},"Vanillite":{"normal":"VANILLITE.png","shiny":"VANILLITE.png","speciesKey":"VANILLITE:0"},"Vanilluxe":{"normal":"VANILLUXE.png","shiny":"VANILLUXE.png","speciesKey":"VANILLUXE:0"},"Vaporeon":{"normal":"VAPOREON.png","shiny":"VAPOREON.png","speciesKey":"VAPOREON:0"},"Varoom":{"normal":"VAROOM.png","shiny":"VAROOM.png","speciesKey":"VAROOM:0"},"Veluza":{"normal":"VELUZA.png","shiny":"VELUZA.png","speciesKey":"VELUZA:0"},"Venipede":{"normal":"VENIPEDE.png","shiny":"VENIPEDE.png","speciesKey":"VENIPEDE:0"},"Venomoth":{"normal":"VENOMOTH.png","shiny":"VENOMOTH.png","speciesKey":"VENOMOTH:0"},"Venonat":{"normal":"VENONAT.png","shiny":"VENONAT.png","speciesKey":"VENONAT:0"},"Venusaur":{"normal":"VENUSAUR.png","shiny":"VENUSAUR.png","speciesKey":"VENUSAUR:0"},"Venusaur [Mega Venusaur]":{"normal":"VENUSAUR_1.png","shiny":"VENUSAUR_1.png","speciesKey":"VENUSAUR:1"},"Vespiquen":{"normal":"VESPIQUEN.png","shiny":"VESPIQUEN.png","speciesKey":"VESPIQUEN:0"},"Vibrava":{"normal":"VIBRAVA.png","shiny":"VIBRAVA.png","speciesKey":"VIBRAVA:0"},"Victini":{"normal":"VICTINI.png","shiny":"VICTINI.png","speciesKey":"VICTINI:0"},"Victreebel":{"normal":"VICTREEBEL.png","shiny":"VICTREEBEL.png","speciesKey":"VICTREEBEL:0"},"Victreebel [Mega Victreebel]":{"normal":"VICTREEBEL_1.png","shiny":"VICTREEBEL_1.png","speciesKey":"VICTREEBEL:1"},"Vigoroth":{"normal":"VIGOROTH.png","shiny":"VIGOROTH.png","speciesKey":"VIGOROTH:0"},"Vikavolt":{"normal":"VIKAVOLT.png","shiny":"VIKAVOLT.png","speciesKey":"VIKAVOLT:0"},"Vileplume":{"normal":"VILEPLUME.png","shiny":"VILEPLUME.png","speciesKey":"VILEPLUME:0"},"Virizion":{"normal":"VIRIZION.png","shiny":"VIRIZION.png","speciesKey":"VIRIZION:0"},"Vivillon":{"normal":"VIVILLON.png","shiny":"VIVILLON.png","speciesKey":"VIVILLON:0"},"Vivillon [Continental Pattern]":{"normal":"VIVILLON_1.png","shiny":"VIVILLON_1.png","speciesKey":"VIVILLON:1"},"Vivillon [Elegant Pattern]":{"normal":"VIVILLON_2.png","shiny":"VIVILLON_2.png","speciesKey":"VIVILLON:2"},"Vivillon [Garden Pattern]":{"normal":"VIVILLON_3.png","shiny":"VIVILLON_3.png","speciesKey":"VIVILLON:3"},"Vivillon [High Plains Pattern]":{"normal":"VIVILLON_4.png","shiny":"VIVILLON_4.png","speciesKey":"VIVILLON:4"},"Vivillon [Icy Snow Pattern]":{"normal":"VIVILLON_5.png","shiny":"VIVILLON_5.png","speciesKey":"VIVILLON:5"},"Vivillon [Jungle Pattern]":{"normal":"VIVILLON_6.png","shiny":"VIVILLON_6.png","speciesKey":"VIVILLON:6"},"Vivillon [Marine Pattern]":{"normal":"VIVILLON_7.png","shiny":"VIVILLON_7.png","speciesKey":"VIVILLON:7"},"Vivillon [Meadow Pattern]":{"normal":"VIVILLON_8.png","shiny":"VIVILLON_8.png","speciesKey":"VIVILLON:8"},"Vivillon [Modern Pattern]":{"normal":"VIVILLON_9.png","shiny":"VIVILLON_9.png","speciesKey":"VIVILLON:9"},"Vivillon [Monsoon Pattern]":{"normal":"VIVILLON_10.png","shiny":"VIVILLON_10.png","speciesKey":"VIVILLON:10"},"Vivillon [Ocean Pattern]":{"normal":"VIVILLON_11.png","shiny":"VIVILLON_11.png","speciesKey":"VIVILLON:11"},"Vivillon [Polar Pattern]":{"normal":"VIVILLON_12.png","shiny":"VIVILLON_12.png","speciesKey":"VIVILLON:12"},"Vivillon [River Pattern]":{"normal":"VIVILLON_13.png","shiny":"VIVILLON_13.png","speciesKey":"VIVILLON:13"},"Vivillon [Sandstorm Pattern]":{"normal":"VIVILLON_14.png","shiny":"VIVILLON_14.png","speciesKey":"VIVILLON:14"},"Vivillon [Savanna Pattern]":{"normal":"VIVILLON_15.png","shiny":"VIVILLON_15.png","speciesKey":"VIVILLON:15"},"Vivillon [Sun Pattern]":{"normal":"VIVILLON_16.png","shiny":"VIVILLON_16.png","speciesKey":"VIVILLON:16"},"Vivillon [Tundra Pattern]":{"normal":"VIVILLON_17.png","shiny":"VIVILLON_17.png","speciesKey":"VIVILLON:17"},"Vivillon [Fancy Pattern]":{"normal":"VIVILLON_18.png","shiny":"VIVILLON_18.png","speciesKey":"VIVILLON:18"},"Vivillon [Poké Ball Pattern]":{"normal":"VIVILLON_19.png","shiny":"VIVILLON_19.png","speciesKey":"VIVILLON:19"},"Volbeat":{"normal":"VOLBEAT.png","shiny":"VOLBEAT.png","speciesKey":"VOLBEAT:0"},"Volcanion":{"normal":"VOLCANION.png","shiny":"VOLCANION.png","speciesKey":"VOLCANION:0"},"Volcarona":{"normal":"VOLCARONA.png","shiny":"VOLCARONA.png","speciesKey":"VOLCARONA:0"},"Voltorb":{"normal":"VOLTORB.png","shiny":"VOLTORB.png","speciesKey":"VOLTORB:0"},"Voltorb [Hisuian]":{"normal":"VOLTORB_1.png","shiny":"VOLTORB_1.png","speciesKey":"VOLTORB:1"},"Vullaby":{"normal":"VULLABY.png","shiny":"VULLABY.png","speciesKey":"VULLABY:0"},"Vulpix":{"normal":"VULPIX.png","shiny":"VULPIX.png","speciesKey":"VULPIX:0"},"Vulpix [Alolan]":{"normal":"VULPIX_1.png","shiny":"VULPIX_1.png","speciesKey":"VULPIX:1"},"Wailmer":{"normal":"WAILMER.png","shiny":"WAILMER.png","speciesKey":"WAILMER:0"},"Wailord":{"normal":"WAILORD.png","shiny":"WAILORD.png","speciesKey":"WAILORD:0"},"Walking Wake":{"normal":"WALKINGWAKE.png","shiny":"WALKINGWAKE.png","speciesKey":"WALKINGWAKE:0"},"Walrein":{"normal":"WALREIN.png","shiny":"WALREIN.png","speciesKey":"WALREIN:0"},"Wartortle":{"normal":"WARTORTLE.png","shiny":"WARTORTLE.png","speciesKey":"WARTORTLE:0"},"Watchog":{"normal":"WATCHOG.png","shiny":"WATCHOG.png","speciesKey":"WATCHOG:0"},"Wattrel":{"normal":"WATTREL.png","shiny":"WATTREL.png","speciesKey":"WATTREL:0"},"Weavile":{"normal":"WEAVILE.png","shiny":"WEAVILE.png","speciesKey":"WEAVILE:0"},"Weedle":{"normal":"WEEDLE.png","shiny":"WEEDLE.png","speciesKey":"WEEDLE:0"},"Weepinbell":{"normal":"WEEPINBELL.png","shiny":"WEEPINBELL.png","speciesKey":"WEEPINBELL:0"},"Weezing":{"normal":"WEEZING.png","shiny":"WEEZING.png","speciesKey":"WEEZING:0"},"Weezing [Galarian]":{"normal":"WEEZING_1.png","shiny":"WEEZING_1.png","speciesKey":"WEEZING:1"},"Whimsicott":{"normal":"WHIMSICOTT.png","shiny":"WHIMSICOTT.png","speciesKey":"WHIMSICOTT:0"},"Whirlipede":{"normal":"WHIRLIPEDE.png","shiny":"WHIRLIPEDE.png","speciesKey":"WHIRLIPEDE:0"},"Whiscash":{"normal":"WHISCASH.png","shiny":"WHISCASH.png","speciesKey":"WHISCASH:0"},"Whismur":{"normal":"WHISMUR.png","shiny":"WHISMUR.png","speciesKey":"WHISMUR:0"},"Wigglytuff":{"normal":"WIGGLYTUFF.png","shiny":"WIGGLYTUFF.png","speciesKey":"WIGGLYTUFF:0"},"Wiglett":{"normal":"WIGLETT.png","shiny":"WIGLETT.png","speciesKey":"WIGLETT:0"},"Wimpod":{"normal":"WIMPOD.png","shiny":"WIMPOD.png","speciesKey":"WIMPOD:0"},"Wingull":{"normal":"WINGULL.png","shiny":"WINGULL.png","speciesKey":"WINGULL:0"},"Wishiwashi":{"normal":"WISHIWASHI.png","shiny":"WISHIWASHI.png","speciesKey":"WISHIWASHI:0"},"Wishiwashi [School Form]":{"normal":"WISHIWASHI_1.png","shiny":"WISHIWASHI_1.png","speciesKey":"WISHIWASHI:1"},"Wobbuffet":{"normal":"WOBBUFFET.png","shiny":"WOBBUFFET.png","speciesKey":"WOBBUFFET:0"},"Wo-Chien":{"normal":"WOCHIEN.png","shiny":"WOCHIEN.png","speciesKey":"WOCHIEN:0"},"Woobat":{"normal":"WOOBAT.png","shiny":"WOOBAT.png","speciesKey":"WOOBAT:0"},"Wooloo":{"normal":"WOOLOO.png","shiny":"WOOLOO.png","speciesKey":"WOOLOO:0"},"Wooper":{"normal":"WOOPER.png","shiny":"WOOPER.png","speciesKey":"WOOPER:0"},"Wooper [Paldean]":{"normal":"WOOPER_1.png","shiny":"WOOPER_1.png","speciesKey":"WOOPER:1"},"Wormadam":{"normal":"WORMADAM.png","shiny":"WORMADAM.png","speciesKey":"WORMADAM:0"},"Wormadam [Sandy Cloak]":{"normal":"WORMADAM_1.png","shiny":"WORMADAM_1.png","speciesKey":"WORMADAM:1"},"Wormadam [Trash Cloak]":{"normal":"WORMADAM_2.png","shiny":"WORMADAM_2.png","speciesKey":"WORMADAM:2"},"Wugtrio":{"normal":"WUGTRIO.png","shiny":"WUGTRIO.png","speciesKey":"WUGTRIO:0"},"Wurmple":{"normal":"WURMPLE.png","shiny":"WURMPLE.png","speciesKey":"WURMPLE:0"},"Wynaut":{"normal":"WYNAUT.png","shiny":"WYNAUT.png","speciesKey":"WYNAUT:0"},"Wyrdeer":{"normal":"WYRDEER.png","shiny":"WYRDEER.png","speciesKey":"WYRDEER:0"},"Xatu":{"normal":"XATU.png","shiny":"XATU.png","speciesKey":"XATU:0"},"Xerneas":{"normal":"XERNEAS.png","shiny":"XERNEAS.png","speciesKey":"XERNEAS:0"},"Xerneas [Active Mode]":{"normal":"XERNEAS_1.png","shiny":"XERNEAS_1.png","speciesKey":"XERNEAS:1"},"Xurkitree":{"normal":"XURKITREE.png","shiny":"XURKITREE.png","speciesKey":"XURKITREE:0"},"Yamask":{"normal":"YAMASK.png","shiny":"YAMASK.png","speciesKey":"YAMASK:0"},"Yamask [Galarian]":{"normal":"YAMASK_1.png","shiny":"YAMASK_1.png","speciesKey":"YAMASK:1"},"Yamper":{"normal":"YAMPER.png","shiny":"YAMPER.png","speciesKey":"YAMPER:0"},"Yanma":{"normal":"YANMA.png","shiny":"YANMA.png","speciesKey":"YANMA:0"},"Yanmega":{"normal":"YANMEGA.png","shiny":"YANMEGA.png","speciesKey":"YANMEGA:0"},"Yungoos":{"normal":"YUNGOOS.png","shiny":"YUNGOOS.png","speciesKey":"YUNGOOS:0"},"Yveltal":{"normal":"YVELTAL.png","shiny":"YVELTAL.png","speciesKey":"YVELTAL:0"},"Zacian":{"normal":"ZACIAN.png","shiny":"ZACIAN.png","speciesKey":"ZACIAN:0"},"Zacian [Crowned Sword]":{"normal":"ZACIAN_1.png","shiny":"ZACIAN_1.png","speciesKey":"ZACIAN:1"},"Zamazenta":{"normal":"ZAMAZENTA.png","shiny":"ZAMAZENTA.png","speciesKey":"ZAMAZENTA:0"},"Zamazenta [Crowned Shield]":{"normal":"ZAMAZENTA_1.png","shiny":"ZAMAZENTA_1.png","speciesKey":"ZAMAZENTA:1"},"Zangoose":{"normal":"ZANGOOSE.png","shiny":"ZANGOOSE.png","speciesKey":"ZANGOOSE:0"},"Zapdos":{"normal":"ZAPDOS.png","shiny":"ZAPDOS.png","speciesKey":"ZAPDOS:0"},"Zapdos [Galarian]":{"normal":"ZAPDOS_1.png","shiny":"ZAPDOS_1.png","speciesKey":"ZAPDOS:1"},"Zarude":{"normal":"ZARUDE.png","shiny":"ZARUDE.png","speciesKey":"ZARUDE:0"},"Zebstrika":{"normal":"ZEBSTRIKA.png","shiny":"ZEBSTRIKA.png","speciesKey":"ZEBSTRIKA:0"},"Zekrom":{"normal":"ZEKROM.png","shiny":"ZEKROM.png","speciesKey":"ZEKROM:0"},"Zeraora":{"normal":"ZERAORA.png","shiny":"ZERAORA.png","speciesKey":"ZERAORA:0"},"Zeraora [Mega Zeraora]":{"normal":"ZERAORA_1.png","shiny":"ZERAORA_1.png","speciesKey":"ZERAORA:1"},"Zigzagoon":{"normal":"ZIGZAGOON.png","shiny":"ZIGZAGOON.png","speciesKey":"ZIGZAGOON:0"},"Zigzagoon [Galarian]":{"normal":"ZIGZAGOON_1.png","shiny":"ZIGZAGOON_1.png","speciesKey":"ZIGZAGOON:1"},"Zoroark":{"normal":"ZOROARK.png","shiny":"ZOROARK.png","speciesKey":"ZOROARK:0"},"Zoroark [Hisuian]":{"normal":"ZOROARK_1.png","shiny":"ZOROARK_1.png","speciesKey":"ZOROARK:1"},"Zorua":{"normal":"ZORUA.png","shiny":"ZORUA.png","speciesKey":"ZORUA:0"},"Zorua [Hisuian]":{"normal":"ZORUA_1.png","shiny":"ZORUA_1.png","speciesKey":"ZORUA:1"},"Zubat":{"normal":"ZUBAT.png","shiny":"ZUBAT.png","speciesKey":"ZUBAT:0"},"Zweilous":{"normal":"ZWEILOUS.png","shiny":"ZWEILOUS.png","speciesKey":"ZWEILOUS:0"},"Zygarde":{"normal":"ZYGARDE.png","shiny":"ZYGARDE.png","speciesKey":"ZYGARDE:0"},"Zygarde [10% Forme]":{"normal":"ZYGARDE_1.png","shiny":"ZYGARDE_1.png","speciesKey":"ZYGARDE:1"},"Zygarde [Complete Forme]":{"normal":"ZYGARDE_2.png","shiny":"ZYGARDE_2.png","speciesKey":"ZYGARDE:2"},"Zygarde [Form 3]":{"normal":"ZYGARDE_3.png","shiny":"ZYGARDE_3.png","speciesKey":"ZYGARDE:3"},"Zygarde [Mega Zygarde]":{"normal":"ZYGARDE_4.png","shiny":"ZYGARDE_4.png","speciesKey":"ZYGARDE:4"},"Zygarde [Form 5]":{"normal":"ZYGARDE_5.png","shiny":"ZYGARDE_5.png","speciesKey":"ZYGARDE:5"}};
/* UTOPIA_ICON_MAP_END */

if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function (searchElement, fromIndex) { // eslint-disable-line no-extend-native
		var k;
		if (this == null) {
			throw new TypeError('"this" equals null or n is undefined');
		}
		var O = Object(this);
		var len = O.length >>> 0;
		if (len === 0) {
			return -1;
		}
		var n = +fromIndex || 0;
		if (Math.abs(n) === Infinity) {
			n = 0;
		}
		if (n >= len) {
			return -1;
		}
		k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
		while (k < len) {
			if (k in O && O[k] === searchElement) {
				return k;
			}
			k++;
		}
		return -1;
	};
}

function startsWith(string, target) {
	return (string || '').slice(0, target.length) === target;
}

var LEGACY_STATS_RBY = ["hp", "at", "df", "sl", "sp"];
var LEGACY_STATS_GSC = ["hp", "at", "df", "sa", "sd", "sp"];
var LEGACY_STATS = [[], LEGACY_STATS_RBY, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC, LEGACY_STATS_GSC];
var HIDDEN_POWER_REGEX = /Hidden Power (\w*)/;

var CALC_STATUS = {
	'Healthy': '',
	'Paralyzed': 'par',
	'Poisoned': 'psn',
	'Badly Poisoned': 'tox',
	'Burned': 'brn',
	'Asleep': 'slp',
	'Frostbitten': 'frz'
};

function legacyStatToStat(st) {
	switch (st) {
		case 'hp':
			return "hp";
		case 'at':
			return "atk";
		case 'df':
			return "def";
		case 'sa':
			return "spa";
		case 'sd':
			return "spd";
		case 'sp':
			return "spe";
		case 'sl':
			return "spc";
	}
}

// input field validation
var bounds = {
	"level": [0, 100],
	"base": [1, 255],
	"evs": [0, 252],
	"ivs": [0, 31],
	"dvs": [0, 15],
	"move-bp": [0, 65535]
};
for (var bounded in bounds) {
	attachValidation(bounded, bounds[bounded][0], bounds[bounded][1]);
}
function attachValidation(clazz, min, max) {
	$("." + clazz).keyup(function () {
		validate($(this), min, max);
	});
}
function validate(obj, min, max) {
	obj.val(Math.max(min, Math.min(max, ~~obj.val())));
}

$("input:radio[name='format']").change(function () {
	var gameType = $("input:radio[name='format']:checked").val();
	if (gameType === 'Singles') {
		$("input:checkbox[name='ruin']:checked").prop("checked", false);
	}
	$(".format-specific." + gameType.toLowerCase()).each(function () {
		if ($(this).hasClass("gen-specific") && !$(this).hasClass("g" + gen)) {
			return;
		}
		$(this).show();
	});
	$(".format-specific").not("." + gameType.toLowerCase()).hide();
});

// auto-calc stats and current HP on change
$(".level").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcHP(poke);
	calcStats(poke);
});
$(".nature").bind("keyup change", function () {
	calcStats($(this).closest(".poke-info"));
});
$(".hp .base, .hp .evs, .hp .ivs").bind("keyup change", function () {
	calcHP($(this).closest(".poke-info"));
});
$(".at .base, .at .evs, .at .ivs").bind("keyup change", function () {
	calcStat($(this).closest(".poke-info"), 'at');
});
$(".df .base, .df .evs, .df .ivs").bind("keyup change", function () {
	calcStat($(this).closest(".poke-info"), 'df');
});
$(".sa .base, .sa .evs, .sa .ivs").bind("keyup change", function () {
	calcStat($(this).closest(".poke-info"), 'sa');
});
$(".sd .base, .sd .evs, .sd .ivs").bind("keyup change", function () {
	calcStat($(this).closest(".poke-info"), 'sd');
});
$(".sp .base, .sp .evs, .sp .ivs").bind("keyup change", function () {
	calcStat($(this).closest(".poke-info"), 'sp');
});
$(".sl .base").keyup(function () {
	calcStat($(this).closest(".poke-info"), 'sl');
});
$(".at .dvs").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcStat(poke, 'at');
	poke.find(".hp .dvs").val(getHPDVs(poke));
	calcHP(poke);
});
$(".df .dvs").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcStat(poke, 'df');
	poke.find(".hp .dvs").val(getHPDVs(poke));
	calcHP(poke);
});
$(".sa .dvs").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcStat(poke, 'sa');
	poke.find(".sd .dvs").val($(this).val());
	calcStat(poke, 'sd');
	poke.find(".hp .dvs").val(getHPDVs(poke));
	calcHP(poke);
});
$(".sp .dvs").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcStat(poke, 'sp');
	poke.find(".hp .dvs").val(getHPDVs(poke));
	calcHP(poke);
});
$(".sl .dvs").keyup(function () {
	var poke = $(this).closest(".poke-info");
	calcStat(poke, 'sl');
	poke.find(".hp .dvs").val(getHPDVs(poke));
	calcHP(poke);
});

function getHPDVs(poke) {
	return (~~poke.find(".at .dvs").val() % 2) * 8 +
		(~~poke.find(".df .dvs").val() % 2) * 4 +
		(~~poke.find(".sp .dvs").val() % 2) * 2 +
		(~~poke.find(gen === 1 ? ".sl .dvs" : ".sa .dvs").val() % 2);
}

function calcStats(poke) {
	for (var i = 0; i < LEGACY_STATS[gen].length; i++) {
		calcStat(poke, LEGACY_STATS[gen][i]);
	}
}

function calcCurrentHP(poke, max, percent, skipDraw) {
	var current = Math.round(Number(percent) * Number(max) / 100);
	poke.find(".current-hp").val(current);
	if (!skipDraw) drawHealthBar(poke, max, current);
	return current;
}
function calcPercentHP(poke, max, current, skipDraw) {
	var percent = Math.round(100 * Number(current) / Number(max));
	if (percent === 0 && current > 0) {
		percent = 1;
	} else if (percent === 100 & current < max) {
		percent = 99;
	}

	poke.find(".percent-hp").val(percent);
	if (!skipDraw) drawHealthBar(poke, max, current);
	return percent;
}
function drawHealthBar(poke, max, current) {
	var fillPercent = 100 * current / max;
	var fillColor = fillPercent > 50 ? "green" : fillPercent > 20 ? "yellow" : "red";

	var healthbar = poke.find(".hpbar");
	healthbar.addClass("hp-" + fillColor);
	var unwantedColors = ["green", "yellow", "red"];
	unwantedColors.splice(unwantedColors.indexOf(fillColor), 1);
	for (var i = 0; i < unwantedColors.length; i++) {
		healthbar.removeClass("hp-" + unwantedColors[i]);
	}
	healthbar.css("background", "linear-gradient(to right, " + fillColor + " " + fillPercent + "%, white 0%");
}
// TODO: these HP inputs should really be input type=number with min=0, step=1, constrained by max=maxHP or 100
$(".current-hp").keyup(function () {
	var max = $(this).parent().children(".max-hp").text();
	validate($(this), 0, max);
	var current = $(this).val();
	calcPercentHP($(this).parent(), max, current);
});
$(".percent-hp").keyup(function () {
	var max = $(this).parent().children(".max-hp").text();
	validate($(this), 0, 100);
	var percent = $(this).val();
	calcCurrentHP($(this).parent(), max, percent);
});

$(".ability").bind("keyup change", function () {
	$(this).closest(".poke-info").find(".move-hits").val($(this).val() === 'Skill Link' ? 5 : 3);

	var ability = $(this).closest(".poke-info").find(".ability").val();

	var TOGGLE_ABILITIES = ['Flash Fire', 'Intimidate', 'Minus', 'Plus', 'Slow Start', 'Unburden', 'Stakeout'];

	if (TOGGLE_ABILITIES.indexOf(ability) >= 0) {
		$(this).closest(".poke-info").find(".abilityToggle").show();
	} else {
		$(this).closest(".poke-info").find(".abilityToggle").hide();
	}

	if (ability === "Supreme Overlord") {
		$(this).closest(".poke-info").find(".alliesFainted").show();
	} else {
		$(this).closest(".poke-info").find(".alliesFainted").val('0');
		$(this).closest(".poke-info").find(".alliesFainted").hide();

	}
});

$("#p1 .ability").bind("keyup change", function () {
	autosetWeather($(this).val(), 0);
	autosetTerrain($(this).val(), 0);
});

var lastManualWeather = "";
var lastAutoWeather = ["", ""];
function autosetWeather(ability, i) {
	var currentWeather = $("input:radio[name='weather']:checked").val();
	if (lastAutoWeather.indexOf(currentWeather) === -1) {
		lastManualWeather = currentWeather;
		lastAutoWeather[1 - i] = "";
	}
	switch (ability) {
		case "Drought":
		case "Orichalcum Pulse":
			lastAutoWeather[i] = "Sun";
			$("#sun").prop("checked", true);
			break;
		case "Drizzle":
			lastAutoWeather[i] = "Rain";
			$("#rain").prop("checked", true);
			break;
		case "Sand Stream":
			lastAutoWeather[i] = "Sand";
			$("#sand").prop("checked", true);
			break;
		case "Snow Warning":
			lastAutoWeather[i] = "Snow";
			$("#snow").prop("checked", true);
			break;
		case "Desolate Land":
			lastAutoWeather[i] = "Harsh Sunshine";
			$("#harsh-sunshine").prop("checked", true);
			break;
		case "Primordial Sea":
			lastAutoWeather[i] = "Heavy Rain";
			$("#heavy-rain").prop("checked", true);
			break;
		case "Delta Stream":
			lastAutoWeather[i] = "Strong Winds";
			$("#strong-winds").prop("checked", true);
			break;
		default:
			break;
	}
}

var lastManualTerrain = "";
var lastAutoTerrain = ["", ""];
function autosetTerrain(ability, i) {
	var currentTerrain = $("input:checkbox[name='terrain']:checked").val() || "No terrain";
	if (lastAutoTerrain.indexOf(currentTerrain) === -1) {
		lastManualTerrain = currentTerrain;
		lastAutoTerrain[1 - i] = "";
	}
	// terrain input uses checkbox instead of radio, need to uncheck all first
	$("input:checkbox[name='terrain']:checked").prop("checked", false);
	switch (ability) {
		case "Electric Surge":
		case "Hadron Engine":
			lastAutoTerrain[i] = "Electric";
			$("#electric").prop("checked", true);
			break;
		case "Grassy Surge":
			lastAutoTerrain[i] = "Grassy";
			$("#grassy").prop("checked", true);
			break;
		case "Misty Surge":
			lastAutoTerrain[i] = "Misty";
			$("#misty").prop("checked", true);
			break;
		case "Psychic Surge":
			lastAutoTerrain[i] = "Psychic";
			$("#psychic").prop("checked", true);
			break;
		default:
			lastAutoTerrain[i] = "";
			var newTerrain = lastAutoTerrain[1 - i] !== "" ? lastAutoTerrain[1 - i] : lastManualTerrain;
			if ("No terrain" !== newTerrain) {
				$("input:checkbox[name='terrain'][value='" + newTerrain + "']").prop("checked", true);
			}
			break;
	}
}

$("#p1 .item").bind("keyup change", function () {
	autosetStatus("#p1", $(this).val());
});

var lastManualStatus = { "#p1": "Healthy" };
var lastAutoStatus = { "#p1": "Healthy" };
function autosetStatus(p, item) {
	var currentStatus = $(p + " .status").val();
	if (item === "Flame Orb") {
		lastAutoStatus[p] = "Burned";
		$(p + " .status").val("Burned");
		$(p + " .status").change();
	} else if (item === "Toxic Orb") {
		lastAutoStatus[p] = "Badly Poisoned";
		$(p + " .status").val("Badly Poisoned");
		$(p + " .status").change();
	}
}

$(".status").bind("keyup change", function () {
	if ($(this).val() === 'Badly Poisoned') {
		$(this).parent().children(".toxic-counter").show();
	} else {
		$(this).parent().children(".toxic-counter").hide();
	}
});

var lockerMove = "";
// auto-update move details on select
$(".move-selector").change(function () {
	var moveName = $(this).val();
	var move = moves[moveName] || moves['(No Move)'];
	var moveGroupObj = $(this).parent();
	moveGroupObj.children(".move-bp").val(moveName === 'Present' ? 40 : move.bp);
	var m = moveName.match(HIDDEN_POWER_REGEX);
	if (m) {
		var pokeObj = $(this).closest(".poke-info");
		var pokemon = createPokemon(pokeObj);
		var actual = calc.Stats.getHiddenPower(GENERATION, pokemon.ivs);
		if (actual.type !== m[1]) {
			var hpIVs = calc.Stats.getHiddenPowerIVs(GENERATION, m[1]);
			if (hpIVs && gen < 7) {
				for (var i = 0; i < LEGACY_STATS[gen].length; i++) {
					var legacyStat = LEGACY_STATS[gen][i];
					var stat = legacyStatToStat(legacyStat);
					pokeObj.find("." + legacyStat + " .ivs").val(hpIVs[stat] !== undefined ? hpIVs[stat] : 31);
					pokeObj.find("." + legacyStat + " .dvs").val(hpIVs[stat] !== undefined ? calc.Stats.IVToDV(hpIVs[stat]) : 15);
				}
				if (gen < 3) {
					var hpDV = calc.Stats.getHPDV({
						atk: pokeObj.find(".at .ivs").val(),
						def: pokeObj.find(".df .ivs").val(),
						spe: pokeObj.find(".sp .ivs").val(),
						spc: pokeObj.find(".sa .ivs").val()
					});
					pokeObj.find(".hp .ivs").val(calc.Stats.DVToIV(hpDV));
					pokeObj.find(".hp .dvs").val(hpDV);
				}
				pokeObj.change();
				moveGroupObj.children(".move-bp").val(gen >= 6 ? 60 : 70);
			}
		} else {
			moveGroupObj.children(".move-bp").val(actual.power);
		}
	} else if (gen >= 2 && gen <= 6 && HIDDEN_POWER_REGEX.test($(this).attr('data-prev'))) {
		// If this selector was previously Hidden Power but now isn't, reset all IVs/DVs to max.
		var pokeObj = $(this).closest(".poke-info");
		for (var i = 0; i < LEGACY_STATS[gen].length; i++) {
			var legacyStat = LEGACY_STATS[gen][i];
			pokeObj.find("." + legacyStat + " .ivs").val(31);
			pokeObj.find("." + legacyStat + " .dvs").val(15);
		}
	}
	$(this).attr('data-prev', moveName);
	moveGroupObj.children(".move-type").val(move.type);
	moveGroupObj.children(".move-cat").val(move.category);
	moveGroupObj.children(".move-crit").prop("checked", move.willCrit === true);

	var stat = move.category === 'Special' ? 'spa' : 'atk';
	var dropsStats =
		move.self && move.self.boosts && move.self.boosts[stat] && move.self.boosts[stat] < 0;
	if (Array.isArray(move.multihit)) {
		moveGroupObj.children(".stat-drops").hide();
		moveGroupObj.children(".move-hits").show();
		var pokemon = $(this).closest(".poke-info");
		var moveHits = (pokemon.find(".ability").val() === 'Skill Link') ? 5 : 3;
		moveGroupObj.children(".move-hits").val(moveHits);
	} else if (dropsStats) {
		moveGroupObj.children(".move-hits").hide();
		moveGroupObj.children(".stat-drops").show();
	} else {
		moveGroupObj.children(".move-hits").hide();
		moveGroupObj.children(".stat-drops").hide();
	}
	moveGroupObj.children(".move-z").prop("checked", false);
});

/* UTOPIA_PLAYER_MOVE_COMPACTION_V5_2026 */
var utopiaReorderingMoves = false;

function utopiaReorderPlayerMoves() {
    if (utopiaReorderingMoves) return;

    var selectors = $('#p1 .move-selector');

    if (selectors.length !== 4) return;

    var current = selectors.map(function () {
        return String($(this).val() || '(No Move)');
    }).get();

    var filled = current.filter(function (move) {
        return move !== '(No Move)' && move !== '';
    });

    while (filled.length < 4) {
        filled.push('(No Move)');
    }

    var needsUpdate = false;

    for (var i = 0; i < 4; i++) {
        if (current[i] !== filled[i]) {
            needsUpdate = true;
            break;
        }
    }

    if (!needsUpdate) return;

    utopiaReorderingMoves = true;

    try {
        selectors.each(function (index) {
            if (current[index] !== filled[index]) {
                $(this).val(filled[index]);
            }
        });

        selectors.each(function (index) {
            if (current[index] !== filled[index]) {
                $(this).trigger('change');
            }
        });
    } finally {
        utopiaReorderingMoves = false;
    }
}

$(document).on(
    'change.utopiaPlayerMoveCompaction',
    '#p1 .move-selector',
    function () {
        if (utopiaReorderingMoves) return;

        utopiaReorderPlayerMoves();
    }
);

$(".item").change(function () {
	var itemName = $(this).val();
	var $metronomeControl = $(this).closest('.poke-info').find('.metronome');
	if (itemName === "Metronome") {
		$metronomeControl.show();
	} else {
		$metronomeControl.hide();
	}
});

function smogonAnalysis(pokemonName) {
	var generation = ["rb", "gs", "rs", "dp", "bw", "xy", "sm", "ss", "sv"][gen - 1];
	return "https://smogon.com/dex/" + generation + "/pokemon/" + pokemonName.toLowerCase() + "/";
}

function sortmons(a, b) {
	function slotOf(full) {
    var value = full.substring(full.indexOf("]") + 1);
    var species = value.substring(0, value.indexOf(" ("));
    var label = value.substring(value.indexOf(" (") + 2, value.lastIndexOf(")"));
    var set = SETDEX_SS[species] && SETDEX_SS[species][label];
    return set && Number.isFinite(Number(set.slot)) ? Number(set.slot) : 999;
  }
  return slotOf(a) - slotOf(b)
}

function isMonFromCurrentTrainer(current, neew) {
  if (!current) return false;
  function trainerID(full) {
    var name = full.substring(0, full.indexOf(' ('));
    var label = full.substring(full.indexOf(' (') + 2, full.lastIndexOf(')'));
    return SETDEX_SS[name] && SETDEX_SS[name][label] && SETDEX_SS[name][label].trainerId;
  }
  return !!trainerID(current.dataset.id) && trainerID(current.dataset.id) === trainerID(neew);
}
var nextTrainerId = 1;
var previousTrainerId = 1;
// auto-update set details on select top bar pokemon
$(".set-selector").change(function () {
	window.NO_CALC = true;
	try {
	var fullSetName = $(this).val();
	var nextTrainer = "";
	var monNumbers = 0
	if ($(this).hasClass('opposing')) {
		topPokemonIcon(fullSetName, $("#p2mon")[0])
		var currentTrainerMon = document.getElementsByClassName('opposite-pok')[0]
		
		if (isMonFromCurrentTrainer(currentTrainerMon, fullSetName)){
			// don't reload
		}else{
			CURRENT_TRAINER_POKS = get_trainer_poks(fullSetName)
			var next_poks = CURRENT_TRAINER_POKS.sort(sortmons)
			monNumbers = next_poks.length;
			var frag = new DocumentFragment();
			$('.trainer-pok-list-opposing').html('');
			for (i in next_poks) {
				if (next_poks[i][0].includes($('input.opposing').val())) {
					continue
				}
				var pok_name = next_poks[i].substring(next_poks[i].indexOf("]") + 1).split(" (")[0]
				if (pok_name == "Zygarde-10%") {
					pok_name = "Zygarde-10%25"
				}//this ruined my day
				var newPoke = document.createElement("img");
				newPoke.className = "opposite-pok right-side";
				var fullTrainerSet = next_poks[i].substring(next_poks[i].indexOf("]") + 1);
        var trainerSpecies = fullTrainerSet.substring(0, fullTrainerSet.indexOf(" ("));
        var trainerLabel = fullTrainerSet.substring(
          fullTrainerSet.indexOf(" (") + 2,
          fullTrainerSet.lastIndexOf(")")
        );
        var trainerSet = SETDEX_SS[trainerSpecies] &&
          SETDEX_SS[trainerSpecies][trainerLabel];
        newPoke.src = getSrcImgPokemon({
          name: trainerSpecies,
          shiny: trainerSet ? trainerSet.shiny === true : false
        });
				newPoke.title = utopiaCleanLabel(trainerSpecies + ' (' + trainerLabel + ')');
				nextTrainer=`${next_poks[i]}`
				newPoke.dataset.id = CURRENT_TRAINER_POKS[i].substring(CURRENT_TRAINER_POKS[i].indexOf("]") + 1);
				frag.append(newPoke);
			}
		}
		if (nextTrainer){
			let trainerId = nextTrainer.match(/^\[\d+/)[0].substring(1);
			nextTrainerId = parseInt(trainerId) + 1;
      previousTrainerId = parseInt(trainerId) - 1;
		}
		
		
	}

	$('.trainer-pok-list-opposing').append(frag);
	for (mon of document.getElementsByClassName('trainer-pok-list-opposing')[0].children){
		mon.addEventListener("dragstart", dragstart_handler);
	}
	var pokemonName = fullSetName.substring(0, fullSetName.indexOf(" ("));
	var setName = fullSetName.substring(fullSetName.indexOf("(") + 1, fullSetName.lastIndexOf(")"));
	var pokemon = pokedex[pokemonName];
	if (pokemon) {
		var pokeObj = $(this).closest(".poke-info");
		if (stickyMoves.getSelectedSide() === pokeObj.prop("id")) {
			stickyMoves.clearStickyMove();
		}
		pokeObj.find(".teraToggle").prop("checked", false);
		pokeObj.find(".analysis").attr("href", smogonAnalysis(pokemonName));
		pokeObj.find(".type1").val(pokemon.types[0]);
		pokeObj.find(".type2").val(pokemon.types[1]);
		pokeObj.find(".hp .base").val(pokemon.bs.hp);
		var i;
		for (i = 0; i < LEGACY_STATS[gen].length; i++) {
			pokeObj.find("." + LEGACY_STATS[gen][i] + " .base").val(pokemon.bs[LEGACY_STATS[gen][i]]);
		}
		pokeObj.find(".boost").val(0);
		pokeObj.find(".percent-hp").val(100);
		pokeObj.find(".status").val("Healthy");
		$(".status").change();
		var moveObj;
		var abilityObj = pokeObj.find(".ability");
		var itemObj = pokeObj.find(".item");
		var randset = $("#randoms").prop("checked") ? randdex[pokemonName] : undefined;
		var regSets = pokemonName in setdex && setName in setdex[pokemonName];
		if (randset) {
			var listItems = randdex[pokemonName].items ? randdex[pokemonName].items : [];
			var listAbilities = randdex[pokemonName].abilities ? randdex[pokemonName].abilities : [];
			if (gen >= 3) $(this).closest('.poke-info').find(".ability-pool").show();
			$(this).closest('.poke-info').find(".extraSetAbilities").text(listAbilities.join(', '));
			if (gen >= 2) $(this).closest('.poke-info').find(".item-pool").show();
			$(this).closest('.poke-info').find(".extraSetItems").text(listItems.join(', '));
			if (gen >= 9) {
				$(this).closest('.poke-info').find(".role-pool").show();
				$(this).closest('.poke-info').find(".tera-type-pool").show();
			}
			var listRoles = randdex[pokemonName].roles ? Object.keys(randdex[pokemonName].roles) : [];
			$(this).closest('.poke-info').find(".extraSetRoles").text(listRoles.join(', '));
			var listTeraTypes = [];
			if (randdex[pokemonName].roles) {
				for (var roleName in randdex[pokemonName].roles) {
					var role = randdex[pokemonName].roles[roleName];
					for (var q = 0; q < role.teraTypes.length; q++) {
						if (listTeraTypes.indexOf(role.teraTypes[q]) === -1) {
							listTeraTypes.push(role.teraTypes[q]);
						}
					}
				}
			}
			pokeObj.find(".teraType").val(listTeraTypes[0] || pokemon.types[0]);
			$(this).closest('.poke-info').find(".extraSetTeraTypes").text(listTeraTypes.join(', '));
		} else {
			$(this).closest('.poke-info').find(".ability-pool").hide();
			$(this).closest('.poke-info').find(".item-pool").hide();
			$(this).closest('.poke-info').find(".role-pool").hide();
			$(this).closest('.poke-info').find(".tera-type-pool").hide();
		}
		if (regSets || randset) {
			var set = regSets ? correctHiddenPower(setdex[pokemonName][setName]) : randset;
			if (regSets) {
				pokeObj.find(".teraType").val(set.teraType || pokemon.types[0]);
			}
			pokeObj.find(".level").val(set.level);
			pokeObj.find(".hp .evs").val((set.evs && set.evs.hp !== undefined) ? set.evs.hp : 0);
			pokeObj.find(".hp .ivs").val((set.ivs && set.ivs.hp !== undefined) ? set.ivs.hp : 31);
			pokeObj.find(".hp .dvs").val((set.dvs && set.dvs.hp !== undefined) ? set.dvs.hp : 15);
			for (i = 0; i < LEGACY_STATS[gen].length; i++) {
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .evs").val(
					(set.evs && set.evs[LEGACY_STATS[gen][i]] !== undefined) ?
						set.evs[LEGACY_STATS[gen][i]] : ($("#randoms").prop("checked") ? 84 : 0));
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .ivs").val(
					(set.ivs && set.ivs[LEGACY_STATS[gen][i]] !== undefined) ? set.ivs[LEGACY_STATS[gen][i]] : 31);
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .dvs").val(
					(set.dvs && set.dvs[LEGACY_STATS[gen][i]] !== undefined) ? set.dvs[LEGACY_STATS[gen][i]] : 15);
			}
			setSelectValueIfValid(pokeObj.find(".nature"), set.nature, "Hardy");
			var abilityFallback = (typeof pokemon.abilities !== "undefined") ? pokemon.abilities[0] : "";
			if ($("#randoms").prop("checked")) {
				setSelectValueIfValid(abilityObj, randset.abilities && randset.abilities[0], abilityFallback);
				setSelectValueIfValid(itemObj, randset.items && randset.items[0], "");
			} else {
				setSelectValueIfValid(abilityObj, set.ability, abilityFallback);
				setSelectValueIfValid(itemObj, set.item, "");
			}
			/* UTOPIA_V6_THICK_CLUB_TRAINER_HP_20261105: determine the type of unspecified trainer Hidden Power. */
			var setMoves = set.moves;
			if (regSets && set.trainerId && Array.isArray(setMoves) &&
				setMoves.indexOf('Hidden Power') !== -1) {
				var hpIVs = set.ivs || {};
				var hpTypeIVs = {
					hp: hpIVs.hp === undefined ? 31 : hpIVs.hp,
					atk: hpIVs.at === undefined ? 31 : hpIVs.at,
					def: hpIVs.df === undefined ? 31 : hpIVs.df,
					spa: hpIVs.sa === undefined ? 31 : hpIVs.sa,
					spd: hpIVs.sd === undefined ? 31 : hpIVs.sd,
					spe: hpIVs.sp === undefined ? 31 : hpIVs.sp
				};
				var hpType = calc.Stats.getHiddenPower(GENERATION, hpTypeIVs).type;
				var typedMove = 'Hidden Power ' + hpType;
				if (GENERATION.moves.get(calc.toID(typedMove))) {
					setMoves = setMoves.map(function(moveName) {
						return moveName === 'Hidden Power' ? typedMove : moveName;
					});
				}
			}
			if (randset) {
				if (gen < 9) {
					setMoves = randset.moves;
				} else {
					setMoves = [];
					for (var role in randset.roles) {
						for (var q = 0; q < randset.roles[role].moves.length; q++) {
							var moveName = randset.roles[role].moves[q];
							if (setMoves.indexOf(moveName) === -1) setMoves.push(moveName);
						}
					}
				}
			}
			var moves = selectMovesFromRandomOptions(setMoves);
			for (i = 0; i < 4; i++) {
				moveObj = pokeObj.find(".move" + (i + 1) + " select.move-selector");
				moveObj.attr('data-prev', moveObj.val());
				setSelectValueIfValid(moveObj, moves[i], "(No Move)");
				moveObj.change();
			}
			if (randset) {
				$(this).closest('.poke-info').find(".move-pool").show();
				$(this).closest('.poke-info').find(".extraSetMoves").html(formatMovePool(setMoves));
			}
		} else {
			pokeObj.find(".teraType").val(pokemon.types[0]);
			pokeObj.find(".level").val(100);
			pokeObj.find(".hp .evs").val(0);
			pokeObj.find(".hp .ivs").val(31);
			pokeObj.find(".hp .dvs").val(15);
			for (i = 0; i < LEGACY_STATS[gen].length; i++) {
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .evs").val(0);
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .ivs").val(31);
				pokeObj.find("." + LEGACY_STATS[gen][i] + " .dvs").val(15);
			}
			pokeObj.find(".nature").val("Hardy");
			abilityObj.val("");
			itemObj.val("");
			for (i = 0; i < 4; i++) {
				moveObj = pokeObj.find(".move" + (i + 1) + " select.move-selector");
				moveObj.attr('data-prev', moveObj.val());
				moveObj.val("(No Move)");
				moveObj.change();
			}
			if ($("#randoms").prop("checked")) {
				$(this).closest('.poke-info').find(".move-pool").hide();
			}
		}
		if (typeof getSelectedTiers === "function") { // doesn't exist when in 1vs1 mode
			var format = getSelectedTiers()[0];
			var is50lvl = startsWith(format, "VGC") || startsWith(format, "Battle Spot");
			//var isDoubles = format === 'Doubles' || has50lvl; *TODO*
			if (format === "LC") pokeObj.find(".level").val(5);
			if (is50lvl) pokeObj.find(".level").val(50);
			//if (isDoubles) field.gameType = 'Doubles'; *TODO*
		}
		var formeObj = $(this).siblings().find(".forme").parent();
		itemObj.prop("disabled", false);
		var baseForme;
		if (pokemon.baseSpecies && pokemon.baseSpecies !== pokemon.name) {
			baseForme = pokedex[pokemon.baseSpecies];
		}
		if (pokemon.otherFormes) {
			showFormes(formeObj, pokemonName, pokemon, pokemonName);
		} else if (baseForme && baseForme.otherFormes) {
			showFormes(formeObj, pokemonName, baseForme, pokemon.baseSpecies);
		} else {
			formeObj.hide();
		}
		if ($(this).hasClass("player")) {
			topPokemonIcon(
				fullSetName,
				document.getElementById("p1mon")
			);
		}
		calcHP(pokeObj);
		calcStats(pokeObj);
		abilityObj.change();
		itemObj.change();
		if (pokemon.gender === "N") {
			pokeObj.find(".gender").parent().hide();
			pokeObj.find(".gender").val("");
		} else pokeObj.find(".gender").parent().show();
	}
	} finally {
		window.NO_CALC = false;
	}
});

function formatMovePool(moves) {
	var formatted = [];
	for (var i = 0; i < moves.length; i++) {
		formatted.push(isKnownDamagingMove(moves[i]) ? moves[i] : '<i>' + moves[i] + '</i>');
	}
	return formatted.join(', ');
}

function isKnownDamagingMove(move) {
	var m = GENERATION.moves.get(calc.toID(move));
	return m && m.basePower;
}

function selectMovesFromRandomOptions(moves) {
	var selected = [];

	var nonDamaging = [];
	for (var i = 0; i < moves.length; i++) {
		if (isKnownDamagingMove(moves[i])) {
			selected.push(moves[i]);
			if (selected.length >= 4) break;
		} else {
			nonDamaging.push(moves[i]);
		}
	}

	while (selected.length < 4 && nonDamaging.length) {
		selected.push(nonDamaging.pop());
	}

	return selected;
}

function showFormes(formeObj, pokemonName, pokemon, baseFormeName) {
	var formes = pokemon.otherFormes.slice();
	formes.unshift(baseFormeName);

	var defaultForme = formes.indexOf(pokemonName);
	if (defaultForme < 0) defaultForme = 0;
	/* UTOPIA_MEGA_SAVED_FORM_V6 */
	var playerSide = formeObj.closest('#p1');
	if (playerSide.length) {
		var chosen = playerSide.find('.set-selector').val() || '';
		var separator = chosen.indexOf(' (');
		if (separator >= 0 && chosen.endsWith(')')) {
			var selectedSpecies = chosen.slice(0, separator);
			var selectedLabel = chosen.slice(separator + 2, -1);
			var selectedSet = setdex[selectedSpecies] && setdex[selectedSpecies][selectedLabel];
			if (selectedSet && selectedSet.forme && formes.indexOf(selectedSet.forme) >= 0) {
				defaultForme = formes.indexOf(selectedSet.forme);
			}
		}
	}

	var formeOptions = getSelectOptions(formes, false, defaultForme);
	formeObj.children("select").find("option").remove().end().append(formeOptions).change();
	formeObj.show();
}

function setSelectValueIfValid(select, value, fallback) {
	select.val(!value ? fallback : select.children("option[value='" + value + "']").length ? value : fallback);
}

$(".forme").change(function () {
	var altForme = pokedex[$(this).val()],
		container = $(this).closest(".info-group").siblings(),
		fullSetName = container.find(".select2-chosen").first().text(),
		pokemonName = fullSetName.substring(0, fullSetName.indexOf(" (")),
		setName = fullSetName.substring(fullSetName.indexOf("(") + 1, fullSetName.lastIndexOf(")"));

	$(this).parent().siblings().find(".type1").val(altForme.types[0]);
	$(this).parent().siblings().find(".type2").val(altForme.types[1] ? altForme.types[1] : "");
	for (var i = 0; i < LEGACY_STATS[9].length; i++) {
		var baseStat = container.find("." + LEGACY_STATS[9][i]).find(".base");
		baseStat.val(altForme.bs[LEGACY_STATS[9][i]]);
		baseStat.keyup();
	}
	var isRandoms = $("#randoms").prop("checked");
	var pokemonSets = isRandoms ? randdex[pokemonName] : setdex[pokemonName];
	var chosenSet = pokemonSets && pokemonSets[setName];
	var greninjaSet = $(this).val().indexOf("Greninja") !== -1;
	var isAltForme = $(this).val() !== pokemonName;
	if (chosenSet && isAltForme && abilities.indexOf(altForme.ab) !== -1 && !greninjaSet) {
		container.find(".ability").val(altForme.ab);
	} else if (greninjaSet) {
		$(this).parent().find(".ability");
	} else if (chosenSet) {
		if (!isRandoms) {
			container.find(".abilities").val(chosenSet.ability);
		} else {
			container.find(".ability").val(chosenSet.abilities[0]);
		}
	}
	container.find(".ability").keyup();

	if ($(this).val().indexOf("-Mega") !== -1 && $(this).val() !== "Rayquaza-Mega") {
		container.find(".item").val("").keyup();
	} else {
		container.find(".item").prop("disabled", false);
	}
});

function correctHiddenPower(pokemon) {
	// After Gen 7 bottlecaps means you can have a HP without perfect IVs
	if (gen >= 7) return pokemon;

	// Convert the legacy stats table to a useful one, and also figure out if all are maxed
	var ivs = {};
	var maxed = true;
	for (var i = 0; i <= LEGACY_STATS[9].length; i++) {
		var s = LEGACY_STATS[9][i];
		var iv = ivs[legacyStatToStat(s)] = (pokemon.ivs && pokemon.ivs[s]) || 31;
		if (iv !== 31) maxed = false;
	}

	var expected = calc.Stats.getHiddenPower(GENERATION, ivs);
	for (var i = 0; i < pokemon.moves.length; i++) {
		var m = pokemon.moves[i].match(HIDDEN_POWER_REGEX);
		if (!m) continue;
		// The Pokemon has Hidden Power and is not maxed but the types don't match we don't
		// want to attempt to reconcile the user's IVs so instead just correct the HP type
		if (!maxed && expected.type !== m[1]) {
			pokemon.moves[i] = "Hidden Power " + expected.type;
		} else {
			// Otherwise, use the default preset hidden power IVs that PS would use
			var hpIVs = calc.Stats.getHiddenPowerIVs(GENERATION, m[1]);
			if (!hpIVs) continue; // some impossible type was specified, ignore

			pokemon.ivs = pokemon.ivs || { hp: 31, at: 31, df: 31, sa: 31, sd: 31, sp: 31 };
			pokemon.dvs = pokemon.dvs || { hp: 15, at: 15, df: 15, sa: 15, sd: 15, sp: 15 };
			for (var stat in hpIVs) {
				pokemon.ivs[calc.Stats.shortForm(stat)] = hpIVs[stat];
				pokemon.dvs[calc.Stats.shortForm(stat)] = calc.Stats.IVToDV(hpIVs[stat]);
			}
			if (gen < 3) {
				pokemon.dvs.hp = calc.Stats.getHPDV({
					atk: pokemon.ivs.at,
					def: pokemon.ivs.df,
					spe: pokemon.ivs.sp,
					spc: pokemon.ivs.sa
				});
				pokemon.ivs.hp = calc.Stats.DVToIV(pokemon.dvs.hp);
			}
		}
	}
	return pokemon;
}

function createPokemon(pokeInfo) {
	if (typeof pokeInfo === "string") { // in this case, pokeInfo is the id of an individual setOptions value whose moveset's tier matches the selected tier(s)
		var name = pokeInfo.substring(0, pokeInfo.indexOf(" ("));
		var setName = pokeInfo.substring(pokeInfo.indexOf("(") + 1, pokeInfo.lastIndexOf(")"));
		var isRandoms = $("#randoms").prop("checked");
		var set = isRandoms ? randdex[name] : setdex[name][setName];

		var ivs = {};
		var evs = {};
		for (var i = 0; i < LEGACY_STATS[gen].length; i++) {
			var legacyStat = LEGACY_STATS[gen][i];
			var stat = legacyStatToStat(legacyStat);

			ivs[stat] = (gen >= 3 && set.ivs && typeof set.ivs[legacyStat] !== "undefined") ? set.ivs[legacyStat] : 31;
			evs[stat] = (set.evs && typeof set.evs[legacyStat] !== "undefined") ? set.evs[legacyStat] : 0;
		}
		var moveNames = set.moves;
		if (isRandoms && gen >= 9) {
			moveNames = [];
			for (var role in set.roles) {
				for (var q = 0; q < set.roles[role].moves.length; q++) {
					var moveName = set.roles[role].moves[q];
					if (moveNames.indexOf(moveName) === -1) moveNames.push(moveName);
				}
			}
		}

		var pokemonMoves = [];
		for (var i = 0; i < 4; i++) {
			var moveName = moveNames[i];
			var isCrit = $('.move-crit')[i].checked;
			pokemonMoves.push(new calc.Move(gen, moves[moveName] ? moveName : "(No Move)", { ability: ability, item: item, isCrit: isCrit, }));
		}

		if (isRandoms) {
			pokemonMoves = pokemonMoves.filter(function (move) {
				return move.category !== "Status";
			});
		}

		return new calc.Pokemon(gen, name, {
			level: set.level,
			ability: set.ability,
			abilityOn: true,
			item: set.item && typeof set.item !== "undefined" && (set.item === "Eviolite" || set.item.indexOf("ite") < 0) ? set.item : "",
			nature: set.nature,
			ivs: ivs,
			evs: evs,
			moves: pokemonMoves
		});
	} else {
		var setName = pokeInfo.find("input.set-selector").val();
		var name;
		if (setName.indexOf("(") === -1) {
			name = setName;
		} else {
			var pokemonName = setName.substring(0, setName.indexOf(" ("));
			var species = pokedex[pokemonName];
			name = (species.otherFormes || (species.baseSpecies && species.baseSpecies !== pokemonName)) ? pokeInfo.find(".forme").val() : pokemonName;
		}

		var baseStats = {};
		var ivs = {};
		var evs = {};
		var boosts = {};
		for (var i = 0; i < LEGACY_STATS[gen].length; i++) {
			var stat = legacyStatToStat(LEGACY_STATS[gen][i]);
			baseStats[stat === 'spc' ? 'spa' : stat] = ~~pokeInfo.find("." + LEGACY_STATS[gen][i] + " .base").val();
			ivs[stat] = gen > 2 ? ~~pokeInfo.find("." + LEGACY_STATS[gen][i] + " .ivs").val() : ~~pokeInfo.find("." + LEGACY_STATS[gen][i] + " .dvs").val() * 2 + 1;
			evs[stat] = ~~pokeInfo.find("." + LEGACY_STATS[gen][i] + " .evs").val();
			boosts[stat] = ~~pokeInfo.find("." + LEGACY_STATS[gen][i] + " .boost").val();
		}
		if (gen === 1) baseStats.spd = baseStats.spa;

		var ability = pokeInfo.find(".ability").val();
		var item = pokeInfo.find(".item").val();
		var isDynamaxed = pokeInfo.find(".max").prop("checked");
		var teraType = pokeInfo.find(".teraToggle").is(":checked") ? pokeInfo.find(".teraType").val() : undefined;
		pokeInfo.isDynamaxed = isDynamaxed;
		calcHP(pokeInfo);
		var curHP = ~~pokeInfo.find(".current-hp").val();
		// FIXME the Pokemon constructor expects non-dynamaxed HP
		if (isDynamaxed) curHP = Math.floor(curHP / 2);
		var types = [pokeInfo.find(".type1").val(), pokeInfo.find(".type2").val()];
		return new calc.Pokemon(gen, name, {
			level: ~~pokeInfo.find(".level").val(),
			ability: ability,
			abilityOn: pokeInfo.find(".abilityToggle").is(":checked"),
			item: item,
			gender: pokeInfo.find(".gender").is(":visible") ? getGender(pokeInfo.find(".gender").val()) : "N",
			nature: pokeInfo.find(".nature").val(),
			ivs: ivs,
			evs: evs,
			isDynamaxed: isDynamaxed,
			isSaltCure: pokeInfo.find(".saltcure").is(":checked"),
			alliesFainted: ability === 'Groove Guard'
                ? Math.max(0, (+pokeInfo.find('.utopia-groove-hits').val() || 1) - 1)
                : parseInt(pokeInfo.find(".alliesFainted").val()),
			teraType: teraType,
			boosts: boosts,
			curHP: curHP,
			status: CALC_STATUS[pokeInfo.find(".status").val()],
			toxicCounter: status === 'Badly Poisoned' ? ~~pokeInfo.find(".toxic-counter").val() : 0,
			moves: [
				getMoveDetails(pokeInfo.find(".move1"), name, ability, item, isDynamaxed),
				getMoveDetails(pokeInfo.find(".move2"), name, ability, item, isDynamaxed),
				getMoveDetails(pokeInfo.find(".move3"), name, ability, item, isDynamaxed),
				getMoveDetails(pokeInfo.find(".move4"), name, ability, item, isDynamaxed)
			],
			overrides: {
				baseStats: baseStats,
				types: types
			}
		});
	}
}

function getGender(gender) {
	if (!gender || gender === 'genderless' || gender === 'N') return 'N';
	if (gender.toLowerCase() === 'male' || gender === 'M') return 'M';
	return 'F';
}

function getMoveDetails(moveInfo, species, ability, item, useMax) {
	var moveName = moveInfo.find("select.move-selector").val();
	var isZMove = gen > 6 && moveInfo.find("input.move-z").prop("checked");
	var isCrit = moveInfo.find(".move-crit").prop("checked");
	var hits = +moveInfo.find(".move-hits").val();
	var timesUsed = +moveInfo.find(".stat-drops").val();
	var timesUsedWithMetronome = moveInfo.find(".metronome").is(':visible') ? +moveInfo.find(".metronome").val() : 1;
	var overrides = {
		basePower: +moveInfo.find(".move-bp").val(),
		type: moveInfo.find(".move-type").val()
	};
	if (gen >= 4) overrides.category = moveInfo.find(".move-cat").val();
	return new calc.Move(gen, moveName, {
		ability: ability, item: item, useZ: isZMove, species: species, isCrit: isCrit, hits: hits,
		timesUsed: timesUsed, timesUsedWithMetronome: timesUsedWithMetronome, overrides: overrides, useMax: useMax
	});
}

function createField() {
	var gameType = $("input:radio[name='format']:checked").val();
	var isBeadsOfRuin = $("#beads").prop("checked");
	var isTabletsOfRuin = $("#tablets").prop("checked");
	var isSwordOfRuin = $("#sword").prop("checked");
	var isVesselOfRuin = $("#vessel").prop("checked");
	var isMagicRoom = $("#magicroom").prop("checked");
	var isWonderRoom = $("#wonderroom").prop("checked");
	var isGravity = $("#gravity").prop("checked");
	var isSR = [$("#srL").prop("checked"), $("#srR").prop("checked")];
	var weather;
	var spikes;
	if (gen === 2) {
		spikes = [$("#gscSpikesL").prop("checked") ? 1 : 0, $("#gscSpikesR").prop("checked") ? 1 : 0];
		weather = $("input:radio[name='gscWeather']:checked").val();
	} else {
		weather = $("input:radio[name='weather']:checked").val();
		spikes = [~~$("input:radio[name='spikesL']:checked").val(), ~~$("input:radio[name='spikesR']:checked").val()];
	}
	var steelsurge = [$("#steelsurgeL").prop("checked"), $("#steelsurgeR").prop("checked")];
	var vinelash = [$("#vinelashL").prop("checked"), $("#vinelashR").prop("checked")];
	var wildfire = [$("#wildfireL").prop("checked"), $("#wildfireR").prop("checked")];
	var cannonade = [$("#cannonadeL").prop("checked"), $("#cannonadeR").prop("checked")];
	var volcalith = [$("#volcalithL").prop("checked"), $("#volcalithR").prop("checked")];
	var terrain = ($("input:checkbox[name='terrain']:checked").val()) ? $("input:checkbox[name='terrain']:checked").val() : "";
	var isReflect = [$("#reflectL").prop("checked"), $("#reflectR").prop("checked")];
	var isLightScreen = [$("#lightScreenL").prop("checked"), $("#lightScreenR").prop("checked")];
	var isProtected = [$("#protectL").prop("checked"), $("#protectR").prop("checked")];
	var isSeeded = [$("#leechSeedL").prop("checked"), $("#leechSeedR").prop("checked")];
	var isForesight = [$("#foresightL").prop("checked"), $("#foresightR").prop("checked")];
	var isHelpingHand = [$("#helpingHandL").prop("checked"), $("#helpingHandR").prop("checked")];
	var isTailwind = [$("#tailwindL").prop("checked"), $("#tailwindR").prop("checked")];
	var isFlowerGift = [$("#flowerGiftL").prop("checked"), $("#flowerGiftR").prop("checked")];
	var isFriendGuard = [$("#friendGuardL").prop("checked"), $("#friendGuardR").prop("checked")];
	var isAuroraVeil = [$("#auroraVeilL").prop("checked"), $("#auroraVeilR").prop("checked")];
	var isBattery = [$("#batteryL").prop("checked"), $("#batteryR").prop("checked")];
	var isPowerSpot = [$("#powerSpotL").prop("checked"), $("#powerSpotR").prop("checked")];
	// TODO: support switching in as well!
	var isSwitchingOut = [$("#switchingL").prop("checked"), $("#switchingR").prop("checked")];

	var createSide = function (i) {
		return new calc.Side({
			spikes: spikes[i], isSR: isSR[i], steelsurge: steelsurge[i],
			vinelash: vinelash[i], wildfire: wildfire[i], cannonade: cannonade[i], volcalith: volcalith[i],
			isReflect: isReflect[i], isLightScreen: isLightScreen[i],
			isProtected: isProtected[i], isSeeded: isSeeded[i], isForesight: isForesight[i],
			isTailwind: isTailwind[i], isHelpingHand: isHelpingHand[i], isFlowerGift: isFlowerGift[i], isFriendGuard: isFriendGuard[i],
			isAuroraVeil: isAuroraVeil[i], isBattery: isBattery[i], isPowerSpot: isPowerSpot[i], isSwitching: isSwitchingOut[i] ? 'out' : undefined
		});
	};
	return new calc.Field({
		gameType: gameType, weather: weather, terrain: terrain,
		isMagicRoom: isMagicRoom, isWonderRoom: isWonderRoom, isGravity: isGravity,
		isBeadsOfRuin: isBeadsOfRuin, isTabletsOfRuin: isTabletsOfRuin,
		isSwordOfRuin: isSwordOfRuin, isVesselOfRuin: isVesselOfRuin,
		attackerSide: createSide(0), defenderSide: createSide(1)
	});
}

function calcHP(poke) {
	var total = calcStat(poke, "hp");
	var $maxHP = poke.find(".max-hp");

	var prevMaxHP = Number($maxHP.attr('data-prev')) || total;
	var $currentHP = poke.find(".current-hp");
	var prevCurrentHP = $currentHP.attr('data-set') ? Math.min(Number($currentHP.val()), prevMaxHP) : prevMaxHP;
	// NOTE: poke.find(".percent-hp").val() is a rounded value!
	var prevPercentHP = 100 * prevCurrentHP / prevMaxHP;

	$maxHP.text(total);
	$maxHP.attr('data-prev', total);

	var newCurrentHP = calcCurrentHP(poke, total, prevPercentHP);
	calcPercentHP(poke, total, newCurrentHP);

	$currentHP.attr('data-set', true);
}

function calcStat(poke, StatID) {
	var stat = poke.find("." + StatID);
	var base = ~~stat.find(".base").val();
	var level = ~~poke.find(".level").val();
	var nature, ivs, evs;
	if (gen < 3) {
		ivs = ~~stat.find(".dvs").val() * 2;
		evs = 252;
	} else {
		ivs = ~~stat.find(".ivs").val();
		evs = ~~stat.find(".evs").val();
		if (StatID !== "hp") nature = poke.find(".nature").val();
	}
	// Shedinja still has 1 max HP during the effect even if its Dynamax Level is maxed (DaWoblefet)
	var total = calc.calcStat(gen, legacyStatToStat(StatID), base, ivs, evs, level, nature);
	if (gen > 7 && StatID === "hp" && poke.isDynamaxed && total !== 1) {
		total *= 2;
	}
	stat.find(".total").text(total);
	/* UTOPIA_NATURE_COLORS_V5_8 */
	var natures = {
		Lonely:['at','df'],Brave:['at','sp'],Adamant:['at','sa'],Naughty:['at','sd'],
		Bold:['df','at'],Relaxed:['df','sp'],Impish:['df','sa'],Lax:['df','sd'],
		Timid:['sp','at'],Hasty:['sp','df'],Jolly:['sp','sa'],Naive:['sp','sd'],
		Modest:['sa','at'],Mild:['sa','df'],Quiet:['sa','sp'],Rash:['sa','sd'],
		Calm:['sd','at'],Gentle:['sd','df'],Sassy:['sd','sp'],Careful:['sd','sa']
	};
	var nature = gen >= 3 && natures[poke.find('.nature').val()];
	stat.find('.total').css('color', !nature ? '' :
		nature[0] === StatID ? '#ed6262' : nature[1] === StatID ? '#579ff5' : '');
	return total;
}

var GENERATION = {
	'1': 1, 'rb': 1, 'rby': 1,
	'2': 2, 'gs': 2, 'gsc': 2,
	'3': 3, 'rs': 3, 'rse': 3, 'frlg': 3, 'adv': 3,
	'4': 4, 'dp': 4, 'dpp': 4, 'hgss': 4,
	'5': 5, 'bw': 5, 'bw2': 5, 'b2w2': 5,
	'6': 6, 'xy': 6, 'oras': 6,
	'7': 7, 'sm': 7, 'usm': 7, 'usum': 7,
	'8': 8, 'ss': 8,
	'9': 9, 'sv': 9
};
var SETDEX = [
	{},
	typeof SETDEX_RBY === 'undefined' ? {} : SETDEX_RBY,
	typeof SETDEX_GSC === 'undefined' ? {} : SETDEX_GSC,
	typeof SETDEX_ADV === 'undefined' ? {} : SETDEX_ADV,
	typeof SETDEX_DPP === 'undefined' ? {} : SETDEX_DPP,
	typeof SETDEX_BW === 'undefined' ? {} : SETDEX_BW,
	typeof SETDEX_XY === 'undefined' ? {} : SETDEX_XY,
	typeof SETDEX_SM === 'undefined' ? {} : SETDEX_SM,
	typeof SETDEX_SS === 'undefined' ? {} : SETDEX_SS,
	typeof SETDEX_SV === 'undefined' ? {} : SETDEX_SV,
];
var RANDDEX = [
	{},
	typeof GEN1RANDOMBATTLE === 'undefined' ? {} : GEN1RANDOMBATTLE,
	typeof GEN2RANDOMBATTLE === 'undefined' ? {} : GEN2RANDOMBATTLE,
	typeof GEN3RANDOMBATTLE === 'undefined' ? {} : GEN3RANDOMBATTLE,
	typeof GEN4RANDOMBATTLE === 'undefined' ? {} : GEN4RANDOMBATTLE,
	typeof GEN5RANDOMBATTLE === 'undefined' ? {} : GEN5RANDOMBATTLE,
	typeof GEN6RANDOMBATTLE === 'undefined' ? {} : GEN6RANDOMBATTLE,
	typeof GEN7RANDOMBATTLE === 'undefined' ? {} : GEN7RANDOMBATTLE,
	typeof GEN8RANDOMBATTLE === 'undefined' ? {} : GEN8RANDOMBATTLE,
	typeof GEN9RANDOMBATTLE === 'undefined' ? {} : GEN9RANDOMBATTLE,
];
var gen, genWasChanged, notation, pokedex, setdex, randdex, typeChart, moves, abilities, items, calcHP, calcStat, GENERATION;

TR_NAMES = get_trainer_names()

$(".gen").change(function () {
	/*eslint-disable */
	gen = ~~$(this).val() || 8;
	GENERATION = calc.Generations.get(gen);
	var params = new URLSearchParams(window.location.search);
	if (gen === 8) {
		params.delete('gen');
		params = '' + params;
		if (window.history && window.history.replaceState) {
			window.history.replaceState({}, document.title, window.location.pathname + (params.length ? '?' + params : ''));
		}
	} else {
		params.set('gen', gen);
		if (window.history && window.history.pushState) {
			params.sort();
			var path = window.location.pathname + '?' + params;
			window.history.pushState({}, document.title, path);
			gtag('config', 'UA-26211653-3', { 'page_path': path });
		}
	}
	genWasChanged = true;
	/* eslint-enable */
	// declaring these variables with var here makes z moves not work; TODO
	pokedex = calc.SPECIES[gen];
	setdex = SETDEX[gen];
	randdex = RANDDEX[gen];
	typeChart = calc.TYPE_CHART[gen];
	moves = calc.MOVES[gen];
	items = calc.ITEMS[gen];
	abilities = calc.ABILITIES[gen];
	clearField();
	$("#importedSets").prop("checked", false);
	loadDefaultLists();
	$(".gen-specific.g" + gen).show();
	$(".gen-specific").not(".g" + gen).hide();
	var typeOptions = getSelectOptions(Object.keys(typeChart));
	$("select.type1, select.move-type").find("option").remove().end().append(typeOptions);
	$("select.teraType").find("option").remove().end().append(getSelectOptions(Object.keys(typeChart).slice(1)));
	$("select.type2").find("option").remove().end().append("<option value=\"\">(none)</option>" + typeOptions);
	var moveOptions = getSelectOptions(Object.keys(moves), true);
	$("select.move-selector").find("option").remove().end().append(moveOptions);
	var abilityOptions = getSelectOptions(abilities, true);
	$("select.ability").find("option").remove().end().append("<option value=\"\">(other)</option>" + abilityOptions);
	var itemOptions = getSelectOptions(items, true);
	$("select.item").find("option").remove().end().append("<option value=\"\">(none)</option>" + itemOptions);

	$(".set-selector").val(getFirstValidSetOption().id);
	$(".set-selector").change();
});

function getFirstValidSetOption() {
	var sets = getSetOptions();
	// NB: The first set is never valid, so we start searching after it.
	for (var i = 1; i < sets.length; i++) {
		if (sets[i].id && sets[i].id.indexOf('(Blank Set)') === -1) return sets[i];
	}
	return undefined;
}

$(".notation").change(function () {
	notation = $(this).val();
});

function clearField() {
	$("#singles-format").prop("checked", true);
	$("#clear").prop("checked", true);
	$("#gscClear").prop("checked", true);
	$("#gravity").prop("checked", false);
	$("#srL").prop("checked", false);
	$("#srR").prop("checked", false);
	$("#spikesL0").prop("checked", true);
	$("#spikesR0").prop("checked", true);
	$("#gscSpikesL").prop("checked", false);
	$("#gscSpikesR").prop("checked", false);
	$("#steelsurgeL").prop("checked", false);
	$("#steelsurgeR").prop("checked", false);
	$("#vinelashL").prop("checked", false);
	$("#vinelashR").prop("checked", false);
	$("#wildfireL").prop("checked", false);
	$("#wildfireR").prop("checked", false);
	$("#cannonadeL").prop("checked", false);
	$("#cannonadeR").prop("checked", false);
	$("#volcalithL").prop("checked", false);
	$("#volcalithR").prop("checked", false);
	$("#reflectL").prop("checked", false);
	$("#reflectR").prop("checked", false);
	$("#lightScreenL").prop("checked", false);
	$("#lightScreenR").prop("checked", false);
	$("#protectL").prop("checked", false);
	$("#protectR").prop("checked", false);
	$("#leechSeedL").prop("checked", false);
	$("#leechSeedR").prop("checked", false);
	$("#foresightL").prop("checked", false);
	$("#foresightR").prop("checked", false);
	$("#helpingHandL").prop("checked", false);
	$("#helpingHandR").prop("checked", false);
	$("#tailwindL").prop("checked", false);
	$("#tailwindR").prop("checked", false);
	$("#friendGuardL").prop("checked", false);
	$("#friendGuardR").prop("checked", false);
	$("#auroraVeilL").prop("checked", false);
	$("#auroraVeilR").prop("checked", false);
	$("#batteryL").prop("checked", false);
	$("#batteryR").prop("checked", false);
	$("#switchingL").prop("checked", false);
	$("#switchingR").prop("checked", false);
	$("input:checkbox[name='terrain']").prop("checked", false);
}

function getSetOptions(sets) {
	var setsHolder = sets;
	if (setsHolder === undefined) {
		setsHolder = pokedex;
	}
	var pokeNames = Object.keys(setsHolder);
	pokeNames.sort();
	var setOptions = [];
	for (var i = 0; i < pokeNames.length; i++) {
		var pokeName = pokeNames[i];
		setOptions.push({
			pokemon: pokeName,
			text: pokeName
		});
		if ($("#randoms").prop("checked")) {
			if (pokeName in randdex) {
				setOptions.push({
					pokemon: pokeName,
					set: 'Randoms Set',
					text: pokeName + " (Randoms)",
					id: pokeName + " (Randoms)"
				});
			}
		} else {
			if (pokeName in setdex) {
				var setNames = Object.keys(setdex[pokeName]);
				for (var j = 0; j < setNames.length; j++) {
					var setName = setNames[j];
					setOptions.push({
						pokemon: pokeName,
						set: setName,
						text: pokeName + " (" + setName + ")",
						id: pokeName + " (" + setName + ")",
						isCustom: setdex[pokeName][setName].isCustomSet,
						nickname: setdex[pokeName][setName].nickname || ""
					});
				}
			}
			setOptions.push({
				pokemon: pokeName,
				set: "Blank Set",
				text: pokeName + " (Blank Set)",
				id: pokeName + " (Blank Set)"
			});
		}
	}
	return setOptions;
}

function getSelectOptions(arr, sort, defaultOption) {
	if (sort) {
		arr.sort();
	}
	var r = '';
	var shortenNames = arr === abilities || arr === items;
	var visibleNames = new Set();
	for (var i = 0; i < arr.length; i++) {
		var label = shortenNames ? arr[i].replace(/\s*\[[^\]]*\]$/, "") : utopiaMegaDisplayName(arr[i]);
		var duplicate = shortenNames && visibleNames.has(label);
		if (shortenNames) visibleNames.add(label);
		var hidden = duplicate ? ' hidden style="display:none"' : '';
		r += '<option value="' + arr[i] + '"' + hidden + ' ' + (defaultOption === i ? 'selected' : '') + '>' + label + '</option>';
	}
	return r;
}
var stickyMoves = (function () {
	var lastClicked = 'resultMoveL1';
	$(".result-move").click(function () {
		if (this.id === lastClicked) {
			$(this).toggleClass("locked-move");
		} else {
			$('.locked-move').removeClass('locked-move');
		}
		lastClicked = this.id;
	});

	return {
		clearStickyMove: function () {
			lastClicked = null;
			$('.locked-move').removeClass('locked-move');
		},
		setSelectedMove: function (slot) {
			lastClicked = slot;
		},
		getSelectedSide: function () {
			if (lastClicked) {
				if (lastClicked.indexOf('resultMoveL') !== -1) {
					return 'p1';
				} else if (lastClicked.indexOf('resultMoveR') !== -1) {
					return 'p2';
				}
			}
			return null;
		}
	};
})();

function isPokeInfoGrounded(pokeInfo) {
	var teraType = pokeInfo.find(".teraToggle").is(":checked") ? pokeInfo.find(".teraType").val() : undefined;
	return $("#gravity").prop("checked") || (
		teraType ? teraType !== "Flying" : pokeInfo.find(".type1").val() !== "Flying" &&
			teraType ? teraType !== "Flying" : pokeInfo.find(".type2").val() !== "Flying" &&
			pokeInfo.find(".ability").val() !== "Levitate" &&
		pokeInfo.find(".item").val() !== "Air Balloon"
	);
}

function getTerrainEffects() {
	var className = $(this).prop("className");
	className = className.substring(0, className.indexOf(" "));
	switch (className) {
		case "type1":
		case "type2":
		case "teraType":
		case "teraToggle":
		case "item":
			var id = $(this).closest(".poke-info").prop("id");
			var terrainValue = $("input:checkbox[name='terrain']:checked").val();
			if (terrainValue === "Electric") {
				$("#" + id).find("[value='Asleep']").prop("disabled", isPokeInfoGrounded($("#" + id)));
			} else if (terrainValue === "Misty") {
				$("#" + id).find(".status").prop("disabled", isPokeInfoGrounded($("#" + id)));
			}
			break;
		case "ability":
			// with autoset, ability change may cause terrain change, need to consider both sides
			var terrainValue = $("input:checkbox[name='terrain']:checked").val();
			if (terrainValue === "Electric") {
				$("#p1").find(".status").prop("disabled", false);
				$("#p2").find(".status").prop("disabled", false);
				$("#p1").find("[value='Asleep']").prop("disabled", isPokeInfoGrounded($("#p1")));
				$("#p2").find("[value='Asleep']").prop("disabled", isPokeInfoGrounded($("#p2")));
			} else if (terrainValue === "Misty") {
				$("#p1").find(".status").prop("disabled", isPokeInfoGrounded($("#p1")));
				$("#p2").find(".status").prop("disabled", isPokeInfoGrounded($("#p2")));
			} else {
				$("#p1").find("[value='Asleep']").prop("disabled", false);
				$("#p1").find(".status").prop("disabled", false);
				$("#p2").find("[value='Asleep']").prop("disabled", false);
				$("#p2").find(".status").prop("disabled", false);
			}
			break;
		default:
			$("input:checkbox[name='terrain']").not(this).prop("checked", false);
			if ($(this).prop("checked") && $(this).val() === "Electric") {
				// need to enable status because it may be disabled by Misty Terrain before.
				$("#p1").find(".status").prop("disabled", false);
				$("#p2").find(".status").prop("disabled", false);
				$("#p1").find("[value='Asleep']").prop("disabled", isPokeInfoGrounded($("#p1")));
				$("#p2").find("[value='Asleep']").prop("disabled", isPokeInfoGrounded($("#p2")));
			} else if ($(this).prop("checked") && $(this).val() === "Misty") {
				$("#p1").find(".status").prop("disabled", isPokeInfoGrounded($("#p1")));
				$("#p2").find(".status").prop("disabled", isPokeInfoGrounded($("#p2")));
			} else {
				$("#p1").find("[value='Asleep']").prop("disabled", false);
				$("#p1").find(".status").prop("disabled", false);
				$("#p2").find("[value='Asleep']").prop("disabled", false);
				$("#p2").find(".status").prop("disabled", false);
			}
			break;
	}
}

  /* UTOPIA_SLOT_DISPLAY_V2 */
function loadDefaultLists() {
  utopiaMakeTrainerOptions();
  $('.set-selector').each(function() {
    var input = $(this);
    var opposing = input.hasClass('opposing');
    input.select2({
      formatResult: function(option) {
        if (opposing && option.utopiaTrainer) return option.text;
        if ($('#randoms').prop('checked')) return option.pokemon;
        return option.set
          ? '&nbsp;&nbsp;&nbsp;' + utopiaCleanLabel(option.set)
          : '<b>' + option.text + '</b>';
      },
      formatSelection: function(option) {
        if (opposing) {
          var value = String((option && option.id) || input.val() || '');
          var trainer = utopiaTrainerForValue(value);
          if (trainer) return trainer.text;
          var open = value.indexOf(' (');
          var close = value.lastIndexOf(')');
          if (open >= 0 && close > open) {
            return utopiaCleanLabel(value.slice(open + 2, close));
          }
          return utopiaCleanLabel(String((option && option.text) || value));
        }
        return utopiaCleanLabel(String((option && (option.text || option.id)) || ''));
      },
      query: function(query) {
        var pageSize = 30;
        var page = query.page || 1;
        var term = String(query.term || '').toLowerCase().trim();
        var results = [];
        if (opposing && !$('#randoms').prop('checked')) {
          results = UTOPIA_TRAINER_OPTIONS.filter(function(t) {
            return t.text.toLowerCase().indexOf(term) >= 0;
          }).map(function(t) {
            return {
              id: t.id,
              text: t.text,
              utopiaTrainer: true
            };
          });
        } else {
          var options = getSetOptions();
          results = options.filter(function(o) {
            return (!$('#randoms').prop('checked') || o.id) &&
              (o.pokemon + ' ' + (o.set || ''))
                .toLowerCase().indexOf(term) >= 0;
          });


        }
        query.callback({
          results: results.slice((page - 1) * pageSize, page * pageSize),
          more: results.length > page * pageSize
        });
      },
      initSelection: function(element, callback) {
        var value = $(element).val();
        var trainer = opposing && utopiaTrainerForValue(value);
        if (trainer) {
          callback({
            id: value,
            text: trainer.text,
            utopiaTrainer: true
          });
        } else {
          var selected = null;
          var options = getSetOptions();

          for (var i = 0; i < options.length; i++) {
            if (options[i].id === value) {
              selected = options[i];
              break;
            }
          }

          callback(selected || getFirstValidSetOption());
        }
      }
    });
    if (opposing) {
      var container = input.select2('container');
      var playerContainer = $('.player').select2('container');
      if (container && container.length && playerContainer && playerContainer.length) {
        var playerWidth = playerContainer.outerWidth();
        if (playerWidth > 0) {
          container.css({
            width: playerWidth + 'px',
            maxWidth: playerWidth + 'px',
            boxSizing: 'border-box'
          });
        }
      }
    }
  });
  $('.opposing')
    .off('change.utopiaTrainer')
    .on('change.utopiaTrainer', utopiaTrainerChosen);
}

function allPokemon(selector) {
	var allSelector = "";
	for (var i = 0; i < $(".poke-info").length; i++) {
		if (i > 0) {
			allSelector += ", ";
		}
		allSelector += "#p" + (i + 1) + " " + selector;
	}
	return allSelector;
}

function loadCustomList(id) {
	$("#" + id + " .set-selector").select2({
		formatResult: function (set) {
			return (set.nickname ? set.pokemon + " (" + set.nickname + ")" : set.id);
		},
		query: function (query) {
			var pageSize = 30;
			var results = [];
			var options = getSetOptions();
			for (var i = 0; i < options.length; i++) {
				var option = options[i];
				var pokeName = option.pokemon.toUpperCase();
				var setName = option.set ? option.set.toUpperCase() : option.set;
				if (option.isCustom && option.set && (!query.term || query.term.toUpperCase().split(" ").every(function (term) {
					return pokeName.indexOf(term) === 0 || pokeName.indexOf("-" + term) >= 0 || pokeName.indexOf(" " + term) >= 0 || setName.indexOf(term) === 0 || setName.indexOf("-" + term) >= 0 || setName.indexOf(" " + term) >= 0;
				}))) {
					results.push(option);
				}
			}
			query.callback({
				results: results.slice((query.page - 1) * pageSize, query.page * pageSize),
				more: results.length >= query.page * pageSize
			});
		},
		initSelection: function (element, callback) {
			var data = "";
			callback(data);
		}
	});
}

function get_trainer_names() {
  var result = [];
  for (const [species, sets] of Object.entries(SETDEX_SS)) {
    for (const [name, set] of Object.entries(sets)) {
      result.push('[' + set.index + ']' + species + ' (' + name + ')');
    }
  }
  return result;
}
function addBoxed(poke, box) {
	if (document.getElementById(`${poke.name}${poke.nameProp}`)) {
		//nothing to do it already exist
		return
	}
	var newPoke = document.createElement("img");
	newPoke.id = `${poke.name}${poke.nameProp}`
	newPoke.className = "trainer-pok left-side";
	/* UTOPIA_SAVED_FORM_BOX_ICON_V7 */
	var boxedSet = SETDEX_SS[poke.name] &&
		SETDEX_SS[poke.name][poke.nameProp];
	var boxedForm = boxedSet && boxedSet.forme
		? boxedSet.forme
		: poke.name;
	newPoke.src = getSrcImgPokemon({
		name: UTOPIA_ICON_MAP[boxedForm] ? boxedForm : poke.name,
		shiny: boxedSet ? boxedSet.shiny === true : poke.shiny === true
	});
	newPoke.dataset.id = `${poke.name} (${poke.nameProp})`
	newPoke.addEventListener("dragstart", dragstart_handler);
	if (!box){
		$('#box-poke-list')[0].appendChild(newPoke)
	}else{
		box.append(newPoke)
	}
}

function getSrcImgPokemon(poke) {
  if (!poke) return "img/icons/000.png";
  var name = typeof poke === "string" ? poke : poke.name;
  var entry = UTOPIA_ICON_MAP[name];
  if (!entry) return "img/icons/000.png";
  var isShiny = typeof poke === "object" && (
    poke.shiny === true || poke.isShiny === true
  );
  if (isShiny && entry.shiny) {
    return "img/icons_shiny/" + entry.shiny;
  }
  return "img/icons/" + entry.normal;
}

function get_trainer_poks(trainer_name) {
  var species = trainer_name.substring(0, trainer_name.indexOf(' ('));
  var label = trainer_name.substring(trainer_name.indexOf(' (') + 2, trainer_name.lastIndexOf(')'));
  var selected = SETDEX_SS[species] && SETDEX_SS[species][label];
  if (!selected || !selected.trainerId) return [];
  var result = [];
  for (const [name, sets] of Object.entries(SETDEX_SS)) {
    for (const [setName, set] of Object.entries(sets)) {
      if (set.trainerId === selected.trainerId) {
        result.push('[' + set.index + ']' + name + ' (' + setName + ')');
      }
    }
  }
  return result;
}
/* UTOPIA_PLAYER_SPRITE_ORDER_V5_FINAL */
function utopiaSpriteFormMatchesSpecies(form, species) {
  var a = UTOPIA_ICON_MAP[form];
  var b = UTOPIA_ICON_MAP[species];

  return !!(
    a &&
    b &&
    a.speciesKey &&
    b.speciesKey &&
    a.speciesKey.split(':')[0] ===
    b.speciesKey.split(':')[0]
  );
}

function topPokemonIcon(fullname, node) {
  if (!node || !fullname) return;

  var full = String(fullname);
  var at = full.indexOf(' (');

  var species = at >= 0
    ? full.slice(0, at)
    : full;

  var label = at >= 0
    ? full.slice(at + 2, full.lastIndexOf(')'))
    : '';

  var set = SETDEX_SS[species] &&
    SETDEX_SS[species][label];

  var form = species;

  if (node.id === 'p1mon') {
    var control = $('#p1 .forme');

    var chosen = control.parent().is(':visible')
      ? control.val()
      : '';

    if (utopiaSpriteFormMatchesSpecies(chosen, species)) {
      form = chosen;
    } else if (
      set &&
      utopiaSpriteFormMatchesSpecies(set.forme, species)
    ) {
      form = set.forme;
    }
  } else if (
    set &&
    utopiaSpriteFormMatchesSpecies(set.forme, species)
  ) {
    form = set.forme;
  }

  if (!UTOPIA_ICON_MAP[form]) {
    form = species;
  }

  node.src = getSrcImgPokemon({
    name: form,
    shiny: !!(set && set.shiny === true)
  });
}

$(document).on('click', '.right-side', function () {
  var set = $(this).attr('data-id');
  var trainer = utopiaTrainerForValue(set);
  if (!trainer) return;
  utopiaSelectTrainerSet(set);
});

/* UTOPIA_BOX_EDIT_GATE_V5_8 */
var utopiaBoxSaveGate = {
  clicked: '',
  armed: false,
  dirty: false,

  /* UTOPIA_EXPLICIT_BLANK_TARGET_V5_8 */
  blankTarget: '',

  selected: function () {
    if (this.blankTarget) return this.blankTarget;
    return String($('#p1 .set-selector').val() || '');
  },

  validTarget: function () {
    if (!this.armed || !this.clicked) return false;

    var current = this.selected();

    if (current === this.clicked) return true;

    if (!current.endsWith(' (Blank Set)')) return false;

    var species = current.slice(0, -12);
    var boxIcons = document.querySelectorAll('.trainer-pok.left-side');

    for (var i = 0; i < boxIcons.length; i++) {
      var boxId = String(boxIcons[i].getAttribute('data-id') || '');

      if (boxId.indexOf(species + ' (') === 0) {
        return false;
      }
    }

    return true;
  },

  show: function () {
    $('#save-change').prop('hidden', !(this.dirty && this.validTarget()));
  },

  edited: function () {
    if (!this.armed || !this.validTarget()) return;

    this.dirty = true;
    this.show();
  },

  afterSave: function () {
    this.armed = false;
    this.clicked = '';
    this.dirty = false;
    this.blankTarget = '';
    this.show();
  }
};

$(document).on('click.utopiaBoxGate', '.trainer-pok.left-side', function () {
  utopiaBoxSaveGate.clicked = String($(this).attr('data-id') || '');
  utopiaBoxSaveGate.armed = !!utopiaBoxSaveGate.clicked;
  utopiaBoxSaveGate.dirty = false;
  utopiaBoxSaveGate.blankTarget = '';
  utopiaBoxSaveGate.show();
});

/* UTOPIA_SELECT2_SELECTION_SYNC_V5 */
var utopiaSelectionSyncing = false;

function utopiaSyncPlayerSelection(id) {
    if (utopiaSelectionSyncing || !id) return;

    var input = $('#p1 .set-selector');

    if (!input.length) return;

    var current = String(input.val() || '');

    if (current === id) return;

    utopiaSelectionSyncing = true;

    try {
        input.val(id);
        input.trigger('change');
    } finally {
        utopiaSelectionSyncing = false;
    }
}

function utopiaSetBoxSelection(id) {
    if (!id) return;

    var input = $('#p1 .set-selector');
    var options = getSetOptions();
    var choice = null;

    for (var i = 0; i < options.length; i++) {
        if (options[i].id === id) {
            choice = options[i];
            break;
        }
    }

    if (!choice) {
        console.error('Box Auswahl: Set nicht gefunden:', id);
        return;
    }

    utopiaSelectionSyncing = true;

    try {
        input.select2('data', choice);
        input.val(id);
    } finally {
        utopiaSelectionSyncing = false;
    }

    input.trigger('change');
}

/* Merkt sich die Auswahl und synchronisiert sie nach Select2. */
$(document).on(
    'select2-selecting.utopiaBlankTarget',
    '#p1 .set-selector',
    function (event) {
        var option = event.choice || event.object || {};
        var id = String(option.id || '');

        if (!id) return;

        utopiaBoxSaveGate.blankTarget =
            id.endsWith(' (Blank Set)') ? id : '';

        utopiaBoxSaveGate.dirty = false;
        utopiaBoxSaveGate.show();

        setTimeout(function () {
            var input = $('#p1 .set-selector');
            var data = input.select2('data');
            var actualId = String(data && data.id || '');

            if (actualId === id) {
                utopiaSyncPlayerSelection(id);
            }
        }, 0);
    }
);

$(document).on('change.utopiaBoxGate', '#p1 .set-selector', function () {
  if (!utopiaBoxSaveGate.validTarget()) {
    utopiaBoxSaveGate.dirty = false;
  }

  utopiaBoxSaveGate.show();
});

$(document).on(
  'select2-selecting.utopiaBoxGate',
  '#p1 .move-selector, #p1 .ability, #p1 .item',
  function () {
    utopiaBoxSaveGate.edited();
  }
);

$(document).on(
  'input.utopiaBoxGate change.utopiaBoxGate',
  '#p1 input:not(.set-selector), #p1 select:not(.set-selector), #p1 textarea',
  function (event) {
    if (event.originalEvent) {
      utopiaBoxSaveGate.edited();
    }
  }
);

$(function () {
  utopiaBoxSaveGate.show();
});

$(document).on('click', '.left-side', function () {
    var set = $(this).attr('data-id');

    if (!set) return;

    $('#save-change').attr('hidden', true);
    utopiaSetBoxSelection(set);
});

function truckMessage(){
	var truckMsgId= Number(localStorage.getItem("truckMsg"));
	if (truckMsgId == undefined){
		truckMsgId = -1;
	} 
	truckMsgId+=1;
	if(truckMsgId >= TRUCK_MESSAGES.length){
		truckMsgId = 2;
	}
	localStorage.setItem("truckMsg", truckMsgId);
	//yaayy dynamic strings
	return typeof TRUCK_MESSAGES[truckMsgId] === 'string' ? TRUCK_MESSAGES[truckMsgId] : TRUCK_MESSAGES[truckMsgId]() ;
	
}

//select first mon of the box when loading
function selectFirstMon() {
    var pMons = document.getElementsByClassName("trainer-pok left-side")[0];

    if (!pMons) return;

    var set = pMons.getAttribute('data-id');

    utopiaSetBoxSelection(set);
}

function selectTrainer(value, direction) {
  if (!UTOPIA_TRAINER_OPTIONS.length) utopiaMakeTrainerOptions();
  var index = Number(value);
  var trainer = null;
  for (var i = 0; i < UTOPIA_TRAINER_OPTIONS.length; i++) {
    var option = UTOPIA_TRAINER_OPTIONS[i];
    if (option.index === index) {
      trainer = option;
      break;
    }
  }
  if (!trainer && direction) {
    for (var j = 0; j < UTOPIA_TRAINER_OPTIONS.length; j++) {
      var candidate = UTOPIA_TRAINER_OPTIONS[j];
      if (direction > 0 && candidate.index >= index) {
        trainer = candidate;
        break;
      }
      if (direction < 0 && candidate.index <= index) {
        trainer = candidate;
      }
    }
  }
  if (!trainer) return false;
  utopiaSelectTrainerSet(trainer.id);
  return true;
}

function nextTrainer() {
  selectTrainer(nextTrainerId, 1);
}

function previousTrainer() {
  selectTrainer(previousTrainerId, -1);
}

function resetTrainer() {
	/* UTOPIA_TRUCK_TEAM_V5_8 */
	if (confirm(truckMessage())){
		localStorage.removeItem("customsets");
		$(allPokemon("#importedSetsOptions")).hide();
		loadDefaultLists();
		for (let zone of document.getElementsByClassName("dropzone")){
			zone.innerHTML="";
		}
		selectTrainer(1);
	}
	
}

function HideShowCCSettings(){
	$('#show-cc')[0].toggleAttribute("hidden");
	$('#hide-cc')[0].toggleAttribute("hidden");
	$('#refr-cc')[0].toggleAttribute("hidden");
	$('#info-cc')[0].toggleAttribute("hidden");
	$('#cc-sets')[0].toggleAttribute("hidden");
}

function colorCodeUpdate(){
	var speCheck = document.getElementById("cc-spe-border").checked;
	var ohkoCheck = document.getElementById("cc-ohko-color").checked;
	if (!speCheck && !ohkoCheck){
		return
	}
	var pMons = document.getElementsByClassName("trainer-pok left-side");
	// i calc here to alleviate some calculation
	var p2info = $("#p2");
	var p2 = createPokemon(p2info);
	for (let i = 0; i < pMons.length; i++) {
		let set = pMons[i].getAttribute("data-id");
		let idColor = calculationsColors(set, p2);
		if (speCheck && ohkoCheck){
			pMons[i].className = `trainer-pok left-side mon-speed-${idColor.speed} mon-dmg-${idColor.code}`;
		}
		else if (speCheck){
			pMons[i].className = `trainer-pok left-side mon-speed-${idColor.speed}`;
		}
		else if (ohkoCheck){
			pMons[i].className = `trainer-pok left-side mon-dmg-${idColor.code}`;
		}
		
		
	}
}
function showColorCodes(){
	window.AUTO_REFRESH = document.getElementById("cc-auto-refr").checked;
	colorCodeUpdate();
	HideShowCCSettings();
}

function refreshColorCode(){
	window.AUTO_REFRESH = document.getElementById("cc-auto-refr").checked;
	colorCodeUpdate();
}

function hideColorCodes(){
	var pMons = document.getElementsByClassName("trainer-pok left-side");
	for (let i = 0; i < pMons.length; i++) {
		pMons[i].className = "trainer-pok left-side";
	}
	window.AUTO_REFRESH = false;
	HideShowCCSettings();
}

function toggleInfoColorCode(){
	document.getElementById("info-cc-field").toggleAttribute("hidden");
}

function TrashPokemon() {
	var maybeMultiple = document.getElementById("trash-box").getElementsByClassName("trainer-pok");
	if (maybeMultiple.length == 0){
		return; //nothing to delete
	}
	var numberPKM = maybeMultiple.length > 1 ? `${maybeMultiple.length} Pokemon(s)` : "this Pokemon"; 
	var yes = confirm(`do you really want to remove ${numberPKM}?`);
	if (!yes) {
		return;
	}
	var customSets = JSON.parse(localStorage.customsets);
	var length= maybeMultiple.length;
	for( let i = 0; i<length; i++){
		var pokeTrashed = maybeMultiple[i];
		var name = pokeTrashed.getAttribute("data-id").split(" (")[0];
		delete customSets[name];
	}
	document.getElementById("trash-box").innerHTML="";
	localStorage.setItem("customsets", JSON.stringify(customSets));
	$('#box-poke-list')[0].click();
	//switch to the next pokemon automatically
	
}
function RemoveAllPokemon() {
	document.getEle
}


// Check whether control button is pressed
$(document).keydown(function(event) {
    if (event.which == "17")
        cntrlIsPressed = true;
    else if (event.which == 65 && cntrlIsPressed) {
        // Cntrl+  A
        selectAllRows();
    }
});
$(document).keyup(function() {
    cntrlIsPressed = false;
});
var cntrlIsPressed = false;
/* dragging for pokemons in boxes*/
function allowDrop(ev) {
	ev.preventDefault();
}

var pokeDragged = null;
function dragstart_handler(ev) {
	pokeDragged = ev.target;
}

function drop(ev) {
	ev.preventDefault();
	if (!pokeDragged || !pokeDragged.parentNode || ev.target === pokeDragged) return;
	if (ev.target.classList.contains("dropzone")) {
		pokeDragged.parentNode.removeChild(pokeDragged);
		if(ev.target.tagName=="LEGEND"){
			ev.target.parentNode.children[1].appendChild(pokeDragged);
		}else{
			ev.target.appendChild(pokeDragged);
		}
			
	}
	// if it's a pokemon
	else if(ev.target.classList.contains("left-side") || ev.target.classList.contains("right-side")) {
		if (!cntrlIsPressed){
			let prev1 = pokeDragged.previousElementSibling
			if (!prev1){
				ev.target.after(pokeDragged)
			} else {
				ev.target.before(pokeDragged)
				prev1.after(ev.target)
			}
			//swaps
		} else {
			//appends before
			ev.target.before(pokeDragged)
		}
	}
	ev.target.classList.remove('over');
}

function handleDragEnter(ev) {
	ev.target.classList.add('over');
	ev.target.removeAttribute("data-placeholder");
}

function handleDragLeave(ev) {
	ev.target.classList.remove('over');
}
/* dragging for the item box, note box*/
// target elements with the "box-frame-header" class
interact('.box-frame-header').draggable({
    inertia: true,
    modifiers: [
      interact.modifiers.restrictRect({
        restriction: document.body,
        endOnly: true
      })
    ],
    autoScroll: true,

    listeners: {
      start: function () { document.body.classList.add("utopia-window-dragging"); },
      move: dragMoveListener,
      end: function () { document.body.classList.remove("utopia-window-dragging"); }
    }
  })

function dragMoveListener (event) {
	var target = event.target;
	var parent = target.parentNode;
	// special case for the screen box frame
	if (target.classList.contains("screen-box-frame")) {
		parent = target;
	}
    if (!target.hasAttribute('data-utopia-drag-ready')) {
      var bounds = parent.getBoundingClientRect();
      parent.style.position = 'fixed';
      parent.style.left = bounds.left + 'px';
      parent.style.top = bounds.top + 'px';
      target.setAttribute('data-x', bounds.left);
      target.setAttribute('data-y', bounds.top);
      target.setAttribute('data-utopia-drag-ready', '1');
    }
    var x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
    var y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy ;
	parent.style.left=x+"px";
	parent.style.top=y+"px";
    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
}

window.dragMoveListener = dragMoveListener

function SpeedBorderSetsChange(ev){
	var monImgs = document.getElementsByClassName("left-side");
	if (ev.target.checked){
		for (let monImg of monImgs){
			monImg.classList.remove("mon-speed-none")
		}
	}else{
		for (let monImg of monImgs){
			monImg.classList.add("mon-speed-none")
		}
	}
}
function widthSpeedBorder(ev){
	document.documentElement.style.setProperty("--spe-bor-width", `${ev.target.value}px`)
}

function ColorCodeSetsChange(ev){
	var monImgs = document.getElementsByClassName("left-side");
	if (ev.target.checked){
		for (let monImg of monImgs){
			monImg.classList.remove("mon-dmg-none")
		}
	}else{
		for (let monImg of monImgs){
			monImg.classList.add("mon-dmg-none")
		}
	}
}
function setupSideCollapsers(){
	var applyF = (btns) => {
		for (var i = 0; i < btns.length; i++) {
			let btn = btns[i];
			btn.cum = btn.offsetHeight;
			btn.sisterEl = document.getElementsByClassName(btn.getAttribute("data-set"))[0];
			btn.prevEl = btns[i-1] || null;
			if (btn.prevEl){
				btn.cum += btn.prevEl.cum
			}else{
				btn.cum = 0;
			}
			btn.nextEl = btns[i+1] || null;
			btn.onclick = sideCollapsersCorrection
		}
	}
	var leftBtns = document.getElementsByClassName("l-side-button");
	var rigtBtns = document.getElementsByClassName("r-side-button");
	applyF(leftBtns);
	applyF(rigtBtns);
	/*
		readjust the left buttons
		Because i couldn't find a proper way to do it with css
	*/
	for(let btn of leftBtns){
		btn.style.left = "-" + btn.offsetWidth + "px";
	}
	leftBtns[0].onclick();
	rigtBtns[0].onclick();
}
function sideCollapsersCorrection(ev){
	if (ev){
		var arrow = ev.target.children[0] || ev.target.parentNode.children[0];
		collapseArrow(arrow);
	}
	var node = this;
	if (node.tagName != "BUTTON"){
		node = this.target.parentNode;
	}
	var prev = node.prevEl;
	var offset = node.sisterEl.offsetTop;
	var relativeHeight = node.parentNode.offsetTop;
	if(prev){
		//since the position is absolute, this will prevent from eating fellows.
		var prevLowPos = prev.offsetTop + prev.offsetHeight; - relativeHeight ;
		if(offset==0){// collapsed
			offset = prevLowPos;
		}else{// standing
			offset = offset - relativeHeight;
			if (offset < prevLowPos){
				offset = prevLowPos;
			}
		}
	}else{
		if(offset==0){// collapsed
			offset = node.offsetTop;
		}else{// standing
			offset = offset - relativeHeight;
		}
	}
	node.style.top = offset + "px"
	//propagate to next buttons
	if(node.nextEl){
		node.nextEl.onclick()
	}
}
function collapseArrow(arrow){
	var arrBtn = arrow.parentNode;
	var target = arrBtn.getAttribute("data-set");
	for (let div of document.getElementsByClassName(target)){
		div.toggleAttribute("hidden");
	}
	if (arrBtn.classList.contains("l-side-button")){
		if (arrow.classList.contains("arrowdown")){
			arrow.classList.remove("arrowdown");
			arrow.classList.add("arrowright");
		}else{
			arrow.classList.remove("arrowright");
			arrow.classList.add("arrowdown");
		}
	}
	else if (arrBtn.classList.contains("r-side-button")){
		if (arrow.classList.contains("arrowdown")){
			arrow.classList.remove("arrowdown");
			arrow.classList.add("arrowleft");
		}else{
			arrow.classList.remove("arrowleft");
			arrow.classList.add("arrowdown");
		}
	}
}

window.isInDoubles = false;
function switchIconSingle(){
	document.getElementById("monDouble").removeAttribute("hidden");
	window.isInDoubles = true;
	if (+localStorage.getItem("doubleLegacy")){
		return;
	}
	document.getElementById("trainer-pok-list-opposing2").removeAttribute("hidden");
	for (toShow of document.getElementsByClassName("for-doubles")){
		toShow.removeAttribute("hidden");
	}
	
}

function switchIconDouble(){
	document.getElementById("monDouble").setAttribute("hidden" ,true);
	window.isInDoubles = false;
	if (+localStorage.getItem("doubleLegacy")){
		return;
	}
	var topOppositeBox = document.getElementById("trainer-pok-list-opposing");
	var bottomOppositeBox = document.getElementById("trainer-pok-list-opposing2");
	bottomOppositeBox.setAttribute("hidden" ,true);
	for (toHide of document.getElementsByClassName("for-doubles")){
		toHide.setAttribute("hidden" ,true);
	}
	// set all pokemons that were left in the bottom, replace them onto the top
	for ( let potentialLeft of bottomOppositeBox.children) {
		topOppositeBox.append(potentialLeft);
	}
}

function openCloseItemBox(){
	document.getElementById("item-box-frame").toggleAttribute("hidden");
}

function openCloseNoteBox(){
	document.getElementById("note-box-frame").toggleAttribute("hidden");
}

function selectItem(ev){
	var newItem = ev.target.getAttribute("data-id");
	document.getElementById("itemL1").value=newItem;
}

function onFirstTime(){
	document.getElementById("team-poke-list").setAttribute("data-placeholder", "You can drag & drop your pokemons here");
	document.getElementById("box-poke-list2").setAttribute("data-placeholder","You can drag & drop your pokemons here");
	document.getElementById("trash-box").setAttribute("data-placeholder", "drop here and click remove to remove");
}

function sideArrowToggle(){
	var btn = document.getElementById("side-arrow-toggle");
	var onShow= btn.getAttribute("data-id")
	if (onShow=="true"){
		btn.setAttribute("data-id", "false");
		btn.innerText="Hide Side Arrows";
		localStorage.setItem("hsidearrow", "1");
	}else{
		btn.setAttribute("data-id", "true");
		btn.innerText="Show Side Arrows";
		localStorage.setItem("hsidearrow", "0");
	}
	for(pannel of document.getElementsByClassName("side-pannel")){
		pannel.toggleAttribute("hidden")
	}
	setupSideCollapsers()
}

function toggleDoubleLegacyMode(){
	if (+localStorage.getItem("doubleLegacy")){
		localStorage.setItem("doubleLegacy", 0)
		document.getElementById("double-legacy-mode").innerText="Doubles Modern"
		if(window.isInDoubles){
			document.getElementById("trainer-pok-list-opposing2").removeAttribute("hidden");
			for (toShow of document.getElementsByClassName("for-doubles")){
				toShow.removeAttribute("hidden");
			}
		}
	}else{
		localStorage.setItem("doubleLegacy", 1)
		document.getElementById("double-legacy-mode").innerText="Doubles Legacy"
		if (window.isInDoubles){
			document.getElementById("trainer-pok-list-opposing2").setAttribute("hidden" ,true);
			for (toHide of document.getElementsByClassName("for-doubles")){
				toHide.setAttribute("hidden" ,true);
			}
		}
	}
}

var screenDivCount = 0;
function closeScreenCalc(id){
	var screenDiv = document.getElementById("calc-screen-id"+id);
	screenDiv.parentNode.removeChild(screenDiv);
	screenDivCount--
}
function onClickScreenCalc(){
	var screenDiv = document.createElement("div");
	// box frame header here so it's less code in the end;
	screenDiv.className = "box-frame screen-box-frame box-frame-header";
	screenDiv.id = "calc-screen-id"+screenDivCount;
	screenDiv.dataset.x="500";
	screenDiv.dataset.y="250";
	screenDiv.innerHTML=` <div class="screen-box-frame-header"><legend>Calculation ${screenDivCount+1}</legend>
	<div class="close-frame" id="close-calc-box-${screenDivCount}" onclick="closeScreenCalc(${screenDivCount})"><div class="mdiv"><div class="md"></div></div></div></div>`;
	var moveResults = document.getElementsByClassName("move-result-group");
	var mainResults = document.getElementsByClassName("main-result-group");
	for (let i = 0; i<moveResults.length; i++) {
		if(moveResults[i].parentNode.classList.contains("box-frame")){
			continue
		}
		if(mainResults[i].parentNode.classList.contains("box-frame")){
			continue
		}
		screenDiv.appendChild(moveResults[i].cloneNode(true));
		screenDiv.appendChild(mainResults[i].cloneNode(true));
	}
	document.body.append(screenDiv);
	for ( let label of document.querySelectorAll('.box-frame label')){
		label.removeAttribute("for");
	}
	for ( let span of document.querySelectorAll('.box-frame span')){
		span.removeAttribute("id");
	}
	for ( let input of document.querySelectorAll('.box-frame input')){
		input.removeAttribute("id");
	}
	for (let group of document.querySelectorAll('.box-frame .move-result-group')){
		group.classList.remove("move-result-group");
	}
	for (let group of document.querySelectorAll('.box-frame .main-result-group')){
		group.classList.remove("main-result-group");
	}
	screenDivCount++
}

window.AUTO_REFRESH = false;
$(document).ready(function () {
	var params = new URLSearchParams(window.location.search);
	var g = GENERATION[params.get('gen')] || 8;
	$("#gen" + g).prop("checked", true);
	$("#gen" + g).change();
	$("#percentage").prop("checked", true);
	$("#percentage").change();
	$("#singles-format").prop("checked", true);
	$("#singles-format").change();
	loadDefaultLists();
	$(".move-selector").select2({
		dropdownAutoWidth: true,
        // UTOPIA_HIDDEN_POWER_DISPLAY_V6_2: Select2 3.x – nur die sichtbare Beschriftung ändern.
        // Die option.value bleibt typisiert, damit Typ und Damage korrekt bleiben.
        formatSelection: function (entry, container, escapeMarkup) {
            var name = entry && entry.text ? entry.text : '';
            name = /^Hidden Power (?:Fighting|Flying|Poison|Ground|Rock|Bug|Ghost|Steel|Fire|Water|Grass|Electric|Psychic|Ice|Dragon|Dark)$/.test(name)
                ? 'Hidden Power' : name;
            return escapeMarkup(name);
        },
        formatResult: function (entry, container, query, escapeMarkup) {
            var name = entry && entry.text ? entry.text : '';
            name = /^Hidden Power (?:Fighting|Flying|Poison|Ground|Rock|Bug|Ghost|Steel|Fire|Water|Grass|Electric|Psychic|Ice|Dragon|Dark)$/.test(name)
                ? 'Hidden Power' : name;
            return escapeMarkup(name);
        },
		matcher: function (term, text) {
			// 2nd condition is for Hidden Power
			return text.toUpperCase().indexOf(term.toUpperCase()) === 0 || text.toUpperCase().indexOf(" " + term.toUpperCase()) >= 0;
		}
	});
	$(".set-selector").val(getFirstValidSetOption().id);
	$(".set-selector").change();
	$(".terrain-trigger").bind("change keyup", getTerrainEffects);
	$("#previous-trainer").click(previousTrainer);
	$("#next-trainer").click(nextTrainer);
	$("#reset-trainer").click(resetTrainer);
	$('#show-cc').click(showColorCodes);
	$('#hide-cc').click(hideColorCodes);
	$('#refr-cc').click(refreshColorCode);
	$('#info-cc').click(toggleInfoColorCode);
	$('#trash-pok').click(TrashPokemon);
	$('#cc-spe-border').change(SpeedBorderSetsChange);
	$('#cc-ohko-color').change(ColorCodeSetsChange);
	$('#cc-auto-refr').change(refreshColorCode);
	$('#cc-spe-border')[0].checked=true;
	$('#cc-ohko-color')[0].checked=true;
	$('#cc-spe-width').change(widthSpeedBorder);
	$('#singles-format').click(switchIconDouble);
	$('#doubles-format').click(switchIconSingle);
	$('#side-arrow-toggle').click(sideArrowToggle);
	$('#close-item-box, #ball-item').click(openCloseItemBox);
	$('#close-note-box, #open-note').click(openCloseNoteBox);
	$('.ic').click(selectItem);
	$('#save-change').click(saveTrainerPokemon);
	$('#double-legacy-mode').click(toggleDoubleLegacyMode);
	$('#screen-calc').click(onClickScreenCalc)
	for (let dropzone of document.getElementsByClassName("dropzone")){
		dropzone.ondragenter=handleDragEnter;
		dropzone.ondragleave=handleDragLeave;
		dropzone.ondrop=drop;
		dropzone.ondragover=allowDrop;
	}
	//select last trainer
	var last = parseInt(localStorage.getItem("lasttimetrainer"),10);
	if (isNaN(last)) {
		selectTrainer(1);
	}else{
		selectTrainer(last);
	}
	//to indicate some features
	var isNotNew = JSON.parse(localStorage.getItem("isNotNew"))
	if (!isNotNew){//first time loading the page
		onFirstTime()
		localStorage.setItem("isNotNew", true)
	}
	if (+localStorage.getItem("hsidearrow")){
		setupSideCollapsers()
		sideArrowToggle()
	}
	if (+localStorage.getItem("doubleLegacy")){
		toggleDoubleLegacyMode()
	}

	//some CSS variable;
	document.documentElement.style.setProperty("--spe-bor-width", "3px");
});

/* Click-to-copy function */
$("#mainResult").click(function () {
	navigator.clipboard.writeText($("#mainResult").text()).then(function () {
		document.getElementById('tooltipText').style.visibility = 'visible';
		setTimeout(function () {
			document.getElementById('tooltipText').style.visibility = 'hidden';
		}, 2000);
	});
});

/* UTOPIA_DOUBLES_SELECTION_FIX_V2 */
$(function() {
  function updateMode(value) {
    if (typeof utopiaTrainerForValue !== "function") return;
    var trainer = utopiaTrainerForValue(value);
    if (!trainer) return;
    utopiaSetBattleMode(trainer.doubles === true);
  }
  $(document).on("select2-selecting.utopiaMode", ".opposing", function(event) {
    var choice = event.choice || event.object || event.val;
    var value = typeof choice === "string" ? choice : choice && choice.id;
    if (value) updateMode(value);
  });
  $(document).on("change.utopiaMode", ".opposing", function() {
    updateMode($(this).val());
  });
  $(document).on("click.utopiaMode", "#previous-trainer, #next-trainer", function() {
    updateMode($(".opposing").val());
  });
  updateMode($(".opposing").val());
});









/* UTOPIA_GROOVE_LAYOUT_V7 */
$(function() {
  function utopiaPositionControls() {
    $(".poke-info").each(function() {
      var panel = $(this);
      var group = panel.find(".info-selectors").first();
      var ability = group.find("select.ability").first();
      var item = group.find("select.item").first();

      if (!group.length || !ability.length || !item.length) return;

      var rows = group.children("div:visible");
      var natureRow = group.find("select.nature").first().parent();
      var statusRow = group.find("select.status").first().parent();
      var groove = panel.find("select.utopia-groove-hits").first();
      var bag = panel.find("#ball-item").first();

      if (!groove.length) {
        groove = $('<select class="utopia-groove-hits calc-trigger" aria-label="Groove Guard Trefferfolge"></select>');
        for (var n = 1; n <= 6; n++) {
          groove.append(
            $("<option></option>").val(n).text("x" + n)
          );
        }
        ability.after(groove);
      }

      group.css("position", "relative");

      if (groove.length) {
        if (groove.parent()[0] !== ability.parent()[0]) {
          groove.detach();
          ability.after(groove);
        }

        var abilityRow = ability.parent();

        abilityRow.css("position", "relative");

        groove.find("option").each(function(index) {
          $(this).text("x" + (index + 1));
        });

        groove.css({
          position: "absolute",
          left: (ability[0].offsetLeft + ability[0].offsetWidth + 5) + "px",
          top: ability[0].offsetTop + "px",
          width: "48px",
          height: ability.outerHeight() + "px",
          minWidth: "48px",
          maxWidth: "48px",
          margin: "0",
          padding: "0",
          boxSizing: "border-box"
        });

        groove.toggle(ability.val() === "Groove Guard");
      }

      if (bag.length && natureRow.length && statusRow.length) {
        if (bag.parent()[0] !== group[0]) {
          bag.detach();
          group.append(bag);
        }

        var groupRect = group[0].getBoundingClientRect();
        var natureRect = natureRow[0].getBoundingClientRect();
        var statusRect = statusRow[0].getBoundingClientRect();

        var middleY = (
          natureRect.top + statusRect.bottom
        ) / 2 - groupRect.top;

        var bagWidth = bag.outerWidth();
        var bagHeight = bag.outerHeight();

        var left = group.innerWidth() - bagWidth - 50;
        var top = middleY - bagHeight / 2;

        bag.css({
          position: "absolute",
          left: Math.round(left) + "px",
          top: Math.round(top) + "px",
          margin: "0",
          display: "block",
          zIndex: "2"
        });
      }
    });
  }

  function utopiaPositionItemWindow() {
    var bag = $("#p1 #ball-item");
    var frame = $("#item-box-frame");

    if (!bag.length || !frame.length || frame.prop("hidden")) return;

    var rect = bag[0].getBoundingClientRect();
    var width = frame.outerWidth();
    var height = frame.outerHeight();

    if (!width || !height) return;

    var left = rect.left + rect.width / 2 - width / 2;
    var top = rect.top + rect.height / 2 - height / 2;

    left = Math.max(
      10,
      Math.min(left, window.innerWidth - width - 10)
    );

    top = Math.max(
      10,
      Math.min(top, window.innerHeight - height - 10)
    );

    var positionedLeft = Math.max(10, Math.min(window.innerWidth - width - 10, left + 180));
    frame.css({
      position: "fixed",
      left: Math.round(positionedLeft) + "px",
      top: Math.round(top) + "px"
    });
    var handle = frame.find('.box-frame-header')[0];
    if (handle) {
      handle.setAttribute('data-x', Math.round(positionedLeft));
      handle.setAttribute('data-y', Math.round(top));
      handle.setAttribute('data-utopia-drag-ready', '1');
    }
  }

  function utopiaRefreshGroove() {
    $(".poke-info").each(function() {
      var panel = $(this);
      var ability = panel.find("select.ability").first();
      var groove = panel.find("select.utopia-groove-hits").first();

      if (!ability.length || !groove.length) return;

      groove.toggle(ability.val() === "Groove Guard");
    });
  }

  $(document).on(
    "change.utopiaGrooveV6",
    "select.ability",
    function() {
      utopiaRefreshGroove();
    }
  );

  $(document).on(
    "click.utopiaItemV6",
    "#ball-item",
    function() {
      utopiaPositionItemWindow();
    }
  );

  utopiaPositionControls();
  utopiaRefreshGroove();
});






/* UTOPIA_TRAINER_SELECTION_V5 */
function utopiaSelectTrainerSet(value) {
  var trainer = utopiaTrainerForValue(value);
  if (!trainer) return false;
  var input = $('.opposing');
  if (!input.length) return false;
  input.select2('data', {
    id: value,
    text: trainer.text,
    utopiaTrainer: true
  });
  if (input.val() !== value) {
    input.val(value);
  }
  input.trigger('change');
  return true;
}


/* UTOPIA_TRAINER_WIDTH_CLEAN_V2 */
/* UTOPIA_ITEM_FIX_V11 */
(function () {
  function setupUtopiaItemFixV11() {
    var frame = document.getElementById('item-box-frame');
    var bag = document.getElementById('ball-item');
    var critButton = document.getElementById('show-crits-toggle');
    var referenceButton = document.getElementById('double-legacy-mode');
    if (!frame || !bag || !critButton || !referenceButton) return;
    bag.setAttribute('type', 'button');
    bag.setAttribute('aria-label', 'Open items');
    var bagIcon = bag.querySelector('img');
    if (bagIcon) bagIcon.alt = 'Items';
    var hoverLabel = frame.querySelector('.utopia-item-hover-name');
    if (!hoverLabel) {
      hoverLabel = document.createElement('div');
      hoverLabel.className = 'utopia-item-hover-name';
      frame.appendChild(hoverLabel);
    }
    function hideHoverLabel() {
      hoverLabel.textContent = '';
      hoverLabel.style.display = 'none';
      hoverLabel.style.visibility = 'hidden';
    }
    function showHoverLabel(itemImg) {
      var label = itemImg.getAttribute('data-id') || itemImg.getAttribute('title') || itemImg.getAttribute('alt') || '';
      if (!label) {
        hideHoverLabel();
        return;
      }
      hoverLabel.textContent = label;
      hoverLabel.style.display = 'block';
      hoverLabel.style.visibility = 'hidden';
      requestAnimationFrame(function () {
        var itemRect = itemImg.getBoundingClientRect();
        var frameRect = frame.getBoundingClientRect();
        var labelRect = hoverLabel.getBoundingClientRect();
        var left = itemRect.right - frameRect.left + 8;
        var top = itemRect.top - frameRect.top - labelRect.height - 4;
        if (left + labelRect.width > frame.clientWidth - 8) left = frame.clientWidth - labelRect.width - 8;
        if (left < 8) left = 8;
        if (top < 8) top = itemRect.bottom - frameRect.top + 4;
        if (top + labelRect.height > frame.clientHeight - 8) top = frame.clientHeight - labelRect.height - 8;
        hoverLabel.style.left = left + 'px';
        hoverLabel.style.top = top + 'px';
        hoverLabel.style.visibility = 'visible';
      });
    }
    frame.addEventListener('mouseover', function (event) {
      var itemImg = event.target.closest ? event.target.closest('img[data-id]') : null;
      if (itemImg && frame.contains(itemImg)) showHoverLabel(itemImg);
    });
    frame.addEventListener('mouseout', function (event) {
      var itemImg = event.target.closest ? event.target.closest('img[data-id]') : null;
      if (!itemImg) return;
      if (!event.relatedTarget || !itemImg.contains(event.relatedTarget)) hideHoverLabel();
    });
    frame.addEventListener('click', function (event) {
      var itemImg = event.target.closest ? event.target.closest('img[data-id]') : null;
      if (itemImg) hideHoverLabel();
    });
    document.addEventListener('mousedown', function (event) {
      if (frame.hidden) return;
      if (frame.contains(event.target)) return;
      if (bag.contains(event.target)) return;
      frame.hidden = true;
      hideHoverLabel();
    }, true);
    function syncCritButtonStyle() {
      var style = window.getComputedStyle(referenceButton);
      [
        'padding',
        'font-size',
        'font-family',
        'font-weight',
        'line-height',
        'height',
        'border',
        'border-radius',
        'background-color',
        'color'
      ].forEach(function (property) {
        critButton.style.setProperty(property, style.getPropertyValue(property), 'important');
      });
      critButton.style.setProperty('width', 'auto', 'important');
      critButton.style.setProperty('min-width', '0', 'important');
      critButton.style.setProperty('max-width', 'none', 'important');
      critButton.style.setProperty('border', '0', 'important');
      critButton.style.setProperty('border-width', '0', 'important');
      critButton.style.setProperty('border-style', 'none', 'important');
      critButton.style.setProperty('outline', 'none', 'important');
      critButton.style.setProperty('box-shadow', 'none', 'important');
      critButton.style.setProperty('-webkit-appearance', 'none', 'important');
      critButton.style.setProperty('appearance', 'none', 'important');
      critButton.style.setProperty('white-space', 'nowrap', 'important');
    }
    syncCritButtonStyle();
    window.addEventListener('resize', syncCritButtonStyle);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupUtopiaItemFixV11);
  } else {
    setupUtopiaItemFixV11();
  }
})();

/* UTOPIA_CHANGE_LOGS_V1 */
(function () {
    if (window.utopiaChangeLogsInitialized) return;
    window.utopiaChangeLogsInitialized = true;

    function createElement(tag, className, text) {
        var element = document.createElement(tag);
        if (className) element.className = className;
        if (text) element.textContent = text;
        return element;
    }

    var patchNotes = [
        {
            version: "v1",
            subtitle: "Initial Release",
            sections: [
                {
                    title: "Calculator Integration",
                    notes: [
                        "Adapted the Run & Bun Damage Calculator for Pokémon Utopia.",
                        "Integrated Pokémon Utopia species data, including Mega Evolutions and Mega Z-A Evolutions.",
                        "Integrated Utopia specific moves, abilities, items, base stats and Pokémon types.",
                        "Updated the calculator to use the game's Pokémon data and battle mechanics.",
                        "Adapted Pokémon sets and calculations to Utopia's EV free gameplay.",
                        "Added support for Pokémon Utopia's custom abilities and battle effects.",
                        "Implemented custom ability calculations, including Bristleback, Rainburst, Blade Master, Melt Armor, Turtle Style, Blazing Fury, Kickstart, Perseverance and Battle Temper.",
                        "Added Groove Guard support with configurable stacks from x1 to x6."
                    ]
                },
                {
                    title: "Trainer Data",
                    notes: [
                        "Imported Utopia trainer teams into the calculator.",
                        "Added trainer Pokémon with their assigned moves, abilities, held items, levels and IVs.",
                        "Added trainer and Pokémon selection for the opposing team.",
                        "Added support for trainers with multiple Pokémon of the same species.",
                        "Improved the recognition of Pokémon sets belonging to individual trainers.",
                        "Added support for special trainer battles and combined trainer encounters.",
                        "Included paired trainer battles for Bernie & Ernie, Elias & Kata, Jenny & Caroline, Max & Greed and Kyle & Molly.",
                        "Preserved the separate single battle encounters where required.",
                        "Removed obsolete test trainer entries."
                    ]
                },
                {
                    title: "Battle Modes",
                    notes: [
                        "Added automatic Singles and Doubles mode selection based on trainer battle data.",
                        "Added support for opposing Pokémon in two separate Doubles rows.",
                        "Improved Pokémon selection and drag and drop behavior for Double Battles.",
                        "Added support for switching between Doubles Modern and Doubles Legacy.",
                        "Improved the interaction between the active Pokémon and the opposing trainer team."
                    ]
                },
                {
                    title: "Interface & Quality of Life",
                    notes: [
                        "Integrated Utopia Pokémon sprites and icons.",
                        "Added visual support for custom Pokémon forms and Shiny Pokémon.",
                        "Improved the Trainer Selection interface.",
                        "Updated item selection and Pokémon set controls.",
                        "Improved the layout and positioning of existing calculator controls.",
                        "Added custom item and Pokémon management improvements.",
                        "Preserved compatibility with Pokémon Showdown style set imports."
                    ]
                },
                {
                    title: "Initial Website Release",
                    notes: [
                        "Prepared the calculator for public browser access.",
                        "Configured website deployment using GitHub Pages and GitHub Actions.",
                        "Removed Google Analytics from the published website.",
                        "Prepared item icons for local hosting during website deployment.",
                        "Published the first test version of the Pokémon Utopia Calculator."
                    ]
                }
            ]
        },
        {
            version: "v2",
            subtitle: "Bug Fixes & Improvements",
            sections: [
                {
                    title: "Trainer & Battle Fixes",
                    notes: [
                        "Corrected the trainer Pokémon ordering to follow their original team slots.",
                        "Fixed incorrect opposing Pokémon positions in trainer battles.",
                        "Corrected Saturn's Absol form to Mega Absol Z.",
                        "Updated Channeler Martha's battle configuration to Doubles.",
                        "Improved the handling of opposing Pokémon during trainer changes.",
                        "Added automatic clearing of the previous trainer's lower Doubles row.",
                        "Improved calculation state handling when switching between Pokémon.",
                        "Added safeguards against calculation errors during Double Battles and drag and drop operations."
                    ]
                },
                {
                    title: "Pokémon & Item Fixes",
                    notes: [
                        "Corrected Never Melt Ice and Heavy Duty Boots item naming.",
                        "Improved item selection from the item bag.",
                        "Corrected Save Changes behavior to update an existing Pokémon set instead of creating an unwanted duplicate.",
                        "Improved the item window's position, size and scrolling behavior.",
                        "Restored the Berries section inside the item window.",
                        "Fixed the red close button's hover appearance.",
                        "Added the ability to close the item window by clicking outside it.",
                        "Improved the item bag icon's size and click area.",
                        "Added item name tooltips when hovering over item icons.",
                        "Improved window dragging and prevented unwanted background text selection."
                    ]
                },
                {
                    title: "Damage Calculation Improvements",
                    notes: [
                        "Added the C: Show Crits shortcut and button.",
                        "Added a critical hit damage preview using a x1.5 multiplier.",
                        "Added visual highlighting for critical damage ranges.",
                        "Added the ability to toggle critical damage preview on and off.",
                        "Adjusted the critical hit button to match the other calculator controls.",
                        "Reviewed Gem damage calculations for Pokémon Utopia's difficulty modes.",
                        "Added a secondary Easy/Normal Mode damage comparison for matching Gem boosted moves while retaining the Hard Mode calculation."
                    ]
                },
                {
                    title: "Interface Improvements",
                    notes: [
                        "Removed the obsolete Download Lua Script link.",
                        "Replaced Flowchart of the AI with AI document.",
                        "Updated the AI document link.",
                        "Updated the calculator title to Pokémon Utopia Calculator.",
                        "Added the Utopia U logo as the browser tab icon.",
                        "Renamed the calculation window button to Open Calculation Window.",
                        "Improved spacing, positioning and appearance of footer controls.",
                        "Updated the credits with Edited by MiMsu.",
                        "Improved the C: Show Crits button appearance and hover feedback.",
                        "Added the Change Logs window with versioned patch notes.",
                        "Fixed critical damage previews for all four Pokémon during modern Double Battles.",
                    ]
                }
            ]
        },
        {
            version: "v3",
            subtitle: "Damage and Ability Fixes",
            sections: [
                {
                    title: "Doubles and Interface",
                    notes: [
                        "Fixed critical damage previews for all four Pokémon in Doubles Modern.",
                        "Removed unwanted dash characters from Change Logs notes.",
                        "Updated the initial release description for Mega Evolutions and Mega Z-A Evolutions."
                    ]
                },
                {
                    title: "Pokémon and Abilities",
                    notes: [
                        "Corrected Sharpness for Mega Absol Z in both Galactic Commander Saturn battles.",
                        "Fixed Dragonize to convert Normal moves into Dragon moves with a 20% power boost.",
                        "Fixed Aura Guard to halve damage from contact moves.",
                        "Fixed Mega Sol to make Weather Ball a Fire move with 100 base power.",
                        "Fixed Fire Mane to increase Attack or Special Attack by 50% for Fire moves.",
                        "Fixed Turtle Style to increase the power of all Water type moves by 20%.",
                        "Removed bracketed suffixes from displayed Ability and Item names.",
                        "Removed duplicate Ability and Item entries from selection lists.",
                        "Updated displayed trainer class names to Ace Trainer, Pokémon Ranger and Pokémon Breeder.",
                        "Removed gender markers from trainer names except Galactic Grunts, which display Female or Male."
                    ]
                }
            ]
        },
        {
            version: "v4",
            subtitle: "Mega Toggle, Snow and Frostbitten",
            sections: [
                {
                    title: "Player Controls",
                    notes: [
                        "Added a Mega checkbox for eligible Pokémon on the player side only.",
                        "Mega toggling preserves held items and selected moves.",
                        "Shortened the displayed names of Mega Pokémon forms.",
                        "Updated Pokémon icons when switching between normal and Mega forms.",
                        "Enabled saving and restoring normal or Mega forms for imported Pokémon."
                    ]
                },
                {
                    title: "Battle Mechanics",
                    notes: [
                        "Replaced Hail with Snow and added the 50% physical Defense boost for Ice Pokémon.",
                        "Replaced Frozen with Frostbitten, reducing special move damage by 50%.",
                        "Fixed Eviolite Defense and Special Defense boosts for evolving Pokémon, including trainer Pokémon."
                    ]
                }
            ]
        },
        {
            version: "v5",
            subtitle: "Player Box Editing and Nature Colors",
            sections: [
                {
                    title: "Player Controls",
                    notes: [
                        /* UTOPIA_RXDATA_CHANGELOG_V5_2026 */
                        "Added direct import of Pokémon Essentials save files in the rxdata format.",
                        "Added import of player party Pokémon and PC Box Pokémon while excluding fainted Pokémon and Boxes 29 and 30.",
                        "Saved imported Pokémon as Custom Sets and updated existing sets instead of creating duplicates.",
                        "Fixed imported regional and alternate forms including Paldean Tauros and their sprites.",
                        "Added Pokémon nickname support when importing save files.",
                        "Fixed recognition of the Aura Guard ability when importing Mega Lucario Z.",
                        /* UTOPIA_MOVE_SPRITE_CHANGELOG_V5 */
                        "Fixed the order of manually selected moves so empty slots always appear last.",
                        "Fixed player Pokémon sprites showing incorrect species after switching Pokémon.",
                        "Save Changes now appears only after editing a Pokémon selected from the imported player Box.",
                        "Editing an imported Pokémon updates its existing set without creating a duplicate.",
                        "Selecting an unused Blank Set after opening an imported Pokémon allows adding a new Pokémon to the Box.",
                    ]
                },
                {
                    title: "Interface",
                    notes: [
                        "Added clearer red and blue Nature stat colors.",
                        "Fixed the Truck button to reload the first trainer and display their team."
                    ]
                }
            ]
        },
        {
            version: "v6",
            subtitle: "Battle Mechanics Corrections",
            sections: [
                {
                    title: "Battle Mechanics",
                    notes: [
                        "Fixed Thick Club increasing physical damage for Alolan Marowak.",
                        "Fixed trainer Hidden Power displaying the correct type based on IVs."
                    ]
                }
            ]
        }
    ];

    /* UTOPIA_CHANGELOG_V5_8 */
    patchNotes.sort(function(a, b) {
        return Number(b.version.slice(1)) -
            Number(a.version.slice(1));
    });

    function createNotesBody() {
        var body = createElement("div", "");
        body.id = "change-logs-body";

        patchNotes.forEach(function (version) {
            var heading = createElement("div", "change-logs-version");
            heading.textContent = version.version;
            body.appendChild(heading);

            var description = createElement("div", "change-logs-description");
            description.textContent = version.subtitle;
            body.appendChild(description);

            version.sections.forEach(function (section) {
                var container = createElement("div", "change-logs-section");
                var title = createElement("h4", "", section.title);
                var list = createElement("ul", "");

                section.notes.forEach(function (note) {
                    list.appendChild(createElement("li", "", note));
                });

                container.appendChild(title);
                container.appendChild(list);
                body.appendChild(container);
            });

            if (version.version !== patchNotes[patchNotes.length - 1].version) {
                body.appendChild(createElement("hr", "change-logs-divider"));
            }
        });

        return body;
    }

    function setupChangeLogs() {
        var buttons = document.getElementById("sets");
        var critButton = document.getElementById("show-crits-toggle");
        var referenceButton = document.getElementById("double-legacy-mode");

        if (!buttons || !critButton || !referenceButton) return;

        var changeButton = document.getElementById("change-logs-button");

        if (!changeButton) {
            changeButton = createElement("button", "", "Change Logs");
            changeButton.id = "change-logs-button";
            changeButton.type = "button";
            critButton.insertAdjacentElement("afterend", changeButton);
        }

        function syncButtonStyle() {
            var style = window.getComputedStyle(referenceButton);
            [
                "font-family",
                "font-size",
                "font-weight",
                "line-height",
                "height",
                "padding",
                "margin",
                "border",
                "border-radius",
                "background-color",
                "color"
            ].forEach(function (property) {
                changeButton.style.setProperty(
                    property,
                    style.getPropertyValue(property)
                );
            });
            changeButton.style.width = "auto";
            changeButton.style.minWidth = "0";
        }

        syncButtonStyle();

        var frame = document.getElementById("change-logs-frame");

        if (!frame) {
            frame = createElement("div", "box-frame");
            frame.id = "change-logs-frame";
            frame.hidden = true;

            var header = createElement("div", "box-frame-header");
            var heading = createElement("legend", "", "Change Logs");

            var close = createElement("div", "close-frame");
            close.id = "close-change-logs";
            close.setAttribute("role", "button");
            close.setAttribute("tabindex", "0");
            close.setAttribute("aria-label", "Close Change Logs");

            var line1 = createElement("div", "mdiv");
            var line2 = createElement("div", "md");
            line1.appendChild(line2);
            close.appendChild(line1);

            header.appendChild(heading);
            header.appendChild(close);

            frame.appendChild(header);
            frame.appendChild(createNotesBody());
            document.body.appendChild(frame);
        }

        var closeButton = document.getElementById("close-change-logs");
        var scrollBody = document.getElementById("change-logs-body");

        function openWindow() {
            var width = Math.min(650, window.innerWidth - 24);
            var height = Math.min(470, window.innerHeight - 24);
            var left = Math.max(12, (window.innerWidth - width) / 2);
            var top = Math.max(12, (window.innerHeight - height) / 2);

            frame.style.position = "fixed";
            frame.style.width = width + "px";
            frame.style.height = height + "px";
            frame.style.left = left + "px";
            frame.style.top = top + "px";

            var header = frame.querySelector(".box-frame-header");
            if (header) {
                header.setAttribute("data-x", left);
                header.setAttribute("data-y", top);
                header.setAttribute("data-utopia-drag-ready", "1");
            }

            if (scrollBody) scrollBody.scrollTop = 0;
            frame.hidden = false;
        }

        function closeWindow() {
            frame.hidden = true;
        }

        changeButton.addEventListener("click", function () {
            if (frame.hidden) openWindow();
            else closeWindow();
        });

        closeButton.addEventListener("click", closeWindow);

        closeButton.addEventListener("keydown", function (event) {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                closeWindow();
            }
        });

        document.addEventListener("mousedown", function (event) {
            if (frame.hidden) return;
            if (frame.contains(event.target)) return;
            if (changeButton.contains(event.target)) return;
            closeWindow();
        }, true);

        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape" && !frame.hidden) {
                closeWindow();
            }
        });

        var hoverReference = document.getElementById("double-legacy-mode");

        if (hoverReference) {
            var critOriginalBackground = "";

            critButton.addEventListener("mouseenter", function () {
                var style = window.getComputedStyle(hoverReference);
                critOriginalBackground = style.backgroundColor;
                critButton.style.setProperty(
                    "background-color",
                    "#888888",
                    "important"
                );
            });

            critButton.addEventListener("mouseleave", function () {
                critButton.style.setProperty(
                    "background-color",
                    critOriginalBackground || "#626262",
                    "important"
                );
            });

            critButton.addEventListener("blur", function () {
                if (!critButton.matches(":hover")) {
                    critButton.style.setProperty(
                        "background-color",
                        critOriginalBackground || "#626262",
                        "important"
                    );
                }
            });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", setupChangeLogs);
    } else {
        setupChangeLogs();
    }
})();


/* UTOPIA_CRIT_BUTTON_LABEL_V1 */
(function () {
    function updateCritButtonLabel() {
        var button = document.getElementById('show-crits-toggle');
        if (!button) return;
        var active = window.utopiaShowCrits === true;
        var label = active ? 'C: Hide Crits' : 'C: Show Crits';
        if (button.textContent !== label) {
            button.textContent = label;
        }
    }

    function setupCritButtonLabel() {
        var button = document.getElementById('show-crits-toggle');
        if (!button) return;

        updateCritButtonLabel();

        button.addEventListener('click', function () {
            updateCritButtonLabel();
        });

        document.addEventListener('keyup', function (event) {
            if (event.key === 'c' || event.key === 'C') {
                updateCritButtonLabel();
            }
        });

        var damageLabels = document.querySelectorAll('[id^="resultDamage"]');

        if (damageLabels.length) {
            var observer = new MutationObserver(function () {
                updateCritButtonLabel();
            });

            damageLabels.forEach(function (element) {
                observer.observe(element, {
                    attributes: true,
                    attributeFilter: ['class']
                });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupCritButtonLabel);
    } else {
        setupCritButtonLabel();
    }
})();


/* UTOPIA_PLAYER_MEGA_TOGGLE_V5 */
$(function () {
    var side = $('#p1');
    var forme = side.find('select.forme').first();

    if (!forme.length) return;

    var formRow = forme.parent();

    var label = $('<label>', {
        id: 'utopia-mega-toggle',
        title: 'Toggle Mega Evolution'
    });

    var checkbox = $('<input>', {
        type: 'checkbox'
    });

    label.append(checkbox);
    label.append(document.createTextNode(' Mega'));

    label.css({
        display: 'none',
        marginLeft: '8px',
        whiteSpace: 'nowrap',
        verticalAlign: 'middle',
        fontSize: '12px',
        cursor: 'default'
    });

    checkbox.css({
        margin: '0 4px 0 0',
        verticalAlign: 'middle',
        cursor: 'default'
    });

    forme.after(label);

    var previousNormalForm = '';
    var switching = false;

    /* UTOPIA_MEGA_ICON_SAVE_V6 */
    function currentCustomSet() {
        var chosen = side.find('.set-selector').val() || '';
        var separator = chosen.indexOf(' (');
        if (separator < 0 || !chosen.endsWith(')')) return null;
        var species = chosen.slice(0, separator);
        var label = chosen.slice(separator + 2, -1);
        var custom;
        try {
            custom = JSON.parse(localStorage.customsets || '{}');
        } catch (error) {
            return null;
        }
        return custom[species] && custom[species][label] ? custom[species][label] : null;
    }

    function refreshMegaIcon() {
        var selected = String(
            side.find('.set-selector').val() || ''
        );

        var icon = document.getElementById('p1mon');

        if (!selected || !icon) return;

        topPokemonIcon(selected, icon);
    }

    function markMegaChange() {
        if (typeof utopiaBoxSaveGate !== 'undefined') {
            utopiaBoxSaveGate.edited();
        }
    }

    function isMega(value) {
        return /\[Mega [^\]]+\]|\-Mega(?:\b|\-)/i.test(String(value || ''));
    }

    function getForms() {
        return forme.find('option').map(function () {
            return this.value;
        }).get();
    }

    function updateWidth() {
        var selected = forme.find('option:selected');
        var text = selected.text() || '';

        if (!text) return;

        var measurement = $('<span>').text(text).css({
            position: 'absolute',
            visibility: 'hidden',
            whiteSpace: 'nowrap',
            fontFamily: forme.css('font-family'),
            fontSize: forme.css('font-size'),
            fontWeight: forme.css('font-weight')
        });

        $('body').append(measurement);

        var width = Math.ceil(measurement.outerWidth()) + 26;

        measurement.remove();

        forme.css({
            width: width + 'px',
            maxWidth: '100%',
            boxSizing: 'border-box'
        });
    }

    function update() {
        var forms = getForms();
        var hasMega = forms.some(isMega);
        var hasNormal = forms.some(function (value) {
            return !isMega(value);
        });

        var eligible = hasMega && hasNormal;

        label.css('display', eligible ? 'inline-block' : 'none');

        checkbox.prop('checked', eligible && isMega(forme.val()));

        if (!eligible) previousNormalForm = '';

        updateWidth();
        refreshMegaIcon();
    }

    function changeForm(target) {
        if (!target || target === forme.val()) return;

        var item = side.find('select.item').val();
        var moves = side.find('select.move-selector').map(function () {
            return $(this).val();
        }).get();

        switching = true;

        try {
            forme.val(target).trigger('change');

            if (item !== undefined) {
                side.find('select.item').val(item).trigger('change');
            }

            side.find('select.move-selector').each(function (index) {
                if (moves[index] !== undefined) {
                    $(this).val(moves[index]).trigger('change');
                }
            });
        } finally {
            switching = false;
        }

        update();

        if (typeof performCalculations === 'function') {
            performCalculations();
        }
    }

    checkbox.on('change', function () {
        var forms = getForms();
        var current = forme.val();

        if (this.checked) {
            if (!isMega(current)) {
                previousNormalForm = current;
            }

            var mega = forms.find(isMega);

            changeForm(mega);
        } else {
            var normal = forms.indexOf(previousNormalForm) !== -1
                ? previousNormalForm
                : forms.find(function (value) {
                    return !isMega(value);
                });

            changeForm(normal);
        }
        markMegaChange();
    });

    forme.on('change.utopiaMegaV5', function () {
        if (!switching) {
            if (!isMega(forme.val())) {
                previousNormalForm = forme.val();
            }
            update();
        }
    });

    side.find('input.set-selector.player').on('change.utopiaMegaV5', function () {
        previousNormalForm = '';
        setTimeout(update, 0);
    });

    update();
});


/* UTOPIA_PLAYER_DIAGNOSTICS_V5 */
(function () {
    'use strict';

    function readSets() {
        try {
            return JSON.parse(localStorage.customsets || '{}');
        } catch (error) {
            return {};
        }
    }

    function snapshot(reason) {
        try {
            var input = $('#p1 .set-selector');
            var selected = String(input.val() || '');
            var display = '';
            var select2Id = '';

            try {
                var data = input.select2('data');
                select2Id = data ? String(data.id || '') : '';
                var container = input.select2('container');
                display = container.find('.select2-chosen').text().trim();
            } catch (error) {}

            var species = selected.split(' (')[0];
            var separator = selected.indexOf(' (');
            var label = separator >= 0 && selected.endsWith(')')
                ? selected.slice(separator + 2, -1)
                : '';

            var form = String($('#p1 .forme').val() || '');
            var sets = readSets();
            var saved = sets[species] && sets[species][label];
            var icon = document.getElementById('p1mon');

            var gate = typeof utopiaBoxSaveGate !== 'undefined'
                ? utopiaBoxSaveGate
                : null;

            var map = typeof UTOPIA_ICON_MAP !== 'undefined'
                ? UTOPIA_ICON_MAP
                : {};

            var spriteSpecies = map[species];
            var spriteForm = map[form];

            console.group(
                '%cUTOPIA DIAGNOSE: ' + reason,
                'color:#59bdff;font-weight:bold'
            );

            console.table({
                Auswahlwert: selected,
                AngezeigterName: display,
                Select2ID: select2Id,
                Pokemon: species,
                SetName: label,
                Form: form,
                BasisSpeciesKey: spriteSpecies
                    ? spriteSpecies.speciesKey
                    : '(nicht gefunden)',
                FormSpeciesKey: spriteForm
                    ? spriteForm.speciesKey
                    : '(nicht gefunden)',
                FormImSet: saved
                    ? String(saved.forme || '')
                    : '(nicht gespeichert)',
                LinkerSpritePfad: icon
                    ? icon.getAttribute('src')
                    : '(Icon fehlt)',
                ErwartetesBasisIcon: spriteSpecies
                    ? spriteSpecies.normal
                    : '(nicht gefunden)',
                GateAngeklickt: gate ? gate.clicked : '',
                GateBlankTarget: gate ? gate.blankTarget : '',
                GateAktiviert: gate ? gate.armed : false,
                GateBearbeitet: gate ? gate.dirty : false,
                SaveButtonVersteckt: $('#save-change').prop('hidden'),
                GespeichertePokemon: Object.keys(sets).join(', ')
            });

            console.log('Gespeicherte Sets der Spezies:', sets[species] || {});
            console.groupEnd();
        } catch (error) {
            console.error('UTOPIA DIAGNOSE ERROR:', error);
        }
    }

    function later(reason) {
        setTimeout(function () {
            snapshot(reason);
        }, 50);
    }

    $(document).on(
        'click.utopiaDiagnostics',
        '.trainer-pok.left-side',
        function () {
            later('Box Pokemon angeklickt');
        }
    );

    $(document).on(
        'select2-selecting.utopiaDiagnostics',
        '#p1 .set-selector',
        function (event) {
            var choice = event.choice || event.object || {};
            console.log(
                'UTOPIA DIAGNOSE: Select2 waehlt:',
                choice.id || choice.text || choice
            );
            later('Pokemon im Suchfeld ausgewaehlt');
        }
    );

    $(document).on(
        'change.utopiaDiagnostics',
        '#p1 .set-selector',
        function () {
            later('Pokemon Auswahl geaendert');
        }
    );

    $(document).on(
        'click.utopiaDiagnostics',
        '#save-change',
        function () {
            snapshot('VOR Save Changes');
            later('NACH Save Changes');
        }
    );

    $(function () {
        later('SEITENSTART');
        console.log(
            '%cUTOPIA DIAGNOSE AKTIV',
            'color:#59bdff;font-weight:bold'
        );
    });
})();
