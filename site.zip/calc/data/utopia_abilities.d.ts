export declare const UTOPIA_ABILITIES: string[];
