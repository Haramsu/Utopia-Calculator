export declare const UTOPIA_ITEMS: string[];
