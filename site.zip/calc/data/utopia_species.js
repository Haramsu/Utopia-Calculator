"use strict";
exports.__esModule = true;

exports.UTOPIA_SPECIES = {
    "Abomasnow": {
        "types": [
            "Grass",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 92,
            "df": 75,
            "sa": 92,
            "sd": 85,
            "sp": 60
        },
        "weightkg": 135.5,
        "abilities": {
            "0": "Soundproof"
        },
        "otherFormes": [
            "Abomasnow [Mega Abomasnow]"
        ]
    },
    "Abomasnow [Mega Abomasnow]": {
        "types": [
            "Grass",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 132,
            "df": 105,
            "sa": 132,
            "sd": 105,
            "sp": 30
        },
        "weightkg": 185,
        "abilities": {
            "0": "Soundproof"
        },
        "baseSpecies": "Abomasnow"
    },
    "Abra": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 25,
            "at": 20,
            "df": 15,
            "sa": 105,
            "sd": 55,
            "sp": 90
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Absol": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 65,
            "at": 130,
            "df": 60,
            "sa": 75,
            "sd": 60,
            "sp": 75
        },
        "weightkg": 47,
        "abilities": {
            "0": "Super Luck"
        },
        "otherFormes": [
            "Absol [Mega Absol]",
            "Absol [Mega Absol Z]"
        ]
    },
    "Absol [Mega Absol]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 65,
            "at": 150,
            "df": 60,
            "sa": 115,
            "sd": 60,
            "sp": 115
        },
        "weightkg": 49,
        "abilities": {
            "0": "Magic Bounce"
        },
        "baseSpecies": "Absol"
    },
    "Absol [Mega Absol Z]": {
        "types": [
            "Dark",
            "Ghost"
        ],
        "bs": {
            "hp": 65,
            "at": 154,
            "df": 60,
            "sa": 75,
            "sd": 60,
            "sp": 151
        },
        "weightkg": 49,
        "abilities": {
            "0": "Sharpness"
        },
        "baseSpecies": "Absol"
    },
    "Accelgor": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 80,
            "at": 70,
            "df": 40,
            "sa": 100,
            "sd": 60,
            "sp": 145
        },
        "weightkg": 25.3,
        "abilities": {
            "0": "Hydration"
        }
    },
    "Aegislash": {
        "types": [
            "Steel",
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 140,
            "sa": 50,
            "sd": 140,
            "sp": 60
        },
        "weightkg": 53,
        "abilities": {
            "0": "Stance Change"
        },
        "otherFormes": [
            "Aegislash [Blade Forme]"
        ]
    },
    "Aegislash [Blade Forme]": {
        "types": [
            "Steel",
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 140,
            "df": 50,
            "sa": 140,
            "sd": 50,
            "sp": 60
        },
        "weightkg": 53,
        "abilities": {
            "0": "Stance Change"
        },
        "baseSpecies": "Aegislash"
    },
    "Aerodactyl": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 105,
            "df": 65,
            "sa": 60,
            "sd": 75,
            "sp": 130
        },
        "weightkg": 59,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Aerodactyl [Mega Aerodactyl]"
        ]
    },
    "Aerodactyl [Mega Aerodactyl]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 135,
            "df": 85,
            "sa": 70,
            "sd": 95,
            "sp": 150
        },
        "weightkg": 79,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Aerodactyl"
    },
    "Aggron": {
        "types": [
            "Steel",
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 180,
            "sa": 60,
            "sd": 60,
            "sp": 50
        },
        "weightkg": 360,
        "abilities": {
            "0": "Sturdy"
        },
        "otherFormes": [
            "Aggron [Mega Aggron]"
        ]
    },
    "Aggron [Mega Aggron]": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 140,
            "df": 230,
            "sa": 60,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 395,
        "abilities": {
            "0": "Filter"
        },
        "baseSpecies": "Aggron"
    },
    "Aipom": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 70,
            "df": 55,
            "sa": 40,
            "sd": 55,
            "sp": 85
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Technician"
        }
    },
    "Alakazam": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 55,
            "at": 50,
            "df": 45,
            "sa": 135,
            "sd": 95,
            "sp": 120
        },
        "weightkg": 48,
        "abilities": {
            "0": "Synchronize"
        },
        "otherFormes": [
            "Alakazam [Mega Alakazam]"
        ]
    },
    "Alakazam [Mega Alakazam]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 55,
            "at": 50,
            "df": 65,
            "sa": 175,
            "sd": 105,
            "sp": 150
        },
        "weightkg": 48,
        "abilities": {
            "0": "Trace"
        },
        "baseSpecies": "Alakazam"
    },
    "Alcremie": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "otherFormes": [
            "Alcremie [Ruby Cream]",
            "Alcremie [Form 8]",
            "Alcremie [Form 9]",
            "Alcremie [Form 10]",
            "Alcremie [Form 11]",
            "Alcremie [Form 12]",
            "Alcremie [Form 13]",
            "Alcremie [Matcha Cream]",
            "Alcremie [Form 15]",
            "Alcremie [Form 16]",
            "Alcremie [Form 17]",
            "Alcremie [Form 18]",
            "Alcremie [Form 19]",
            "Alcremie [Form 20]",
            "Alcremie [Mint Cream]",
            "Alcremie [Form 22]",
            "Alcremie [Form 23]",
            "Alcremie [Form 24]",
            "Alcremie [Form 25]",
            "Alcremie [Form 26]",
            "Alcremie [Form 27]",
            "Alcremie [Lemon Cream]",
            "Alcremie [Form 29]",
            "Alcremie [Form 30]",
            "Alcremie [Form 31]",
            "Alcremie [Form 32]",
            "Alcremie [Form 33]",
            "Alcremie [Form 34]",
            "Alcremie [Salted Cream]",
            "Alcremie [Form 36]",
            "Alcremie [Form 37]",
            "Alcremie [Form 38]",
            "Alcremie [Form 39]",
            "Alcremie [Form 40]",
            "Alcremie [Form 41]",
            "Alcremie [Ruby Swirl]",
            "Alcremie [Form 43]",
            "Alcremie [Form 44]",
            "Alcremie [Form 45]",
            "Alcremie [Form 46]",
            "Alcremie [Form 47]",
            "Alcremie [Form 48]",
            "Alcremie [Caramel Swirl]",
            "Alcremie [Form 50]",
            "Alcremie [Form 51]",
            "Alcremie [Form 52]",
            "Alcremie [Form 53]",
            "Alcremie [Form 54]",
            "Alcremie [Form 55]",
            "Alcremie [Rainbow Swirl]",
            "Alcremie [Form 57]",
            "Alcremie [Form 58]",
            "Alcremie [Form 59]",
            "Alcremie [Form 60]",
            "Alcremie [Form 61]",
            "Alcremie [Form 62]"
        ]
    },
    "Alcremie [Ruby Cream]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 8]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 9]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 10]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 11]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 12]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 13]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Matcha Cream]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 15]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 16]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 17]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 18]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 19]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 20]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Mint Cream]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 22]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 23]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 24]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 25]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 26]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 27]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Lemon Cream]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 29]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 30]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 31]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 32]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 33]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 34]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Salted Cream]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 36]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 37]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 38]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 39]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 40]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 41]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Ruby Swirl]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 43]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 44]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 45]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 46]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 47]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 48]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Caramel Swirl]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 50]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 51]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 52]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 53]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 54]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 55]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Rainbow Swirl]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 57]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 58]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 59]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 60]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 61]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alcremie [Form 62]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 121,
            "sp": 64
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        },
        "baseSpecies": "Alcremie"
    },
    "Alomomola": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 165,
            "at": 75,
            "df": 80,
            "sa": 40,
            "sd": 45,
            "sp": 65
        },
        "weightkg": 31.6,
        "abilities": {
            "0": "Healer"
        }
    },
    "Altaria": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 70,
            "df": 90,
            "sa": 70,
            "sd": 105,
            "sp": 80
        },
        "weightkg": 20.6,
        "abilities": {
            "0": "Natural Cure"
        },
        "otherFormes": [
            "Altaria [Mega Altaria]"
        ]
    },
    "Altaria [Mega Altaria]": {
        "types": [
            "Dragon",
            "Fairy"
        ],
        "bs": {
            "hp": 75,
            "at": 110,
            "df": 110,
            "sa": 110,
            "sd": 105,
            "sp": 80
        },
        "weightkg": 20.6,
        "abilities": {
            "0": "Pixilate"
        },
        "baseSpecies": "Altaria"
    },
    "Amaura": {
        "types": [
            "Rock",
            "Ice"
        ],
        "bs": {
            "hp": 77,
            "at": 59,
            "df": 50,
            "sa": 67,
            "sd": 63,
            "sp": 46
        },
        "weightkg": 25.2,
        "abilities": {
            "0": "Refrigerate"
        }
    },
    "Ambipom": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 100,
            "df": 66,
            "sa": 60,
            "sd": 66,
            "sp": 115
        },
        "weightkg": 20.3,
        "abilities": {
            "0": "Technician"
        }
    },
    "Amoonguss": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 114,
            "at": 85,
            "df": 70,
            "sa": 85,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Ampharos": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 90,
            "at": 75,
            "df": 85,
            "sa": 115,
            "sd": 90,
            "sp": 55
        },
        "weightkg": 61.5,
        "abilities": {
            "0": "Static"
        },
        "otherFormes": [
            "Ampharos [Mega Ampharos]"
        ]
    },
    "Ampharos [Mega Ampharos]": {
        "types": [
            "Electric",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 95,
            "df": 105,
            "sa": 165,
            "sd": 110,
            "sp": 45
        },
        "weightkg": 61.5,
        "abilities": {
            "0": "Mold Breaker"
        },
        "baseSpecies": "Ampharos"
    },
    "Annihilape": {
        "types": [
            "Fighting",
            "Ghost"
        ],
        "bs": {
            "hp": 110,
            "at": 115,
            "df": 80,
            "sa": 50,
            "sd": 90,
            "sp": 90
        },
        "weightkg": 56,
        "abilities": {
            "0": "Vital Spirit"
        }
    },
    "Anorith": {
        "types": [
            "Rock",
            "Bug"
        ],
        "bs": {
            "hp": 45,
            "at": 95,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Appletun": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 110,
            "at": 85,
            "df": 80,
            "sa": 100,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 13,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Applin": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 80,
            "sa": 40,
            "sd": 40,
            "sp": 20
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Araquanid": {
        "types": [
            "Water",
            "Bug"
        ],
        "bs": {
            "hp": 68,
            "at": 70,
            "df": 92,
            "sa": 50,
            "sd": 132,
            "sp": 42
        },
        "weightkg": 82,
        "abilities": {
            "0": "Water Bubble"
        }
    },
    "Arbok": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 95,
            "df": 69,
            "sa": 65,
            "sd": 79,
            "sp": 80
        },
        "weightkg": 65,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Arboliva": {
        "types": [
            "Grass",
            "Normal"
        ],
        "bs": {
            "hp": 78,
            "at": 69,
            "df": 90,
            "sa": 125,
            "sd": 109,
            "sp": 39
        },
        "weightkg": 48.2,
        "abilities": {
            "0": "Early Bird"
        }
    },
    "Arcanine": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 90,
            "at": 110,
            "df": 80,
            "sa": 100,
            "sd": 80,
            "sp": 95
        },
        "weightkg": 155,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Arcanine [Hisuian]"
        ]
    },
    "Arcanine [Hisuian]": {
        "types": [
            "Fire",
            "Rock"
        ],
        "bs": {
            "hp": 95,
            "at": 115,
            "df": 80,
            "sa": 95,
            "sd": 80,
            "sp": 90
        },
        "weightkg": 168,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Arcanine"
    },
    "Arceus": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "otherFormes": [
            "Arceus [Fighting Type]",
            "Arceus [Flying Type]",
            "Arceus [Poison Type]",
            "Arceus [Ground Type]",
            "Arceus [Rock Type]",
            "Arceus [Bug Type]",
            "Arceus [Ghost Type]",
            "Arceus [Steel Type]",
            "Arceus [Unknown Type]",
            "Arceus [Fire Type]",
            "Arceus [Water Type]",
            "Arceus [Grass Type]",
            "Arceus [Electric Type]",
            "Arceus [Psychic Type]",
            "Arceus [Ice Type]",
            "Arceus [Dragon Type]",
            "Arceus [Dark Type]",
            "Arceus [Fairy Type]"
        ]
    },
    "Arceus [Fighting Type]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Flying Type]": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Poison Type]": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Ground Type]": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Rock Type]": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Bug Type]": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Ghost Type]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Steel Type]": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Unknown Type]": {
        "types": [
            "???"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Fire Type]": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Water Type]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Grass Type]": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Electric Type]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Psychic Type]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Ice Type]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Dragon Type]": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Dark Type]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Arceus [Fairy Type]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 120,
            "at": 120,
            "df": 120,
            "sa": 120,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 320,
        "abilities": {
            "0": "Multitype"
        },
        "baseSpecies": "Arceus"
    },
    "Archaludon": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 105,
            "df": 130,
            "sa": 125,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 60,
        "abilities": {
            "0": "Stamina"
        }
    },
    "Archen": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 112,
            "df": 45,
            "sa": 74,
            "sd": 45,
            "sp": 70
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Defeatist"
        }
    },
    "Archeops": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 140,
            "df": 65,
            "sa": 112,
            "sd": 65,
            "sp": 110
        },
        "weightkg": 32,
        "abilities": {
            "0": "Defeatist"
        }
    },
    "Arctibax": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 95,
            "df": 66,
            "sa": 45,
            "sd": 65,
            "sp": 62
        },
        "weightkg": 30,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Arctovish": {
        "types": [
            "Water",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 90,
            "df": 100,
            "sa": 80,
            "sd": 90,
            "sp": 55
        },
        "weightkg": 175,
        "abilities": {
            "0": "Slush Rush"
        }
    },
    "Arctozolt": {
        "types": [
            "Electric",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 90,
            "sa": 90,
            "sd": 80,
            "sp": 55
        },
        "weightkg": 150,
        "abilities": {
            "0": "Slush Rush"
        }
    },
    "Ariados": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 40
        },
        "weightkg": 33.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Armaldo": {
        "types": [
            "Rock",
            "Bug"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 100,
            "sa": 70,
            "sd": 80,
            "sp": 45
        },
        "weightkg": 68.2,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Armarouge": {
        "types": [
            "Fire",
            "Psychic"
        ],
        "bs": {
            "hp": 85,
            "at": 60,
            "df": 100,
            "sa": 125,
            "sd": 80,
            "sp": 75
        },
        "weightkg": 85,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Aromatisse": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 101,
            "at": 72,
            "df": 72,
            "sa": 99,
            "sd": 89,
            "sp": 29
        },
        "weightkg": 15.5,
        "abilities": {
            "0": "Healer"
        }
    },
    "Aron": {
        "types": [
            "Steel",
            "Rock"
        ],
        "bs": {
            "hp": 50,
            "at": 70,
            "df": 100,
            "sa": 40,
            "sd": 40,
            "sp": 30
        },
        "weightkg": 60,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Arrokuda": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 41,
            "at": 63,
            "df": 40,
            "sa": 40,
            "sd": 30,
            "sp": 66
        },
        "weightkg": 1,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Articuno": {
        "types": [
            "Ice",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 85,
            "df": 100,
            "sa": 95,
            "sd": 125,
            "sp": 85
        },
        "weightkg": 55.4,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Articuno [Galarian]"
        ]
    },
    "Articuno [Galarian]": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 85,
            "df": 85,
            "sa": 125,
            "sd": 100,
            "sp": 95
        },
        "weightkg": 50.9,
        "abilities": {
            "0": "Competitive"
        },
        "baseSpecies": "Articuno"
    },
    "Audino": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 103,
            "at": 60,
            "df": 86,
            "sa": 60,
            "sd": 86,
            "sp": 50
        },
        "weightkg": 31,
        "abilities": {
            "0": "Healer"
        },
        "otherFormes": [
            "Audino [Mega Audino]"
        ]
    },
    "Audino [Mega Audino]": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 103,
            "at": 60,
            "df": 126,
            "sa": 80,
            "sd": 126,
            "sp": 50
        },
        "weightkg": 32,
        "abilities": {
            "0": "Healer"
        },
        "baseSpecies": "Audino"
    },
    "Aurorus": {
        "types": [
            "Rock",
            "Ice"
        ],
        "bs": {
            "hp": 123,
            "at": 77,
            "df": 72,
            "sa": 99,
            "sd": 92,
            "sp": 58
        },
        "weightkg": 225,
        "abilities": {
            "0": "Refrigerate"
        }
    },
    "Avalugg": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 95,
            "at": 117,
            "df": 184,
            "sa": 44,
            "sd": 46,
            "sp": 28
        },
        "weightkg": 505,
        "abilities": {
            "0": "Own Tempo"
        },
        "otherFormes": [
            "Avalugg [Hisuian]"
        ]
    },
    "Avalugg [Hisuian]": {
        "types": [
            "Ice",
            "Rock"
        ],
        "bs": {
            "hp": 95,
            "at": 127,
            "df": 184,
            "sa": 34,
            "sd": 36,
            "sp": 38
        },
        "weightkg": 262.4,
        "abilities": {
            "0": "Strong Jaw"
        },
        "baseSpecies": "Avalugg"
    },
    "Axew": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 46,
            "at": 87,
            "df": 60,
            "sa": 30,
            "sd": 40,
            "sp": 57
        },
        "weightkg": 18,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Azelf": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 70,
            "sa": 125,
            "sd": 70,
            "sp": 115
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Azumarill": {
        "types": [
            "Water",
            "Fairy"
        ],
        "bs": {
            "hp": 100,
            "at": 65,
            "df": 80,
            "sa": 75,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 28.5,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Azurill": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 20,
            "df": 40,
            "sa": 20,
            "sd": 40,
            "sp": 20
        },
        "weightkg": 2,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Bagon": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 45,
            "at": 75,
            "df": 60,
            "sa": 40,
            "sd": 30,
            "sp": 50
        },
        "weightkg": 42.1,
        "abilities": {
            "0": "Rock Head"
        }
    },
    "Baltoy": {
        "types": [
            "Ground",
            "Psychic"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 55,
            "sa": 40,
            "sd": 70,
            "sp": 55
        },
        "weightkg": 21.5,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Banette": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 64,
            "at": 115,
            "df": 65,
            "sa": 83,
            "sd": 63,
            "sp": 65
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Insomnia"
        },
        "otherFormes": [
            "Banette [Mega Banette]"
        ]
    },
    "Banette [Mega Banette]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 64,
            "at": 165,
            "df": 75,
            "sa": 93,
            "sd": 83,
            "sp": 75
        },
        "weightkg": 13,
        "abilities": {
            "0": "Prankster"
        },
        "baseSpecies": "Banette"
    },
    "Barbaracle": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 72,
            "at": 105,
            "df": 115,
            "sa": 54,
            "sd": 86,
            "sp": 68
        },
        "weightkg": 96,
        "abilities": {
            "0": "Tough Claws"
        },
        "otherFormes": [
            "Barbaracle [Mega Barbaracle]"
        ]
    },
    "Barbaracle [Mega Barbaracle]": {
        "types": [
            "Rock",
            "Fighting"
        ],
        "bs": {
            "hp": 72,
            "at": 140,
            "df": 130,
            "sa": 64,
            "sd": 106,
            "sp": 88
        },
        "weightkg": 100,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Barbaracle"
    },
    "Barboach": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 50,
            "at": 48,
            "df": 43,
            "sa": 46,
            "sd": 41,
            "sp": 60
        },
        "weightkg": 1.9,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Barraskewda": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 61,
            "at": 123,
            "df": 60,
            "sa": 60,
            "sd": 50,
            "sp": 136
        },
        "weightkg": 30,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Basculegion": {
        "types": [
            "Water",
            "Ghost"
        ],
        "bs": {
            "hp": 120,
            "at": 112,
            "df": 65,
            "sa": 80,
            "sd": 75,
            "sp": 78
        },
        "weightkg": 110,
        "abilities": {
            "0": "Swift Swim"
        },
        "otherFormes": [
            "Basculegion [Female]"
        ]
    },
    "Basculegion [Female]": {
        "types": [
            "Water",
            "Ghost"
        ],
        "bs": {
            "hp": 120,
            "at": 92,
            "df": 65,
            "sa": 100,
            "sd": 75,
            "sp": 78
        },
        "weightkg": 110,
        "abilities": {
            "0": "Swift Swim"
        },
        "baseSpecies": "Basculegion"
    },
    "Basculin": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 92,
            "df": 65,
            "sa": 80,
            "sd": 55,
            "sp": 98
        },
        "weightkg": 18,
        "abilities": {
            "0": "Reckless"
        },
        "otherFormes": [
            "Basculin [Blue-Striped]",
            "Basculin [White-Striped]"
        ]
    },
    "Basculin [Blue-Striped]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 92,
            "df": 65,
            "sa": 80,
            "sd": 55,
            "sp": 98
        },
        "weightkg": 18,
        "abilities": {
            "0": "Rock Head"
        },
        "baseSpecies": "Basculin"
    },
    "Basculin [White-Striped]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 92,
            "df": 65,
            "sa": 80,
            "sd": 55,
            "sp": 98
        },
        "weightkg": 18,
        "abilities": {
            "0": "Rattled"
        },
        "baseSpecies": "Basculin"
    },
    "Bastiodon": {
        "types": [
            "Rock",
            "Steel"
        ],
        "bs": {
            "hp": 60,
            "at": 52,
            "df": 168,
            "sa": 47,
            "sd": 138,
            "sp": 30
        },
        "weightkg": 149.5,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Baxcalibur": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 115,
            "at": 145,
            "df": 92,
            "sa": 75,
            "sd": 86,
            "sp": 87
        },
        "weightkg": 210,
        "abilities": {
            "0": "Inner Focus"
        },
        "otherFormes": [
            "Baxcalibur [Mega Baxcalibur]"
        ]
    },
    "Baxcalibur [Mega Baxcalibur]": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 115,
            "at": 175,
            "df": 117,
            "sa": 105,
            "sd": 101,
            "sp": 87
        },
        "weightkg": 315,
        "abilities": {
            "0": "Inner Focus"
        },
        "baseSpecies": "Baxcalibur"
    },
    "Bayleef": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 62,
            "df": 80,
            "sa": 63,
            "sd": 80,
            "sp": 60
        },
        "weightkg": 15.8,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Beartic": {
        "types": [
            "Ice",
            "Fighting"
        ],
        "bs": {
            "hp": 95,
            "at": 130,
            "df": 80,
            "sa": 70,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 260,
        "abilities": {
            "0": "Slush Rush"
        }
    },
    "Beautifly": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 70,
            "df": 50,
            "sa": 100,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 28.4,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Beedrill": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 40,
            "sa": 45,
            "sd": 80,
            "sp": 75
        },
        "weightkg": 29.5,
        "abilities": {
            "0": "Swarm"
        },
        "otherFormes": [
            "Beedrill [Mega Beedrill]"
        ]
    },
    "Beedrill [Mega Beedrill]": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 150,
            "df": 40,
            "sa": 15,
            "sd": 80,
            "sp": 145
        },
        "weightkg": 40.5,
        "abilities": {
            "0": "Adaptability"
        },
        "baseSpecies": "Beedrill"
    },
    "Beheeyem": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 75,
            "df": 75,
            "sa": 125,
            "sd": 95,
            "sp": 40
        },
        "weightkg": 34.5,
        "abilities": {
            "0": "Analytic"
        }
    },
    "Beldum": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 80,
            "sa": 35,
            "sd": 60,
            "sp": 30
        },
        "weightkg": 95.2,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Bellibolt": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 109,
            "at": 64,
            "df": 91,
            "sa": 103,
            "sd": 83,
            "sp": 45
        },
        "weightkg": 113,
        "abilities": {
            "0": "Electromorphosis"
        }
    },
    "Bellossom": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 95,
            "sa": 90,
            "sd": 100,
            "sp": 50
        },
        "weightkg": 5.8,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Bellsprout": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 35,
            "sa": 70,
            "sd": 30,
            "sp": 40
        },
        "weightkg": 4,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Bergmite": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 55,
            "at": 69,
            "df": 85,
            "sa": 32,
            "sd": 35,
            "sp": 28
        },
        "weightkg": 99.5,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Bewear": {
        "types": [
            "Normal",
            "Fighting"
        ],
        "bs": {
            "hp": 120,
            "at": 125,
            "df": 80,
            "sa": 55,
            "sd": 60,
            "sp": 60
        },
        "weightkg": 135,
        "abilities": {
            "0": "Fluffy"
        }
    },
    "Bibarel": {
        "types": [
            "Normal",
            "Water"
        ],
        "bs": {
            "hp": 79,
            "at": 85,
            "df": 60,
            "sa": 55,
            "sd": 60,
            "sp": 71
        },
        "weightkg": 31.5,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Bidoof": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 59,
            "at": 45,
            "df": 40,
            "sa": 35,
            "sd": 40,
            "sp": 31
        },
        "weightkg": 20,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Binacle": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 42,
            "at": 52,
            "df": 67,
            "sa": 39,
            "sd": 56,
            "sp": 50
        },
        "weightkg": 31,
        "abilities": {
            "0": "Tough Claws"
        }
    },
    "Bisharp": {
        "types": [
            "Dark",
            "Steel"
        ],
        "bs": {
            "hp": 65,
            "at": 125,
            "df": 100,
            "sa": 60,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 70,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Blacephalon": {
        "types": [
            "Fire",
            "Ghost"
        ],
        "bs": {
            "hp": 53,
            "at": 127,
            "df": 53,
            "sa": 151,
            "sd": 79,
            "sp": 107
        },
        "weightkg": 13,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Blastoise": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 79,
            "at": 83,
            "df": 100,
            "sa": 85,
            "sd": 105,
            "sp": 78
        },
        "weightkg": 85.5,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Blastoise [Mega Blastoise]"
        ]
    },
    "Blastoise [Mega Blastoise]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 79,
            "at": 103,
            "df": 120,
            "sa": 135,
            "sd": 115,
            "sp": 78
        },
        "weightkg": 101.1,
        "abilities": {
            "0": "Mega Launcher"
        },
        "baseSpecies": "Blastoise"
    },
    "Blaziken": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 70,
            "sa": 110,
            "sd": 70,
            "sp": 80
        },
        "weightkg": 52,
        "abilities": {
            "0": "Blaze"
        },
        "otherFormes": [
            "Blaziken [Mega Blaziken]"
        ]
    },
    "Blaziken [Mega Blaziken]": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 160,
            "df": 80,
            "sa": 130,
            "sd": 80,
            "sp": 100
        },
        "weightkg": 52,
        "abilities": {
            "0": "Inner Focus"
        },
        "baseSpecies": "Blaziken"
    },
    "Blipbug": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 25,
            "at": 20,
            "df": 20,
            "sa": 25,
            "sd": 45,
            "sp": 45
        },
        "weightkg": 8,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Blissey": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 255,
            "at": 10,
            "df": 10,
            "sa": 75,
            "sd": 135,
            "sp": 55
        },
        "weightkg": 46.8,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Blitzle": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 45,
            "at": 60,
            "df": 32,
            "sa": 50,
            "sd": 32,
            "sp": 76
        },
        "weightkg": 29.8,
        "abilities": {
            "0": "Heatproof"
        }
    },
    "Boldore": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 105,
            "df": 105,
            "sa": 50,
            "sd": 40,
            "sp": 20
        },
        "weightkg": 102,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Boltund": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 69,
            "at": 90,
            "df": 60,
            "sa": 90,
            "sd": 60,
            "sp": 121
        },
        "weightkg": 34,
        "abilities": {
            "0": "Strong Jaw"
        }
    },
    "Bombirdier": {
        "types": [
            "Flying",
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 103,
            "df": 85,
            "sa": 60,
            "sd": 85,
            "sp": 82
        },
        "weightkg": 42.9,
        "abilities": {
            "0": "Big Pecks"
        }
    },
    "Bonsly": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 50,
            "at": 80,
            "df": 95,
            "sa": 10,
            "sd": 45,
            "sp": 10
        },
        "weightkg": 15,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Bouffalant": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 95,
            "at": 110,
            "df": 95,
            "sa": 40,
            "sd": 95,
            "sp": 55
        },
        "weightkg": 94.5,
        "abilities": {
            "0": "Reckless"
        }
    },
    "Bounsweet": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 42,
            "at": 30,
            "df": 38,
            "sa": 30,
            "sd": 38,
            "sp": 32
        },
        "weightkg": 3.2,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Braixen": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 59,
            "at": 59,
            "df": 58,
            "sa": 90,
            "sd": 70,
            "sp": 73
        },
        "weightkg": 14.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Brambleghast": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 55,
            "at": 115,
            "df": 70,
            "sa": 80,
            "sd": 70,
            "sp": 90
        },
        "weightkg": 6,
        "abilities": {
            "0": "Wind Rider"
        }
    },
    "Bramblin": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 65,
            "df": 30,
            "sa": 45,
            "sd": 35,
            "sp": 60
        },
        "weightkg": 0.6,
        "abilities": {
            "0": "Wind Rider"
        }
    },
    "Braviary": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 100,
            "at": 123,
            "df": 75,
            "sa": 57,
            "sd": 75,
            "sp": 80
        },
        "weightkg": 41,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Braviary [Hisuian]"
        ]
    },
    "Braviary [Hisuian]": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 110,
            "at": 83,
            "df": 70,
            "sa": 112,
            "sd": 70,
            "sp": 65
        },
        "weightkg": 43.4,
        "abilities": {
            "0": "Keen Eye"
        },
        "baseSpecies": "Braviary"
    },
    "Breloom": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 60,
            "at": 130,
            "df": 80,
            "sa": 60,
            "sd": 60,
            "sp": 70
        },
        "weightkg": 39.2,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Brionne": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 60,
            "at": 69,
            "df": 69,
            "sa": 91,
            "sd": 81,
            "sp": 50
        },
        "weightkg": 17.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Bronzong": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 67,
            "at": 89,
            "df": 116,
            "sa": 79,
            "sd": 116,
            "sp": 33
        },
        "weightkg": 187,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Bronzor": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 57,
            "at": 24,
            "df": 86,
            "sa": 24,
            "sd": 86,
            "sp": 23
        },
        "weightkg": 60.5,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Brute Bonnet": {
        "types": [
            "Grass",
            "Dark"
        ],
        "bs": {
            "hp": 111,
            "at": 127,
            "df": 99,
            "sa": 79,
            "sd": 99,
            "sp": 55
        },
        "weightkg": 21,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Bruxish": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 68,
            "at": 105,
            "df": 70,
            "sa": 70,
            "sd": 70,
            "sp": 92
        },
        "weightkg": 19,
        "abilities": {
            "0": "Dazzling"
        }
    },
    "Budew": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 35,
            "sa": 50,
            "sd": 70,
            "sp": 55
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Buizel": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 65,
            "df": 35,
            "sa": 60,
            "sd": 30,
            "sp": 85
        },
        "weightkg": 29.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Bulbasaur": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 45,
            "at": 49,
            "df": 49,
            "sa": 65,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 6.9,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Buneary": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 66,
            "df": 44,
            "sa": 44,
            "sd": 56,
            "sp": 85
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Bunnelby": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 38,
            "at": 36,
            "df": 38,
            "sa": 32,
            "sd": 36,
            "sp": 57
        },
        "weightkg": 5,
        "abilities": {
            "0": "Cheek Pouch"
        }
    },
    "Burmy": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 40,
            "at": 29,
            "df": 45,
            "sa": 29,
            "sd": 45,
            "sp": 36
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Shed Skin"
        },
        "otherFormes": [
            "Burmy [Sandy Cloak]",
            "Burmy [Trash Cloak]"
        ]
    },
    "Burmy [Sandy Cloak]": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 40,
            "at": 29,
            "df": 45,
            "sa": 29,
            "sd": 45,
            "sp": 36
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Shed Skin"
        },
        "baseSpecies": "Burmy"
    },
    "Burmy [Trash Cloak]": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 40,
            "at": 29,
            "df": 45,
            "sa": 29,
            "sd": 45,
            "sp": 36
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Shed Skin"
        },
        "baseSpecies": "Burmy"
    },
    "Butterfree": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 45,
            "df": 50,
            "sa": 90,
            "sd": 80,
            "sp": 70
        },
        "weightkg": 32,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Buzzwole": {
        "types": [
            "Bug",
            "Fighting"
        ],
        "bs": {
            "hp": 107,
            "at": 139,
            "df": 139,
            "sa": 53,
            "sd": 53,
            "sp": 79
        },
        "weightkg": 333.6,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Cacnea": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 85,
            "df": 40,
            "sa": 85,
            "sd": 40,
            "sp": 35
        },
        "weightkg": 51.3,
        "abilities": {
            "0": "Sand Force"
        }
    },
    "Cacturne": {
        "types": [
            "Grass",
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 115,
            "df": 60,
            "sa": 115,
            "sd": 60,
            "sp": 55
        },
        "weightkg": 77.4,
        "abilities": {
            "0": "Sand Force"
        }
    },
    "Calyrex": {
        "types": [
            "Psychic",
            "Grass"
        ],
        "bs": {
            "hp": 100,
            "at": 80,
            "df": 80,
            "sa": 80,
            "sd": 80,
            "sp": 80
        },
        "weightkg": 7.7,
        "abilities": {
            "0": "Unnerve"
        },
        "otherFormes": [
            "Calyrex [Ice Rider]",
            "Calyrex [Shadow Rider]"
        ]
    },
    "Calyrex [Ice Rider]": {
        "types": [
            "Psychic",
            "Ice"
        ],
        "bs": {
            "hp": 100,
            "at": 165,
            "df": 150,
            "sa": 85,
            "sd": 130,
            "sp": 50
        },
        "weightkg": 809.1,
        "abilities": {
            "0": "As One"
        },
        "baseSpecies": "Calyrex"
    },
    "Calyrex [Shadow Rider]": {
        "types": [
            "Psychic",
            "Ghost"
        ],
        "bs": {
            "hp": 100,
            "at": 85,
            "df": 80,
            "sa": 165,
            "sd": 100,
            "sp": 150
        },
        "weightkg": 53.6,
        "abilities": {
            "0": "As One"
        },
        "baseSpecies": "Calyrex"
    },
    "Camerupt": {
        "types": [
            "Fire",
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 100,
            "df": 70,
            "sa": 105,
            "sd": 75,
            "sp": 40
        },
        "weightkg": 220,
        "abilities": {
            "0": "Magma Armor"
        },
        "otherFormes": [
            "Camerupt [Mega Camerupt]"
        ]
    },
    "Camerupt [Mega Camerupt]": {
        "types": [
            "Fire",
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 120,
            "df": 100,
            "sa": 145,
            "sd": 105,
            "sp": 20
        },
        "weightkg": 320.5,
        "abilities": {
            "0": "Sheer Force"
        },
        "baseSpecies": "Camerupt"
    },
    "Capsakid": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 62,
            "df": 40,
            "sa": 62,
            "sd": 40,
            "sp": 50
        },
        "weightkg": 3,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Carbink": {
        "types": [
            "Rock",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 150,
            "sa": 50,
            "sd": 150,
            "sp": 50
        },
        "weightkg": 5.7,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Carkol": {
        "types": [
            "Rock",
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 60,
            "df": 90,
            "sa": 60,
            "sd": 70,
            "sp": 50
        },
        "weightkg": 78,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Carnivine": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 74,
            "at": 100,
            "df": 72,
            "sa": 90,
            "sd": 72,
            "sp": 46
        },
        "weightkg": 27,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Carracosta": {
        "types": [
            "Water",
            "Rock"
        ],
        "bs": {
            "hp": 74,
            "at": 108,
            "df": 133,
            "sa": 83,
            "sd": 65,
            "sp": 32
        },
        "weightkg": 81,
        "abilities": {
            "0": "Solid Rock"
        }
    },
    "Carvanha": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 45,
            "at": 90,
            "df": 20,
            "sa": 65,
            "sd": 20,
            "sp": 65
        },
        "weightkg": 20.8,
        "abilities": {
            "0": "Rough Skin"
        }
    },
    "Cascoon": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 35,
            "df": 55,
            "sa": 25,
            "sd": 25,
            "sp": 15
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Castform": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 70,
            "sa": 70,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 0.8,
        "abilities": {
            "0": "Forecast"
        },
        "otherFormes": [
            "Castform [Sunny Form]",
            "Castform [Rainy Form]",
            "Castform [Snowy Form]"
        ]
    },
    "Castform [Sunny Form]": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 70,
            "sa": 70,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 0.8,
        "abilities": {
            "0": "Forecast"
        },
        "baseSpecies": "Castform"
    },
    "Castform [Rainy Form]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 70,
            "sa": 70,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 0.8,
        "abilities": {
            "0": "Forecast"
        },
        "baseSpecies": "Castform"
    },
    "Castform [Snowy Form]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 70,
            "sa": 70,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 0.8,
        "abilities": {
            "0": "Forecast"
        },
        "baseSpecies": "Castform"
    },
    "Caterpie": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 35,
            "sa": 20,
            "sd": 20,
            "sp": 45
        },
        "weightkg": 2.9,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Celebi": {
        "types": [
            "Psychic",
            "Grass"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 5,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Celesteela": {
        "types": [
            "Steel",
            "Flying"
        ],
        "bs": {
            "hp": 97,
            "at": 101,
            "df": 103,
            "sa": 107,
            "sd": 101,
            "sp": 61
        },
        "weightkg": 999.9,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Centiskorch": {
        "types": [
            "Fire",
            "Bug"
        ],
        "bs": {
            "hp": 100,
            "at": 115,
            "df": 65,
            "sa": 90,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 120,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Ceruledge": {
        "types": [
            "Fire",
            "Ghost"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 80,
            "sa": 60,
            "sd": 100,
            "sp": 85
        },
        "weightkg": 62,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Cetitan": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 170,
            "at": 113,
            "df": 65,
            "sa": 45,
            "sd": 55,
            "sp": 73
        },
        "weightkg": 700,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Cetoddle": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 108,
            "at": 68,
            "df": 45,
            "sa": 30,
            "sd": 40,
            "sp": 43
        },
        "weightkg": 45,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Chandelure": {
        "types": [
            "Ghost",
            "Fire"
        ],
        "bs": {
            "hp": 60,
            "at": 55,
            "df": 90,
            "sa": 145,
            "sd": 90,
            "sp": 80
        },
        "weightkg": 34.3,
        "abilities": {
            "0": "Infiltrator"
        },
        "otherFormes": [
            "Chandelure [Mega Chandelure]"
        ]
    },
    "Chandelure [Mega Chandelure]": {
        "types": [
            "Ghost",
            "Fire"
        ],
        "bs": {
            "hp": 60,
            "at": 75,
            "df": 110,
            "sa": 175,
            "sd": 110,
            "sp": 90
        },
        "weightkg": 69.6,
        "abilities": {
            "0": "Infiltrator"
        },
        "baseSpecies": "Chandelure"
    },
    "Chansey": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 250,
            "at": 5,
            "df": 5,
            "sa": 35,
            "sd": 105,
            "sp": 50
        },
        "weightkg": 34.6,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Charcadet": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 40,
            "at": 50,
            "df": 40,
            "sa": 50,
            "sd": 40,
            "sp": 35
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Charizard": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 84,
            "df": 78,
            "sa": 109,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 90.5,
        "abilities": {
            "0": "Blaze"
        },
        "otherFormes": [
            "Charizard [Mega Charizard X]",
            "Charizard [Mega Charizard Y]"
        ]
    },
    "Charizard [Mega Charizard X]": {
        "types": [
            "Fire",
            "Dragon"
        ],
        "bs": {
            "hp": 78,
            "at": 130,
            "df": 111,
            "sa": 130,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 110.5,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Charizard"
    },
    "Charizard [Mega Charizard Y]": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 104,
            "df": 78,
            "sa": 159,
            "sd": 115,
            "sp": 100
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "Drought"
        },
        "baseSpecies": "Charizard"
    },
    "Charjabug": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 57,
            "at": 82,
            "df": 95,
            "sa": 55,
            "sd": 75,
            "sp": 36
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Battery"
        }
    },
    "Charmander": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 39,
            "at": 52,
            "df": 43,
            "sa": 60,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Charmeleon": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 58,
            "at": 64,
            "df": 58,
            "sa": 80,
            "sd": 65,
            "sp": 80
        },
        "weightkg": 19,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Chatot": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 76,
            "at": 65,
            "df": 45,
            "sa": 92,
            "sd": 42,
            "sp": 91
        },
        "weightkg": 1.9,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Cherrim": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 60,
            "df": 70,
            "sa": 87,
            "sd": 78,
            "sp": 85
        },
        "weightkg": 9.3,
        "abilities": {
            "0": "Flower Gift"
        },
        "otherFormes": [
            "Cherrim [Sunshine Form]"
        ]
    },
    "Cherrim [Sunshine Form]": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 60,
            "df": 70,
            "sa": 87,
            "sd": 78,
            "sp": 85
        },
        "weightkg": 9.3,
        "abilities": {
            "0": "Flower Gift"
        },
        "baseSpecies": "Cherrim"
    },
    "Cherubi": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 45,
            "at": 35,
            "df": 45,
            "sa": 62,
            "sd": 53,
            "sp": 35
        },
        "weightkg": 3.3,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Chesnaught": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 88,
            "at": 107,
            "df": 122,
            "sa": 74,
            "sd": 75,
            "sp": 64
        },
        "weightkg": 90,
        "abilities": {
            "0": "Overgrow"
        },
        "otherFormes": [
            "Chesnaught [Mega Chesnaught]"
        ]
    },
    "Chesnaught [Mega Chesnaught]": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 88,
            "at": 137,
            "df": 172,
            "sa": 74,
            "sd": 115,
            "sp": 44
        },
        "weightkg": 90,
        "abilities": {
            "0": "Bulletproof"
        },
        "baseSpecies": "Chesnaught"
    },
    "Chespin": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 56,
            "at": 61,
            "df": 65,
            "sa": 48,
            "sd": 45,
            "sp": 38
        },
        "weightkg": 9,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Chewtle": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 64,
            "df": 50,
            "sa": 38,
            "sd": 38,
            "sp": 44
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Strong Jaw"
        }
    },
    "Chien-Pao": {
        "types": [
            "Dark",
            "Ice"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 80,
            "sa": 90,
            "sd": 65,
            "sp": 135
        },
        "weightkg": 152.2,
        "abilities": {
            "0": "Sword of Ruin"
        }
    },
    "Chikorita": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 45,
            "at": 49,
            "df": 65,
            "sa": 49,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 6.4,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Chimchar": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 44,
            "at": 58,
            "df": 44,
            "sa": 58,
            "sd": 44,
            "sp": 61
        },
        "weightkg": 6.2,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Chimecho": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 50,
            "df": 80,
            "sa": 95,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 1,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Chimecho [Mega Chimecho]"
        ]
    },
    "Chimecho [Mega Chimecho]": {
        "types": [
            "Psychic",
            "Steel"
        ],
        "bs": {
            "hp": 75,
            "at": 50,
            "df": 110,
            "sa": 135,
            "sd": 120,
            "sp": 65
        },
        "weightkg": 8,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Chimecho"
    },
    "Chinchou": {
        "types": [
            "Water",
            "Electric"
        ],
        "bs": {
            "hp": 75,
            "at": 38,
            "df": 38,
            "sa": 56,
            "sd": 56,
            "sp": 67
        },
        "weightkg": 12,
        "abilities": {
            "0": "Volt Absorb"
        }
    },
    "Chingling": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 50,
            "sa": 65,
            "sd": 50,
            "sp": 45
        },
        "weightkg": 0.6,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Chi-Yu": {
        "types": [
            "Dark",
            "Fire"
        ],
        "bs": {
            "hp": 55,
            "at": 80,
            "df": 80,
            "sa": 135,
            "sd": 120,
            "sp": 100
        },
        "weightkg": 4.9,
        "abilities": {
            "0": "Beads of Ruin"
        }
    },
    "Cinccino": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 95,
            "df": 60,
            "sa": 65,
            "sd": 60,
            "sp": 115
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Cinderace": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 116,
            "df": 75,
            "sa": 65,
            "sd": 75,
            "sp": 119
        },
        "weightkg": 33,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Clamperl": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 35,
            "at": 64,
            "df": 85,
            "sa": 74,
            "sd": 55,
            "sp": 32
        },
        "weightkg": 52.5,
        "abilities": {
            "0": "Shell Armor"
        }
    },
    "Clauncher": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 53,
            "df": 62,
            "sa": 58,
            "sd": 63,
            "sp": 44
        },
        "weightkg": 8.3,
        "abilities": {
            "0": "Mega Launcher"
        }
    },
    "Clawitzer": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 71,
            "at": 73,
            "df": 88,
            "sa": 120,
            "sd": 89,
            "sp": 59
        },
        "weightkg": 35.3,
        "abilities": {
            "0": "Mega Launcher"
        }
    },
    "Claydol": {
        "types": [
            "Ground",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 70,
            "df": 105,
            "sa": 70,
            "sd": 120,
            "sp": 75
        },
        "weightkg": 108,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Clefable": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 95,
            "at": 70,
            "df": 73,
            "sa": 95,
            "sd": 90,
            "sp": 60
        },
        "weightkg": 40,
        "abilities": {
            "0": "Cute Charm"
        },
        "otherFormes": [
            "Clefable [Mega Clefable]"
        ]
    },
    "Clefable [Mega Clefable]": {
        "types": [
            "Fairy",
            "Flying"
        ],
        "bs": {
            "hp": 95,
            "at": 80,
            "df": 93,
            "sa": 135,
            "sd": 110,
            "sp": 70
        },
        "weightkg": 42.3,
        "abilities": {
            "0": "Magic Bounce"
        },
        "baseSpecies": "Clefable"
    },
    "Clefairy": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 45,
            "df": 48,
            "sa": 60,
            "sd": 65,
            "sp": 35
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Cleffa": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 25,
            "df": 28,
            "sa": 45,
            "sd": 55,
            "sp": 15
        },
        "weightkg": 3,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Clobbopus": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 50,
            "at": 68,
            "df": 60,
            "sa": 50,
            "sd": 50,
            "sp": 32
        },
        "weightkg": 4,
        "abilities": {
            "0": "Limber"
        }
    },
    "Clodsire": {
        "types": [
            "Poison",
            "Ground"
        ],
        "bs": {
            "hp": 130,
            "at": 75,
            "df": 60,
            "sa": 45,
            "sd": 100,
            "sp": 20
        },
        "weightkg": 223,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Cloyster": {
        "types": [
            "Water",
            "Ice"
        ],
        "bs": {
            "hp": 50,
            "at": 95,
            "df": 180,
            "sa": 85,
            "sd": 45,
            "sp": 70
        },
        "weightkg": 132.5,
        "abilities": {
            "0": "Shell Armor"
        }
    },
    "Coalossal": {
        "types": [
            "Rock",
            "Fire"
        ],
        "bs": {
            "hp": 110,
            "at": 80,
            "df": 120,
            "sa": 80,
            "sd": 90,
            "sp": 30
        },
        "weightkg": 310.5,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Cobalion": {
        "types": [
            "Steel",
            "Fighting"
        ],
        "bs": {
            "hp": 91,
            "at": 90,
            "df": 129,
            "sa": 90,
            "sd": 72,
            "sp": 108
        },
        "weightkg": 250,
        "abilities": {
            "0": "Justified"
        }
    },
    "Cofagrigus": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 58,
            "at": 50,
            "df": 145,
            "sa": 95,
            "sd": 105,
            "sp": 30
        },
        "weightkg": 76.5,
        "abilities": {
            "0": "Mummy"
        }
    },
    "Combee": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 30,
            "at": 30,
            "df": 42,
            "sa": 30,
            "sd": 42,
            "sp": 70
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Hustle"
        }
    },
    "Combusken": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 60,
            "sa": 85,
            "sd": 60,
            "sp": 55
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Comfey": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 51,
            "at": 52,
            "df": 90,
            "sa": 82,
            "sd": 110,
            "sp": 100
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Flower Veil"
        }
    },
    "Conkeldurr": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 105,
            "at": 140,
            "df": 95,
            "sa": 55,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 87,
        "abilities": {
            "0": "Guts"
        }
    },
    "Copperajah": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 122,
            "at": 130,
            "df": 69,
            "sa": 80,
            "sd": 69,
            "sp": 30
        },
        "weightkg": 650,
        "abilities": {
            "0": "Sheer Force"
        }
    },
    "Corphish": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 43,
            "at": 80,
            "df": 65,
            "sa": 50,
            "sd": 35,
            "sp": 35
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Corsola": {
        "types": [
            "Water",
            "Rock"
        ],
        "bs": {
            "hp": 65,
            "at": 55,
            "df": 95,
            "sa": 65,
            "sd": 95,
            "sp": 35
        },
        "weightkg": 5,
        "abilities": {
            "0": "Natural Cure"
        },
        "otherFormes": [
            "Corsola [Galarian]"
        ]
    },
    "Corsola [Galarian]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 55,
            "df": 100,
            "sa": 65,
            "sd": 100,
            "sp": 30
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Cursed Body"
        },
        "baseSpecies": "Corsola"
    },
    "Corviknight": {
        "types": [
            "Flying",
            "Steel"
        ],
        "bs": {
            "hp": 98,
            "at": 87,
            "df": 105,
            "sa": 53,
            "sd": 85,
            "sp": 67
        },
        "weightkg": 75,
        "abilities": {
            "0": "Unnerve"
        }
    },
    "Corvisquire": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 68,
            "at": 67,
            "df": 55,
            "sa": 43,
            "sd": 55,
            "sp": 77
        },
        "weightkg": 16,
        "abilities": {
            "0": "Unnerve"
        }
    },
    "Cosmoem": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 43,
            "at": 29,
            "df": 131,
            "sa": 29,
            "sd": 131,
            "sp": 37
        },
        "weightkg": 999.9,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Cosmog": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 43,
            "at": 29,
            "df": 31,
            "sa": 29,
            "sd": 31,
            "sp": 37
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Cottonee": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 40,
            "at": 27,
            "df": 60,
            "sa": 37,
            "sd": 50,
            "sp": 66
        },
        "weightkg": 0.6,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Crabominable": {
        "types": [
            "Fighting",
            "Ice"
        ],
        "bs": {
            "hp": 97,
            "at": 132,
            "df": 77,
            "sa": 62,
            "sd": 67,
            "sp": 43
        },
        "weightkg": 180,
        "abilities": {
            "0": "Hyper Cutter"
        },
        "otherFormes": [
            "Crabominable [Mega Crabominable]"
        ]
    },
    "Crabominable [Mega Crabominable]": {
        "types": [
            "Fighting",
            "Ice"
        ],
        "bs": {
            "hp": 97,
            "at": 157,
            "df": 122,
            "sa": 62,
            "sd": 107,
            "sp": 33
        },
        "weightkg": 252.8,
        "abilities": {
            "0": "Iron Fist"
        },
        "baseSpecies": "Crabominable"
    },
    "Crabrawler": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 47,
            "at": 82,
            "df": 57,
            "sa": 42,
            "sd": 47,
            "sp": 63
        },
        "weightkg": 7,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Cradily": {
        "types": [
            "Rock",
            "Grass"
        ],
        "bs": {
            "hp": 86,
            "at": 81,
            "df": 97,
            "sa": 81,
            "sd": 107,
            "sp": 43
        },
        "weightkg": 60.4,
        "abilities": {
            "0": "Suction Cups"
        }
    },
    "Cramorant": {
        "types": [
            "Flying",
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 55,
            "sa": 85,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 18,
        "abilities": {
            "0": "Gulp Missile"
        },
        "otherFormes": [
            "Cramorant [Gulping Form]",
            "Cramorant [Gorging Form]"
        ]
    },
    "Cramorant [Gulping Form]": {
        "types": [
            "Flying",
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 55,
            "sa": 85,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 18,
        "abilities": {
            "0": "Gulp Missile"
        },
        "baseSpecies": "Cramorant"
    },
    "Cramorant [Gorging Form]": {
        "types": [
            "Flying",
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 55,
            "sa": 85,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 18,
        "abilities": {
            "0": "Gulp Missile"
        },
        "baseSpecies": "Cramorant"
    },
    "Cranidos": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 67,
            "at": 125,
            "df": 40,
            "sa": 30,
            "sd": 30,
            "sp": 58
        },
        "weightkg": 31.5,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Crawdaunt": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 63,
            "at": 120,
            "df": 85,
            "sa": 90,
            "sd": 55,
            "sp": 55
        },
        "weightkg": 32.8,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Cresselia": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 120,
            "at": 70,
            "df": 120,
            "sa": 75,
            "sd": 130,
            "sp": 85
        },
        "weightkg": 85.6,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Croagunk": {
        "types": [
            "Poison",
            "Fighting"
        ],
        "bs": {
            "hp": 48,
            "at": 61,
            "df": 40,
            "sa": 61,
            "sd": 40,
            "sp": 50
        },
        "weightkg": 23,
        "abilities": {
            "0": "Poison Touch"
        }
    },
    "Crobat": {
        "types": [
            "Poison",
            "Flying"
        ],
        "bs": {
            "hp": 85,
            "at": 90,
            "df": 80,
            "sa": 70,
            "sd": 80,
            "sp": 130
        },
        "weightkg": 75,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Crocalor": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 81,
            "at": 55,
            "df": 78,
            "sa": 90,
            "sd": 58,
            "sp": 49
        },
        "weightkg": 30.7,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Croconaw": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 65,
            "at": 80,
            "df": 80,
            "sa": 59,
            "sd": 63,
            "sp": 58
        },
        "weightkg": 25,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Crustle": {
        "types": [
            "Bug",
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 105,
            "df": 125,
            "sa": 65,
            "sd": 75,
            "sp": 45
        },
        "weightkg": 200,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Cryogonal": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 80,
            "at": 50,
            "df": 50,
            "sa": 95,
            "sd": 135,
            "sp": 105
        },
        "weightkg": 148,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Cubchoo": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 55,
            "at": 70,
            "df": 40,
            "sa": 60,
            "sd": 40,
            "sp": 40
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Rattled"
        }
    },
    "Cubone": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 95,
            "sa": 40,
            "sd": 50,
            "sp": 35
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Rock Head"
        }
    },
    "Cufant": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 72,
            "at": 80,
            "df": 49,
            "sa": 40,
            "sd": 49,
            "sp": 40
        },
        "weightkg": 100,
        "abilities": {
            "0": "Sheer Force"
        }
    },
    "Cursola": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 95,
            "df": 50,
            "sa": 145,
            "sd": 130,
            "sp": 30
        },
        "weightkg": 0.4,
        "abilities": {
            "0": "Weak Armor"
        }
    },
    "Cutiefly": {
        "types": [
            "Bug",
            "Fairy"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 40,
            "sa": 55,
            "sd": 40,
            "sp": 84
        },
        "weightkg": 0.2,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Cyclizar": {
        "types": [
            "Dragon",
            "Normal"
        ],
        "bs": {
            "hp": 70,
            "at": 95,
            "df": 65,
            "sa": 85,
            "sd": 65,
            "sp": 121
        },
        "weightkg": 63,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Cyndaquil": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 39,
            "at": 52,
            "df": 43,
            "sa": 60,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 7.9,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Dachsbun": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 57,
            "at": 80,
            "df": 115,
            "sa": 50,
            "sd": 80,
            "sp": 95
        },
        "weightkg": 14.9,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Darkrai": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 90,
            "sa": 135,
            "sd": 90,
            "sp": 125
        },
        "weightkg": 50.5,
        "abilities": {
            "0": "Bad Dreams"
        },
        "otherFormes": [
            "Darkrai [Mega Darkrai]"
        ]
    },
    "Darkrai [Mega Darkrai]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 120,
            "df": 130,
            "sa": 165,
            "sd": 130,
            "sp": 85
        },
        "weightkg": 240,
        "abilities": {
            "0": "Bad Dreams"
        },
        "baseSpecies": "Darkrai"
    },
    "Darmanitan": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 105,
            "at": 140,
            "df": 55,
            "sa": 30,
            "sd": 55,
            "sp": 95
        },
        "weightkg": 92.9,
        "abilities": {
            "0": "Sheer Force"
        },
        "otherFormes": [
            "Darmanitan [Zen Mode]",
            "Darmanitan [Galarian Standard Mode]",
            "Darmanitan [Galarian Zen Mode]"
        ]
    },
    "Darmanitan [Zen Mode]": {
        "types": [
            "Fire",
            "Psychic"
        ],
        "bs": {
            "hp": 105,
            "at": 30,
            "df": 105,
            "sa": 140,
            "sd": 105,
            "sp": 55
        },
        "weightkg": 92.9,
        "abilities": {
            "0": "Sheer Force"
        },
        "baseSpecies": "Darmanitan"
    },
    "Darmanitan [Galarian Standard Mode]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 105,
            "at": 140,
            "df": 55,
            "sa": 30,
            "sd": 55,
            "sp": 95
        },
        "weightkg": 120,
        "abilities": {
            "0": "Sheer Force"
        },
        "baseSpecies": "Darmanitan"
    },
    "Darmanitan [Galarian Zen Mode]": {
        "types": [
            "Ice",
            "Fire"
        ],
        "bs": {
            "hp": 105,
            "at": 160,
            "df": 55,
            "sa": 30,
            "sd": 55,
            "sp": 135
        },
        "weightkg": 120,
        "abilities": {
            "0": "Gorilla Tactics"
        },
        "baseSpecies": "Darmanitan"
    },
    "Dartrix": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 75,
            "df": 75,
            "sa": 70,
            "sd": 70,
            "sp": 52
        },
        "weightkg": 16,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Darumaka": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 45,
            "sa": 15,
            "sd": 45,
            "sp": 50
        },
        "weightkg": 37.5,
        "abilities": {
            "0": "Hustle"
        },
        "otherFormes": [
            "Darumaka [Galarian]"
        ]
    },
    "Darumaka [Galarian]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 45,
            "sa": 15,
            "sd": 45,
            "sp": 50
        },
        "weightkg": 40,
        "abilities": {
            "0": "Hustle"
        },
        "baseSpecies": "Darumaka"
    },
    "Decidueye": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 78,
            "at": 107,
            "df": 75,
            "sa": 100,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 36.6,
        "abilities": {
            "0": "Overgrow"
        },
        "otherFormes": [
            "Decidueye [Hisuian]"
        ]
    },
    "Decidueye [Hisuian]": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 88,
            "at": 112,
            "df": 80,
            "sa": 95,
            "sd": 95,
            "sp": 60
        },
        "weightkg": 37,
        "abilities": {
            "0": "Overgrow"
        },
        "baseSpecies": "Decidueye"
    },
    "Dedenne": {
        "types": [
            "Electric",
            "Fairy"
        ],
        "bs": {
            "hp": 67,
            "at": 58,
            "df": 57,
            "sa": 81,
            "sd": 67,
            "sp": 101
        },
        "weightkg": 2.2,
        "abilities": {
            "0": "Cheek Pouch"
        }
    },
    "Deerling": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Deerling [Summer Form]",
            "Deerling [Autumn Form]",
            "Deerling [Winter Form]"
        ]
    },
    "Deerling [Summer Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Deerling"
    },
    "Deerling [Autumn Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Deerling"
    },
    "Deerling [Winter Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Deerling"
    },
    "Deino": {
        "types": [
            "Dark",
            "Dragon"
        ],
        "bs": {
            "hp": 52,
            "at": 65,
            "df": 50,
            "sa": 45,
            "sd": 50,
            "sp": 38
        },
        "weightkg": 17.3,
        "abilities": {
            "0": "Hustle"
        }
    },
    "Delcatty": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 65,
            "df": 65,
            "sa": 55,
            "sd": 55,
            "sp": 90
        },
        "weightkg": 32.6,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Delibird": {
        "types": [
            "Ice",
            "Flying"
        ],
        "bs": {
            "hp": 45,
            "at": 55,
            "df": 45,
            "sa": 65,
            "sd": 45,
            "sp": 75
        },
        "weightkg": 16,
        "abilities": {
            "0": "Sniper"
        }
    },
    "Delphox": {
        "types": [
            "Fire",
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 69,
            "df": 72,
            "sa": 114,
            "sd": 100,
            "sp": 104
        },
        "weightkg": 39,
        "abilities": {
            "0": "Blaze"
        },
        "otherFormes": [
            "Delphox [Mega Delphox]"
        ]
    },
    "Delphox [Mega Delphox]": {
        "types": [
            "Fire",
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 69,
            "df": 72,
            "sa": 159,
            "sd": 125,
            "sp": 134
        },
        "weightkg": 39,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Delphox"
    },
    "Deoxys": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 150,
            "df": 50,
            "sa": 150,
            "sd": 50,
            "sp": 150
        },
        "weightkg": 60.8,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Deoxys [Attack Forme]",
            "Deoxys [Defense Forme]",
            "Deoxys [Speed Forme]"
        ]
    },
    "Deoxys [Attack Forme]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 180,
            "df": 20,
            "sa": 180,
            "sd": 20,
            "sp": 150
        },
        "weightkg": 60.8,
        "abilities": {
            "0": "Pressure"
        },
        "baseSpecies": "Deoxys"
    },
    "Deoxys [Defense Forme]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 70,
            "df": 160,
            "sa": 70,
            "sd": 160,
            "sp": 90
        },
        "weightkg": 60.8,
        "abilities": {
            "0": "Pressure"
        },
        "baseSpecies": "Deoxys"
    },
    "Deoxys [Speed Forme]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 95,
            "df": 90,
            "sa": 95,
            "sd": 90,
            "sp": 180
        },
        "weightkg": 60.8,
        "abilities": {
            "0": "Pressure"
        },
        "baseSpecies": "Deoxys"
    },
    "Dewgong": {
        "types": [
            "Water",
            "Ice"
        ],
        "bs": {
            "hp": 90,
            "at": 70,
            "df": 80,
            "sa": 70,
            "sd": 95,
            "sp": 70
        },
        "weightkg": 120,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Dewott": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 75,
            "df": 60,
            "sa": 83,
            "sd": 60,
            "sp": 60
        },
        "weightkg": 24.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Dewpider": {
        "types": [
            "Water",
            "Bug"
        ],
        "bs": {
            "hp": 38,
            "at": 40,
            "df": 52,
            "sa": 40,
            "sd": 72,
            "sp": 27
        },
        "weightkg": 4,
        "abilities": {
            "0": "Water Bubble"
        }
    },
    "Dhelmise": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 131,
            "df": 100,
            "sa": 86,
            "sd": 90,
            "sp": 40
        },
        "weightkg": 210,
        "abilities": {
            "0": "Steelworker"
        }
    },
    "Dialga": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 100,
            "at": 120,
            "df": 120,
            "sa": 150,
            "sd": 100,
            "sp": 90
        },
        "weightkg": 683,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Dialga [Origin Forme]"
        ]
    },
    "Dialga [Origin Forme]": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 120,
            "sa": 150,
            "sd": 120,
            "sp": 90
        },
        "weightkg": 848.7,
        "abilities": {
            "0": "Pressure"
        },
        "baseSpecies": "Dialga"
    },
    "Diancie": {
        "types": [
            "Rock",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 100,
            "df": 150,
            "sa": 100,
            "sd": 150,
            "sp": 50
        },
        "weightkg": 8.8,
        "abilities": {
            "0": "Clear Body"
        },
        "otherFormes": [
            "Diancie [Mega Diancie]"
        ]
    },
    "Diancie [Mega Diancie]": {
        "types": [
            "Rock",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 160,
            "df": 110,
            "sa": 160,
            "sd": 110,
            "sp": 110
        },
        "weightkg": 27.8,
        "abilities": {
            "0": "Magic Bounce"
        },
        "baseSpecies": "Diancie"
    },
    "Diggersby": {
        "types": [
            "Normal",
            "Ground"
        ],
        "bs": {
            "hp": 85,
            "at": 71,
            "df": 77,
            "sa": 50,
            "sd": 77,
            "sp": 78
        },
        "weightkg": 42.4,
        "abilities": {
            "0": "Huge Power"
        }
    },
    "Diglett": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 10,
            "at": 55,
            "df": 25,
            "sa": 35,
            "sd": 45,
            "sp": 95
        },
        "weightkg": 0.8,
        "abilities": {
            "0": "Arena Trap"
        },
        "otherFormes": [
            "Diglett [Alolan]"
        ]
    },
    "Diglett [Alolan]": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 10,
            "at": 55,
            "df": 30,
            "sa": 35,
            "sd": 45,
            "sp": 90
        },
        "weightkg": 1,
        "abilities": {
            "0": "Sand Force"
        },
        "baseSpecies": "Diglett"
    },
    "Dipplin": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 110,
            "sa": 95,
            "sd": 90,
            "sp": 40
        },
        "weightkg": 4.4,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Ditto": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 48,
            "at": 48,
            "df": 48,
            "sa": 48,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 4,
        "abilities": {
            "0": "Limber"
        }
    },
    "Dodrio": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 110,
            "df": 70,
            "sa": 60,
            "sd": 60,
            "sp": 110
        },
        "weightkg": 85.2,
        "abilities": {
            "0": "Tangled Feet"
        }
    },
    "Doduo": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 35,
            "at": 85,
            "df": 45,
            "sa": 35,
            "sd": 35,
            "sp": 75
        },
        "weightkg": 39.2,
        "abilities": {
            "0": "Tangled Feet"
        }
    },
    "Dolliv": {
        "types": [
            "Grass",
            "Normal"
        ],
        "bs": {
            "hp": 52,
            "at": 53,
            "df": 60,
            "sa": 78,
            "sd": 78,
            "sp": 33
        },
        "weightkg": 11.9,
        "abilities": {
            "0": "Early Bird"
        }
    },
    "Dondozo": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 150,
            "at": 100,
            "df": 115,
            "sa": 65,
            "sd": 65,
            "sp": 35
        },
        "weightkg": 220,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Donphan": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 90,
            "at": 120,
            "df": 120,
            "sa": 60,
            "sd": 60,
            "sp": 50
        },
        "weightkg": 120,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Dottler": {
        "types": [
            "Bug",
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 35,
            "df": 80,
            "sa": 50,
            "sd": 90,
            "sp": 30
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Doublade": {
        "types": [
            "Steel",
            "Ghost"
        ],
        "bs": {
            "hp": 59,
            "at": 110,
            "df": 150,
            "sa": 45,
            "sd": 49,
            "sp": 35
        },
        "weightkg": 4.5,
        "abilities": {
            "0": "No Guard"
        }
    },
    "Dracovish": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 90,
            "df": 100,
            "sa": 70,
            "sd": 80,
            "sp": 75
        },
        "weightkg": 215,
        "abilities": {
            "0": "Sand Rush"
        }
    },
    "Dracozolt": {
        "types": [
            "Electric",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 90,
            "sa": 80,
            "sd": 70,
            "sp": 75
        },
        "weightkg": 190,
        "abilities": {
            "0": "Sand Rush"
        }
    },
    "Dragalge": {
        "types": [
            "Poison",
            "Dragon"
        ],
        "bs": {
            "hp": 65,
            "at": 75,
            "df": 90,
            "sa": 97,
            "sd": 123,
            "sp": 44
        },
        "weightkg": 81.5,
        "abilities": {
            "0": "Poison Point"
        },
        "otherFormes": [
            "Dragalge [Mega Dragalge]"
        ]
    },
    "Dragalge [Mega Dragalge]": {
        "types": [
            "Poison",
            "Dragon"
        ],
        "bs": {
            "hp": 65,
            "at": 85,
            "df": 105,
            "sa": 132,
            "sd": 163,
            "sp": 44
        },
        "weightkg": 100.3,
        "abilities": {
            "0": "Regenerator"
        },
        "baseSpecies": "Dragalge"
    },
    "Dragapult": {
        "types": [
            "Dragon",
            "Ghost"
        ],
        "bs": {
            "hp": 88,
            "at": 120,
            "df": 75,
            "sa": 100,
            "sd": 75,
            "sp": 142
        },
        "weightkg": 50,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Dragonair": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 61,
            "at": 84,
            "df": 65,
            "sa": 70,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 16.5,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Dragonite": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 91,
            "at": 134,
            "df": 95,
            "sa": 100,
            "sd": 100,
            "sp": 80
        },
        "weightkg": 210,
        "abilities": {
            "0": "Inner Focus"
        },
        "otherFormes": [
            "Dragonite [Mega Dragonite]"
        ]
    },
    "Dragonite [Mega Dragonite]": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 91,
            "at": 124,
            "df": 115,
            "sa": 145,
            "sd": 125,
            "sp": 100
        },
        "weightkg": 290,
        "abilities": {
            "0": "Multiscale"
        },
        "baseSpecies": "Dragonite"
    },
    "Drakloak": {
        "types": [
            "Dragon",
            "Ghost"
        ],
        "bs": {
            "hp": 68,
            "at": 80,
            "df": 50,
            "sa": 60,
            "sd": 50,
            "sp": 102
        },
        "weightkg": 11,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Drampa": {
        "types": [
            "Normal",
            "Dragon"
        ],
        "bs": {
            "hp": 78,
            "at": 60,
            "df": 85,
            "sa": 135,
            "sd": 91,
            "sp": 36
        },
        "weightkg": 185,
        "abilities": {
            "0": "Cloud Nine"
        },
        "otherFormes": [
            "Drampa [Mega Drampa]"
        ]
    },
    "Drampa [Mega Drampa]": {
        "types": [
            "Normal",
            "Dragon"
        ],
        "bs": {
            "hp": 78,
            "at": 85,
            "df": 110,
            "sa": 160,
            "sd": 116,
            "sp": 36
        },
        "weightkg": 240.5,
        "abilities": {
            "0": "Berserk"
        },
        "baseSpecies": "Drampa"
    },
    "Drapion": {
        "types": [
            "Poison",
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 110,
            "sa": 60,
            "sd": 75,
            "sp": 95
        },
        "weightkg": 61.5,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Dratini": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 41,
            "at": 64,
            "df": 45,
            "sa": 50,
            "sd": 50,
            "sp": 50
        },
        "weightkg": 3.3,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Drednaw": {
        "types": [
            "Water",
            "Rock"
        ],
        "bs": {
            "hp": 90,
            "at": 115,
            "df": 90,
            "sa": 48,
            "sd": 68,
            "sp": 74
        },
        "weightkg": 115.5,
        "abilities": {
            "0": "Strong Jaw"
        }
    },
    "Dreepy": {
        "types": [
            "Dragon",
            "Ghost"
        ],
        "bs": {
            "hp": 28,
            "at": 60,
            "df": 30,
            "sa": 40,
            "sd": 30,
            "sp": 82
        },
        "weightkg": 2,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Drifblim": {
        "types": [
            "Ghost",
            "Flying"
        ],
        "bs": {
            "hp": 150,
            "at": 80,
            "df": 44,
            "sa": 90,
            "sd": 54,
            "sp": 80
        },
        "weightkg": 15,
        "abilities": {
            "0": "Aftermath"
        }
    },
    "Drifloon": {
        "types": [
            "Ghost",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 50,
            "df": 34,
            "sa": 60,
            "sd": 44,
            "sp": 70
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Aftermath"
        }
    },
    "Drilbur": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 40,
            "sa": 30,
            "sd": 45,
            "sp": 68
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Drizzile": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 55,
            "sa": 95,
            "sd": 55,
            "sp": 90
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Drowzee": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 48,
            "df": 45,
            "sa": 43,
            "sd": 90,
            "sp": 42
        },
        "weightkg": 32.4,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Druddigon": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 77,
            "at": 120,
            "df": 90,
            "sa": 60,
            "sd": 90,
            "sp": 48
        },
        "weightkg": 139,
        "abilities": {
            "0": "Rough Skin"
        }
    },
    "Dubwool": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 72,
            "at": 80,
            "df": 100,
            "sa": 60,
            "sd": 90,
            "sp": 88
        },
        "weightkg": 43,
        "abilities": {
            "0": "Fluffy"
        }
    },
    "Ducklett": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 62,
            "at": 44,
            "df": 50,
            "sa": 44,
            "sd": 50,
            "sp": 55
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Dudunsparce": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 125,
            "at": 100,
            "df": 80,
            "sa": 85,
            "sd": 75,
            "sp": 55
        },
        "weightkg": 39.2,
        "abilities": {
            "0": "Serene Grace"
        },
        "otherFormes": [
            "Dudunsparce [Three-Segment Form]"
        ]
    },
    "Dudunsparce [Three-Segment Form]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 125,
            "at": 100,
            "df": 80,
            "sa": 85,
            "sd": 75,
            "sp": 55
        },
        "weightkg": 47.4,
        "abilities": {
            "0": "Serene Grace"
        },
        "baseSpecies": "Dudunsparce"
    },
    "Dugtrio": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 35,
            "at": 100,
            "df": 50,
            "sa": 50,
            "sd": 70,
            "sp": 120
        },
        "weightkg": 33.3,
        "abilities": {
            "0": "Arena Trap"
        },
        "otherFormes": [
            "Dugtrio [Alolan]"
        ]
    },
    "Dugtrio [Alolan]": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 35,
            "at": 100,
            "df": 60,
            "sa": 50,
            "sd": 70,
            "sp": 110
        },
        "weightkg": 66.6,
        "abilities": {
            "0": "Sand Force"
        },
        "baseSpecies": "Dugtrio"
    },
    "Dunsparce": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 100,
            "at": 70,
            "df": 70,
            "sa": 65,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 14,
        "abilities": {
            "0": "Serene Grace"
        }
    },
    "Duosion": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 65,
            "at": 40,
            "df": 50,
            "sa": 125,
            "sd": 60,
            "sp": 30
        },
        "weightkg": 8,
        "abilities": {
            "0": "Magic Guard"
        }
    },
    "Duraludon": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 70,
            "at": 95,
            "df": 115,
            "sa": 120,
            "sd": 50,
            "sp": 85
        },
        "weightkg": 40,
        "abilities": {
            "0": "Light Metal"
        }
    },
    "Durant": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 58,
            "at": 109,
            "df": 112,
            "sa": 48,
            "sd": 48,
            "sp": 109
        },
        "weightkg": 33,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Dusclops": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 70,
            "df": 130,
            "sa": 60,
            "sd": 130,
            "sp": 25
        },
        "weightkg": 30.6,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Dusknoir": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 45,
            "at": 100,
            "df": 135,
            "sa": 65,
            "sd": 135,
            "sp": 45
        },
        "weightkg": 106.6,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Duskull": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 20,
            "at": 40,
            "df": 90,
            "sa": 30,
            "sd": 90,
            "sp": 25
        },
        "weightkg": 15,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Dustox": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 70,
            "sa": 50,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 31.6,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Dwebble": {
        "types": [
            "Bug",
            "Rock"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 85,
            "sa": 35,
            "sd": 35,
            "sp": 55
        },
        "weightkg": 14.5,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Eelektrik": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 65,
            "at": 85,
            "df": 70,
            "sa": 75,
            "sd": 70,
            "sp": 40
        },
        "weightkg": 22,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Eelektross": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 85,
            "at": 115,
            "df": 80,
            "sa": 105,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 80.5,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Eelektross [Mega Eelektross]"
        ]
    },
    "Eelektross [Mega Eelektross]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 85,
            "at": 145,
            "df": 80,
            "sa": 135,
            "sd": 90,
            "sp": 80
        },
        "weightkg": 180,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Eelektross"
    },
    "Eevee": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 50,
            "sa": 45,
            "sd": 65,
            "sp": 55
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Adaptability"
        }
    },
    "Eiscue": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 110,
            "sa": 65,
            "sd": 90,
            "sp": 50
        },
        "weightkg": 89,
        "abilities": {
            "0": "Ice Face"
        },
        "otherFormes": [
            "Eiscue [Noice Face]"
        ]
    },
    "Eiscue [Noice Face]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 70,
            "sa": 65,
            "sd": 50,
            "sp": 130
        },
        "weightkg": 89,
        "abilities": {
            "0": "Ice Face"
        },
        "baseSpecies": "Eiscue"
    },
    "Ekans": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 35,
            "at": 60,
            "df": 44,
            "sa": 40,
            "sd": 54,
            "sp": 55
        },
        "weightkg": 6.9,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Eldegoss": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 90,
            "sa": 80,
            "sd": 120,
            "sp": 60
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Cotton Down"
        }
    },
    "Electabuzz": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 65,
            "at": 83,
            "df": 57,
            "sa": 95,
            "sd": 85,
            "sp": 105
        },
        "weightkg": 30,
        "abilities": {
            "0": "Static"
        }
    },
    "Electivire": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 75,
            "at": 123,
            "df": 67,
            "sa": 95,
            "sd": 85,
            "sp": 95
        },
        "weightkg": 138.6,
        "abilities": {
            "0": "Static"
        }
    },
    "Electrike": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 40,
            "sa": 65,
            "sd": 40,
            "sp": 65
        },
        "weightkg": 15.2,
        "abilities": {
            "0": "Static"
        }
    },
    "Electrode": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 70,
            "sa": 80,
            "sd": 80,
            "sp": 150
        },
        "weightkg": 66.6,
        "abilities": {
            "0": "Aftermath"
        },
        "otherFormes": [
            "Electrode [Hisuian]"
        ]
    },
    "Electrode [Hisuian]": {
        "types": [
            "Electric",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 70,
            "sa": 80,
            "sd": 80,
            "sp": 150
        },
        "weightkg": 71,
        "abilities": {
            "0": "Aftermath"
        },
        "baseSpecies": "Electrode"
    },
    "Elekid": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 45,
            "at": 63,
            "df": 37,
            "sa": 65,
            "sd": 55,
            "sp": 95
        },
        "weightkg": 23.5,
        "abilities": {
            "0": "Static"
        }
    },
    "Elgyem": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 55,
            "sa": 85,
            "sd": 55,
            "sp": 30
        },
        "weightkg": 9,
        "abilities": {
            "0": "Analytic"
        }
    },
    "Emboar": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 110,
            "at": 123,
            "df": 65,
            "sa": 100,
            "sd": 65,
            "sp": 65
        },
        "weightkg": 150,
        "abilities": {
            "0": "Blaze"
        },
        "otherFormes": [
            "Emboar [Mega Emboar]"
        ]
    },
    "Emboar [Mega Emboar]": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 110,
            "at": 148,
            "df": 75,
            "sa": 110,
            "sd": 110,
            "sp": 75
        },
        "weightkg": 180.3,
        "abilities": {
            "0": "Mold Breaker"
        },
        "baseSpecies": "Emboar"
    },
    "Emolga": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 75,
            "df": 60,
            "sa": 75,
            "sd": 60,
            "sp": 103
        },
        "weightkg": 5,
        "abilities": {
            "0": "Static"
        }
    },
    "Empoleon": {
        "types": [
            "Water",
            "Steel"
        ],
        "bs": {
            "hp": 84,
            "at": 86,
            "df": 88,
            "sa": 111,
            "sd": 101,
            "sp": 60
        },
        "weightkg": 84.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Enamorus": {
        "types": [
            "Fairy",
            "Flying"
        ],
        "bs": {
            "hp": 74,
            "at": 115,
            "df": 70,
            "sa": 135,
            "sd": 80,
            "sp": 106
        },
        "weightkg": 48,
        "abilities": {
            "0": "Cute Charm"
        },
        "otherFormes": [
            "Enamorus [Therian Form]"
        ]
    },
    "Enamorus [Therian Form]": {
        "types": [
            "Fairy",
            "Flying"
        ],
        "bs": {
            "hp": 74,
            "at": 115,
            "df": 110,
            "sa": 135,
            "sd": 100,
            "sp": 46
        },
        "weightkg": 48,
        "abilities": {
            "0": "Overcoat"
        },
        "baseSpecies": "Enamorus"
    },
    "Entei": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 115,
            "at": 115,
            "df": 85,
            "sa": 90,
            "sd": 75,
            "sp": 100
        },
        "weightkg": 198,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Escavalier": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 135,
            "df": 105,
            "sa": 60,
            "sd": 105,
            "sp": 20
        },
        "weightkg": 33,
        "abilities": {
            "0": "Overcoat"
        }
    },
    "Espathra": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 60,
            "df": 60,
            "sa": 101,
            "sd": 60,
            "sp": 105
        },
        "weightkg": 90,
        "abilities": {
            "0": "Speed Boost"
        }
    },
    "Espeon": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 65,
            "at": 65,
            "df": 60,
            "sa": 130,
            "sd": 95,
            "sp": 110
        },
        "weightkg": 26.5,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Espurr": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 62,
            "at": 48,
            "df": 54,
            "sa": 63,
            "sd": 60,
            "sp": 68
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Eternatus": {
        "types": [
            "Poison",
            "Dragon"
        ],
        "bs": {
            "hp": 140,
            "at": 85,
            "df": 95,
            "sa": 145,
            "sd": 95,
            "sp": 130
        },
        "weightkg": 950,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Excadrill": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 110,
            "at": 135,
            "df": 60,
            "sa": 50,
            "sd": 65,
            "sp": 88
        },
        "weightkg": 40.4,
        "abilities": {
            "0": "Mold Breaker"
        },
        "otherFormes": [
            "Excadrill [Mega Excadrill]"
        ]
    },
    "Excadrill [Mega Excadrill]": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 110,
            "at": 165,
            "df": 100,
            "sa": 65,
            "sd": 65,
            "sp": 103
        },
        "weightkg": 60,
        "abilities": {
            "0": "Piercing Drill"
        },
        "baseSpecies": "Excadrill"
    },
    "Exeggcute": {
        "types": [
            "Grass",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 40,
            "df": 80,
            "sa": 60,
            "sd": 45,
            "sp": 40
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Exeggutor": {
        "types": [
            "Grass",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 85,
            "sa": 125,
            "sd": 75,
            "sp": 55
        },
        "weightkg": 120,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Exeggutor [Alolan]"
        ]
    },
    "Exeggutor [Alolan]": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 95,
            "at": 105,
            "df": 85,
            "sa": 125,
            "sd": 75,
            "sp": 45
        },
        "weightkg": 415.6,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Exeggutor"
    },
    "Exploud": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 104,
            "at": 91,
            "df": 63,
            "sa": 91,
            "sd": 73,
            "sp": 68
        },
        "weightkg": 84,
        "abilities": {
            "0": "Soundproof"
        }
    },
    "Falinks": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 100,
            "df": 100,
            "sa": 70,
            "sd": 60,
            "sp": 75
        },
        "weightkg": 62,
        "abilities": {
            "0": "Battle Armor"
        },
        "otherFormes": [
            "Falinks [Mega Falinks]"
        ]
    },
    "Falinks [Mega Falinks]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 135,
            "df": 135,
            "sa": 70,
            "sd": 65,
            "sp": 100
        },
        "weightkg": 99,
        "abilities": {
            "0": "Defiant"
        },
        "baseSpecies": "Falinks"
    },
    "Farfetch'd": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 52,
            "at": 90,
            "df": 55,
            "sa": 58,
            "sd": 62,
            "sp": 60
        },
        "weightkg": 15,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Farfetch'd [Galarian]"
        ]
    },
    "Farfetch'd [Galarian]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 52,
            "at": 95,
            "df": 55,
            "sa": 58,
            "sd": 62,
            "sp": 55
        },
        "weightkg": 42,
        "abilities": {
            "0": "Scrappy"
        },
        "baseSpecies": "Farfetch'd"
    },
    "Farigiraf": {
        "types": [
            "Normal",
            "Psychic"
        ],
        "bs": {
            "hp": 120,
            "at": 90,
            "df": 70,
            "sa": 110,
            "sd": 70,
            "sp": 60
        },
        "weightkg": 160,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Fearow": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 65,
            "sa": 61,
            "sd": 61,
            "sp": 100
        },
        "weightkg": 38,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Feebas": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 20,
            "at": 15,
            "df": 20,
            "sa": 10,
            "sd": 55,
            "sp": 80
        },
        "weightkg": 7.4,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Fennekin": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 40,
            "sa": 62,
            "sd": 60,
            "sp": 60
        },
        "weightkg": 9.4,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Feraligatr": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 85,
            "at": 105,
            "df": 100,
            "sa": 79,
            "sd": 83,
            "sp": 78
        },
        "weightkg": 88.8,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Feraligatr [Mega Feraligatr]"
        ]
    },
    "Feraligatr [Mega Feraligatr]": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 85,
            "at": 160,
            "df": 125,
            "sa": 89,
            "sd": 93,
            "sp": 78
        },
        "weightkg": 108.8,
        "abilities": {
            "0": "Dragonize"
        },
        "baseSpecies": "Feraligatr"
    },
    "Ferroseed": {
        "types": [
            "Grass",
            "Steel"
        ],
        "bs": {
            "hp": 44,
            "at": 50,
            "df": 91,
            "sa": 24,
            "sd": 86,
            "sp": 10
        },
        "weightkg": 18.8,
        "abilities": {
            "0": "Iron Barbs"
        }
    },
    "Ferrothorn": {
        "types": [
            "Grass",
            "Steel"
        ],
        "bs": {
            "hp": 74,
            "at": 94,
            "df": 131,
            "sa": 54,
            "sd": 116,
            "sp": 20
        },
        "weightkg": 110,
        "abilities": {
            "0": "Iron Barbs"
        }
    },
    "Fezandipiti": {
        "types": [
            "Poison",
            "Fairy"
        ],
        "bs": {
            "hp": 88,
            "at": 91,
            "df": 82,
            "sa": 70,
            "sd": 125,
            "sp": 99
        },
        "weightkg": 30.1,
        "abilities": {
            "0": "Toxic Chain"
        }
    },
    "Fidough": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 37,
            "at": 55,
            "df": 70,
            "sa": 30,
            "sd": 55,
            "sp": 65
        },
        "weightkg": 10.9,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Finizen": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 45,
            "df": 40,
            "sa": 45,
            "sd": 40,
            "sp": 75
        },
        "weightkg": 60.2,
        "abilities": {
            "0": "Water Veil"
        }
    },
    "Finneon": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 49,
            "at": 49,
            "df": 56,
            "sa": 49,
            "sd": 61,
            "sp": 66
        },
        "weightkg": 7,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Flaaffy": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 70,
            "at": 55,
            "df": 55,
            "sa": 80,
            "sd": 60,
            "sp": 45
        },
        "weightkg": 13.3,
        "abilities": {
            "0": "Static"
        }
    },
    "Flabébé": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 39,
            "sa": 61,
            "sd": 79,
            "sp": 42
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Flower Veil"
        },
        "otherFormes": [
            "Flabébé [Yellow Flower]",
            "Flabébé [Orange Flower]",
            "Flabébé [Blue Flower]",
            "Flabébé [White Flower]"
        ]
    },
    "Flabébé [Yellow Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 39,
            "sa": 61,
            "sd": 79,
            "sp": 42
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Flabébé"
    },
    "Flabébé [Orange Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 39,
            "sa": 61,
            "sd": 79,
            "sp": 42
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Flabébé"
    },
    "Flabébé [Blue Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 39,
            "sa": 61,
            "sd": 79,
            "sp": 42
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Flabébé"
    },
    "Flabébé [White Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 39,
            "sa": 61,
            "sd": 79,
            "sp": 42
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Flabébé"
    },
    "Flamigo": {
        "types": [
            "Flying",
            "Fighting"
        ],
        "bs": {
            "hp": 82,
            "at": 115,
            "df": 74,
            "sa": 75,
            "sd": 64,
            "sp": 90
        },
        "weightkg": 37,
        "abilities": {
            "0": "Scrappy"
        }
    },
    "Flapple": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 80,
            "sa": 95,
            "sd": 60,
            "sp": 70
        },
        "weightkg": 1,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Flareon": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 130,
            "df": 60,
            "sa": 95,
            "sd": 110,
            "sp": 65
        },
        "weightkg": 25,
        "abilities": {
            "0": "Guts"
        }
    },
    "Fletchinder": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 62,
            "at": 73,
            "df": 55,
            "sa": 56,
            "sd": 52,
            "sp": 84
        },
        "weightkg": 16,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Fletchling": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 45,
            "at": 50,
            "df": 43,
            "sa": 40,
            "sd": 38,
            "sp": 62
        },
        "weightkg": 1.7,
        "abilities": {
            "0": "Big Pecks"
        }
    },
    "Flittle": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 30,
            "at": 35,
            "df": 30,
            "sa": 55,
            "sd": 30,
            "sp": 75
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Speed Boost"
        }
    },
    "Floatzel": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 85,
            "at": 105,
            "df": 55,
            "sa": 85,
            "sd": 50,
            "sp": 115
        },
        "weightkg": 33.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Floette": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 47,
            "sa": 75,
            "sd": 98,
            "sp": 52
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "otherFormes": [
            "Floette [Yellow Flower]",
            "Floette [Orange Flower]",
            "Floette [Blue Flower]",
            "Floette [White Flower]",
            "Floette [Eternal Flower]",
            "Floette [Mega Floette]"
        ]
    },
    "Floette [Yellow Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 47,
            "sa": 75,
            "sd": 98,
            "sp": 52
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floette [Orange Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 47,
            "sa": 75,
            "sd": 98,
            "sp": 52
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floette [Blue Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 47,
            "sa": 75,
            "sd": 98,
            "sp": 52
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floette [White Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 47,
            "sa": 75,
            "sd": 98,
            "sp": 52
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floette [Eternal Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 74,
            "at": 65,
            "df": 67,
            "sa": 125,
            "sd": 128,
            "sp": 92
        },
        "weightkg": 0.9,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floette [Mega Floette]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 74,
            "at": 85,
            "df": 87,
            "sa": 155,
            "sd": 148,
            "sp": 102
        },
        "weightkg": 100.8,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Floette"
    },
    "Floragato": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 61,
            "at": 80,
            "df": 63,
            "sa": 60,
            "sd": 63,
            "sp": 83
        },
        "weightkg": 12.2,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Florges": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 65,
            "df": 68,
            "sa": 112,
            "sd": 154,
            "sp": 75
        },
        "weightkg": 10,
        "abilities": {
            "0": "Flower Veil"
        },
        "otherFormes": [
            "Florges [Yellow Flower]",
            "Florges [Orange Flower]",
            "Florges [Blue Flower]",
            "Florges [White Flower]"
        ]
    },
    "Florges [Yellow Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 65,
            "df": 68,
            "sa": 112,
            "sd": 154,
            "sp": 75
        },
        "weightkg": 10,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Florges"
    },
    "Florges [Orange Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 65,
            "df": 68,
            "sa": 112,
            "sd": 154,
            "sp": 75
        },
        "weightkg": 10,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Florges"
    },
    "Florges [Blue Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 65,
            "df": 68,
            "sa": 112,
            "sd": 154,
            "sp": 75
        },
        "weightkg": 10,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Florges"
    },
    "Florges [White Flower]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 65,
            "df": 68,
            "sa": 112,
            "sd": 154,
            "sp": 75
        },
        "weightkg": 10,
        "abilities": {
            "0": "Flower Veil"
        },
        "baseSpecies": "Florges"
    },
    "Flutter Mane": {
        "types": [
            "Ghost",
            "Fairy"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 55,
            "sa": 135,
            "sd": 135,
            "sp": 135
        },
        "weightkg": 4,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Flygon": {
        "types": [
            "Ground",
            "Dragon"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 80,
            "sa": 80,
            "sd": 80,
            "sp": 100
        },
        "weightkg": 82,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Fomantis": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 35,
            "sa": 50,
            "sd": 35,
            "sp": 35
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Leaf Guard"
        }
    },
    "Foongus": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 69,
            "at": 55,
            "df": 45,
            "sa": 55,
            "sd": 55,
            "sp": 15
        },
        "weightkg": 1,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Forretress": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 75,
            "at": 90,
            "df": 140,
            "sa": 60,
            "sd": 60,
            "sp": 40
        },
        "weightkg": 125.8,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Fraxure": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 66,
            "at": 117,
            "df": 70,
            "sa": 40,
            "sd": 50,
            "sp": 67
        },
        "weightkg": 36,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Frigibax": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 65,
            "at": 75,
            "df": 45,
            "sa": 35,
            "sd": 45,
            "sp": 55
        },
        "weightkg": 17,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Frillish": {
        "types": [
            "Water",
            "Ghost"
        ],
        "bs": {
            "hp": 55,
            "at": 40,
            "df": 50,
            "sa": 65,
            "sd": 85,
            "sp": 40
        },
        "weightkg": 33,
        "abilities": {
            "0": "Damp"
        }
    },
    "Froakie": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 41,
            "at": 56,
            "df": 40,
            "sa": 62,
            "sd": 44,
            "sp": 71
        },
        "weightkg": 7,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Frogadier": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 54,
            "at": 63,
            "df": 52,
            "sa": 83,
            "sd": 56,
            "sp": 97
        },
        "weightkg": 10.9,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Froslass": {
        "types": [
            "Ice",
            "Ghost"
        ],
        "bs": {
            "hp": 70,
            "at": 80,
            "df": 70,
            "sa": 80,
            "sd": 70,
            "sp": 110
        },
        "weightkg": 26.6,
        "abilities": {
            "0": "Cursed Body"
        },
        "otherFormes": [
            "Froslass [Mega Froslass]"
        ]
    },
    "Froslass [Mega Froslass]": {
        "types": [
            "Ice",
            "Ghost"
        ],
        "bs": {
            "hp": 70,
            "at": 80,
            "df": 70,
            "sa": 140,
            "sd": 100,
            "sp": 120
        },
        "weightkg": 29.6,
        "abilities": {
            "0": "Cursed Body"
        },
        "baseSpecies": "Froslass"
    },
    "Frosmoth": {
        "types": [
            "Ice",
            "Bug"
        ],
        "bs": {
            "hp": 70,
            "at": 65,
            "df": 60,
            "sa": 125,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 42,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Fuecoco": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 67,
            "at": 45,
            "df": 59,
            "sa": 63,
            "sd": 40,
            "sp": 36
        },
        "weightkg": 9.8,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Furfrou": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "otherFormes": [
            "Furfrou [Heart Trim]",
            "Furfrou [Star Trim]",
            "Furfrou [Diamond Trim]",
            "Furfrou [Debutante Trim]",
            "Furfrou [Matron Trim]",
            "Furfrou [Dandy Trim]",
            "Furfrou [La Reine Trim]",
            "Furfrou [Kabuki Trim]",
            "Furfrou [Pharaoh Trim]"
        ]
    },
    "Furfrou [Heart Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Star Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Diamond Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Debutante Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Matron Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Dandy Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [La Reine Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Kabuki Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furfrou [Pharaoh Trim]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 60,
            "sa": 65,
            "sd": 90,
            "sp": 102
        },
        "weightkg": 28,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Furfrou"
    },
    "Furret": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 85,
            "at": 76,
            "df": 64,
            "sa": 45,
            "sd": 55,
            "sp": 90
        },
        "weightkg": 32.5,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Gabite": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 68,
            "at": 90,
            "df": 65,
            "sa": 50,
            "sd": 55,
            "sp": 82
        },
        "weightkg": 56,
        "abilities": {
            "0": "Rough Skin"
        }
    },
    "Gallade": {
        "types": [
            "Psychic",
            "Fighting"
        ],
        "bs": {
            "hp": 68,
            "at": 125,
            "df": 65,
            "sa": 65,
            "sd": 115,
            "sp": 80
        },
        "weightkg": 52,
        "abilities": {
            "0": "Steadfast"
        },
        "otherFormes": [
            "Gallade [Mega Gallade]"
        ]
    },
    "Gallade [Mega Gallade]": {
        "types": [
            "Psychic",
            "Fighting"
        ],
        "bs": {
            "hp": 68,
            "at": 165,
            "df": 95,
            "sa": 65,
            "sd": 115,
            "sp": 110
        },
        "weightkg": 56.4,
        "abilities": {
            "0": "Inner Focus"
        },
        "baseSpecies": "Gallade"
    },
    "Galvantula": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 70,
            "at": 77,
            "df": 60,
            "sa": 97,
            "sd": 60,
            "sp": 108
        },
        "weightkg": 14.3,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Garbodor": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 95,
            "df": 82,
            "sa": 60,
            "sd": 82,
            "sp": 75
        },
        "weightkg": 107.3,
        "abilities": {
            "0": "Aftermath"
        }
    },
    "Garchomp": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 108,
            "at": 130,
            "df": 95,
            "sa": 80,
            "sd": 85,
            "sp": 102
        },
        "weightkg": 95,
        "abilities": {
            "0": "Rough Skin"
        },
        "otherFormes": [
            "Garchomp [Mega Garchomp]",
            "Garchomp [Mega Garchomp Z]"
        ]
    },
    "Garchomp [Mega Garchomp]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 108,
            "at": 170,
            "df": 115,
            "sa": 120,
            "sd": 95,
            "sp": 92
        },
        "weightkg": 95,
        "abilities": {
            "0": "Sand Force"
        },
        "baseSpecies": "Garchomp"
    },
    "Garchomp [Mega Garchomp Z]": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 108,
            "at": 130,
            "df": 85,
            "sa": 141,
            "sd": 85,
            "sp": 151
        },
        "weightkg": 99,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Garchomp"
    },
    "Gardevoir": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 68,
            "at": 65,
            "df": 65,
            "sa": 125,
            "sd": 115,
            "sp": 80
        },
        "weightkg": 48.4,
        "abilities": {
            "0": "Synchronize"
        },
        "otherFormes": [
            "Gardevoir [Mega Gardevoir]"
        ]
    },
    "Gardevoir [Mega Gardevoir]": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 68,
            "at": 85,
            "df": 65,
            "sa": 165,
            "sd": 135,
            "sp": 100
        },
        "weightkg": 48.4,
        "abilities": {
            "0": "Pixilate"
        },
        "baseSpecies": "Gardevoir"
    },
    "Garganacl": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 130,
            "sa": 45,
            "sd": 90,
            "sp": 35
        },
        "weightkg": 240,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Gastly": {
        "types": [
            "Ghost",
            "Poison"
        ],
        "bs": {
            "hp": 30,
            "at": 35,
            "df": 30,
            "sa": 100,
            "sd": 35,
            "sp": 80
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Gastrodon": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 111,
            "at": 83,
            "df": 68,
            "sa": 92,
            "sd": 82,
            "sp": 39
        },
        "weightkg": 29.9,
        "abilities": {
            "0": "Sticky Hold"
        },
        "otherFormes": [
            "Gastrodon [East Sea]"
        ]
    },
    "Gastrodon [East Sea]": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 111,
            "at": 83,
            "df": 68,
            "sa": 92,
            "sd": 82,
            "sp": 39
        },
        "weightkg": 29.9,
        "abilities": {
            "0": "Sticky Hold"
        },
        "baseSpecies": "Gastrodon"
    },
    "Genesect": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 71,
            "at": 120,
            "df": 95,
            "sa": 120,
            "sd": 95,
            "sp": 99
        },
        "weightkg": 82.5,
        "abilities": {
            "0": "Download"
        },
        "otherFormes": [
            "Genesect [Shock Drive]",
            "Genesect [Burn Drive]",
            "Genesect [Chill Drive]",
            "Genesect [Douse Drive]"
        ]
    },
    "Genesect [Shock Drive]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 71,
            "at": 120,
            "df": 95,
            "sa": 120,
            "sd": 95,
            "sp": 99
        },
        "weightkg": 82.5,
        "abilities": {
            "0": "Download"
        },
        "baseSpecies": "Genesect"
    },
    "Genesect [Burn Drive]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 71,
            "at": 120,
            "df": 95,
            "sa": 120,
            "sd": 95,
            "sp": 99
        },
        "weightkg": 82.5,
        "abilities": {
            "0": "Download"
        },
        "baseSpecies": "Genesect"
    },
    "Genesect [Chill Drive]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 71,
            "at": 120,
            "df": 95,
            "sa": 120,
            "sd": 95,
            "sp": 99
        },
        "weightkg": 82.5,
        "abilities": {
            "0": "Download"
        },
        "baseSpecies": "Genesect"
    },
    "Genesect [Douse Drive]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 71,
            "at": 120,
            "df": 95,
            "sa": 120,
            "sd": 95,
            "sp": 99
        },
        "weightkg": 82.5,
        "abilities": {
            "0": "Download"
        },
        "baseSpecies": "Genesect"
    },
    "Gengar": {
        "types": [
            "Ghost",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 60,
            "sa": 130,
            "sd": 75,
            "sp": 110
        },
        "weightkg": 40.5,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Gengar [Mega Gengar]"
        ]
    },
    "Gengar [Mega Gengar]": {
        "types": [
            "Ghost",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 80,
            "sa": 170,
            "sd": 95,
            "sp": 130
        },
        "weightkg": 40.5,
        "abilities": {
            "0": "Shadow Tag"
        },
        "baseSpecies": "Gengar"
    },
    "Geodude": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 40,
            "at": 80,
            "df": 100,
            "sa": 30,
            "sd": 30,
            "sp": 20
        },
        "weightkg": 20,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Geodude [Alolan]"
        ]
    },
    "Geodude [Alolan]": {
        "types": [
            "Rock",
            "Electric"
        ],
        "bs": {
            "hp": 40,
            "at": 80,
            "df": 100,
            "sa": 30,
            "sd": 30,
            "sp": 20
        },
        "weightkg": 20.3,
        "abilities": {
            "0": "Magnet Pull"
        },
        "baseSpecies": "Geodude"
    },
    "Gholdengo": {
        "types": [
            "Steel",
            "Ghost"
        ],
        "bs": {
            "hp": 87,
            "at": 60,
            "df": 95,
            "sa": 133,
            "sd": 91,
            "sp": 84
        },
        "weightkg": 30,
        "abilities": {
            "0": "Good as Gold"
        }
    },
    "Gible": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 58,
            "at": 70,
            "df": 45,
            "sa": 40,
            "sd": 45,
            "sp": 42
        },
        "weightkg": 20.5,
        "abilities": {
            "0": "Rough Skin"
        }
    },
    "Gigalith": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 85,
            "at": 135,
            "df": 130,
            "sa": 60,
            "sd": 80,
            "sp": 25
        },
        "weightkg": 260,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Gimmighoul": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 70,
            "sa": 75,
            "sd": 70,
            "sp": 10
        },
        "weightkg": 5,
        "abilities": {
            "0": "Rattled"
        },
        "otherFormes": [
            "Gimmighoul [Roaming Form]"
        ]
    },
    "Gimmighoul [Roaming Form]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 70,
            "sa": 75,
            "sd": 70,
            "sp": 10
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Run Away"
        },
        "baseSpecies": "Gimmighoul"
    },
    "Girafarig": {
        "types": [
            "Normal",
            "Psychic"
        ],
        "bs": {
            "hp": 70,
            "at": 80,
            "df": 65,
            "sa": 90,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 41.5,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Giratina": {
        "types": [
            "Ghost",
            "Dragon"
        ],
        "bs": {
            "hp": 150,
            "at": 100,
            "df": 120,
            "sa": 100,
            "sd": 120,
            "sp": 90
        },
        "weightkg": 750,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Giratina [Origin Forme]"
        ]
    },
    "Giratina [Origin Forme]": {
        "types": [
            "Ghost",
            "Dragon"
        ],
        "bs": {
            "hp": 150,
            "at": 120,
            "df": 100,
            "sa": 120,
            "sd": 100,
            "sp": 90
        },
        "weightkg": 650,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Giratina"
    },
    "Glaceon": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 110,
            "sa": 130,
            "sd": 95,
            "sp": 65
        },
        "weightkg": 25.9,
        "abilities": {
            "0": "Ice Body"
        }
    },
    "Glalie": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 80,
            "sa": 80,
            "sd": 80,
            "sp": 80
        },
        "weightkg": 256.5,
        "abilities": {
            "0": "Inner Focus"
        },
        "otherFormes": [
            "Glalie [Mega Glalie]"
        ]
    },
    "Glalie [Mega Glalie]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 80,
            "sa": 120,
            "sd": 80,
            "sp": 100
        },
        "weightkg": 350.2,
        "abilities": {
            "0": "Refrigerate"
        },
        "baseSpecies": "Glalie"
    },
    "Glameow": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 49,
            "at": 55,
            "df": 42,
            "sa": 42,
            "sd": 37,
            "sp": 85
        },
        "weightkg": 3.9,
        "abilities": {
            "0": "Limber"
        }
    },
    "Glastrier": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 100,
            "at": 145,
            "df": 130,
            "sa": 65,
            "sd": 110,
            "sp": 30
        },
        "weightkg": 800,
        "abilities": {
            "0": "Chilling Neigh"
        }
    },
    "Gligar": {
        "types": [
            "Ground",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 75,
            "df": 105,
            "sa": 35,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 64.8,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Glimmet": {
        "types": [
            "Rock",
            "Poison"
        ],
        "bs": {
            "hp": 48,
            "at": 35,
            "df": 42,
            "sa": 105,
            "sd": 60,
            "sp": 60
        },
        "weightkg": 8,
        "abilities": {
            "0": "Corrosion"
        }
    },
    "Glimmora": {
        "types": [
            "Rock",
            "Poison"
        ],
        "bs": {
            "hp": 83,
            "at": 55,
            "df": 90,
            "sa": 130,
            "sd": 81,
            "sp": 86
        },
        "weightkg": 45,
        "abilities": {
            "0": "Corrosion"
        },
        "otherFormes": [
            "Glimmora [Mega Glimmora]"
        ]
    },
    "Glimmora [Mega Glimmora]": {
        "types": [
            "Rock",
            "Poison"
        ],
        "bs": {
            "hp": 83,
            "at": 90,
            "df": 105,
            "sa": 150,
            "sd": 96,
            "sp": 101
        },
        "weightkg": 77,
        "abilities": {
            "0": "Adaptability"
        },
        "baseSpecies": "Glimmora"
    },
    "Gliscor": {
        "types": [
            "Ground",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 95,
            "df": 125,
            "sa": 45,
            "sd": 75,
            "sp": 95
        },
        "weightkg": 42.5,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Gloom": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 70,
            "sa": 85,
            "sd": 75,
            "sp": 40
        },
        "weightkg": 8.6,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Gogoat": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 123,
            "at": 100,
            "df": 62,
            "sa": 97,
            "sd": 81,
            "sp": 68
        },
        "weightkg": 91,
        "abilities": {
            "0": "Grass Pelt"
        }
    },
    "Golbat": {
        "types": [
            "Poison",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 70,
            "sa": 65,
            "sd": 75,
            "sp": 90
        },
        "weightkg": 55,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Goldeen": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 45,
            "at": 67,
            "df": 60,
            "sa": 35,
            "sd": 50,
            "sp": 63
        },
        "weightkg": 15,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Golduck": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 82,
            "df": 78,
            "sa": 95,
            "sd": 80,
            "sp": 85
        },
        "weightkg": 76.6,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Golem": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 130,
            "sa": 55,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 300,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Golem [Alolan]"
        ]
    },
    "Golem [Alolan]": {
        "types": [
            "Rock",
            "Electric"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 130,
            "sa": 55,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 316,
        "abilities": {
            "0": "Magnet Pull"
        },
        "baseSpecies": "Golem"
    },
    "Golett": {
        "types": [
            "Ground",
            "Ghost"
        ],
        "bs": {
            "hp": 59,
            "at": 74,
            "df": 50,
            "sa": 35,
            "sd": 50,
            "sp": 35
        },
        "weightkg": 92,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Golisopod": {
        "types": [
            "Bug",
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 140,
            "sa": 60,
            "sd": 90,
            "sp": 40
        },
        "weightkg": 108,
        "abilities": {
            "0": "Emergency Exit"
        },
        "otherFormes": [
            "Golisopod [Mega Golisopod]"
        ]
    },
    "Golisopod [Mega Golisopod]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 75,
            "at": 150,
            "df": 175,
            "sa": 70,
            "sd": 120,
            "sp": 40
        },
        "weightkg": 148,
        "abilities": {
            "0": "Emergency Exit"
        },
        "baseSpecies": "Golisopod"
    },
    "Golurk": {
        "types": [
            "Ground",
            "Ghost"
        ],
        "bs": {
            "hp": 89,
            "at": 124,
            "df": 80,
            "sa": 55,
            "sd": 80,
            "sp": 55
        },
        "weightkg": 330,
        "abilities": {
            "0": "Iron Fist"
        },
        "otherFormes": [
            "Golurk [Mega Golurk]"
        ]
    },
    "Golurk [Mega Golurk]": {
        "types": [
            "Ground",
            "Ghost"
        ],
        "bs": {
            "hp": 89,
            "at": 159,
            "df": 105,
            "sa": 70,
            "sd": 105,
            "sp": 55
        },
        "weightkg": 330,
        "abilities": {
            "0": "Unseen Fist"
        },
        "baseSpecies": "Golurk"
    },
    "Goodra": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 70,
            "sa": 110,
            "sd": 150,
            "sp": 80
        },
        "weightkg": 150.5,
        "abilities": {
            "0": "Gooey"
        },
        "otherFormes": [
            "Goodra [Hisuian]"
        ]
    },
    "Goodra [Hisuian]": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 100,
            "sa": 110,
            "sd": 150,
            "sp": 60
        },
        "weightkg": 334.1,
        "abilities": {
            "0": "Gooey"
        },
        "baseSpecies": "Goodra"
    },
    "Goomy": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 45,
            "at": 50,
            "df": 35,
            "sa": 55,
            "sd": 75,
            "sp": 40
        },
        "weightkg": 2.8,
        "abilities": {
            "0": "Gooey"
        }
    },
    "Gorebyss": {
        "types": [
            "Water",
            "Fairy"
        ],
        "bs": {
            "hp": 55,
            "at": 84,
            "df": 105,
            "sa": 114,
            "sd": 75,
            "sp": 52
        },
        "weightkg": 22.6,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Gossifleur": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 60,
            "sa": 40,
            "sd": 60,
            "sp": 10
        },
        "weightkg": 2.2,
        "abilities": {
            "0": "Cotton Down"
        }
    },
    "Gothita": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 50,
            "sa": 55,
            "sd": 65,
            "sp": 45
        },
        "weightkg": 5.8,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Gothitelle": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 70,
            "at": 55,
            "df": 95,
            "sa": 95,
            "sd": 110,
            "sp": 65
        },
        "weightkg": 44,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Gothorita": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 45,
            "df": 70,
            "sa": 75,
            "sd": 85,
            "sp": 55
        },
        "weightkg": 18,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Gouging Fire": {
        "types": [
            "Fire",
            "Dragon"
        ],
        "bs": {
            "hp": 105,
            "at": 115,
            "df": 121,
            "sa": 65,
            "sd": 93,
            "sp": 91
        },
        "weightkg": 590,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Gourgeist": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 55,
            "at": 85,
            "df": 122,
            "sa": 58,
            "sd": 75,
            "sp": 99
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Frisk"
        },
        "otherFormes": [
            "Gourgeist [Average Size]",
            "Gourgeist [Large Size]",
            "Gourgeist [Super Size]"
        ]
    },
    "Gourgeist [Average Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 122,
            "sa": 58,
            "sd": 75,
            "sp": 84
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Gourgeist"
    },
    "Gourgeist [Large Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 75,
            "at": 95,
            "df": 122,
            "sa": 58,
            "sd": 75,
            "sp": 69
        },
        "weightkg": 14,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Gourgeist"
    },
    "Gourgeist [Super Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 85,
            "at": 100,
            "df": 122,
            "sa": 58,
            "sd": 75,
            "sp": 54
        },
        "weightkg": 39,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Gourgeist"
    },
    "Grafaiai": {
        "types": [
            "Poison",
            "Normal"
        ],
        "bs": {
            "hp": 63,
            "at": 95,
            "df": 65,
            "sa": 80,
            "sd": 72,
            "sp": 110
        },
        "weightkg": 27.2,
        "abilities": {
            "0": "Unburden"
        }
    },
    "Granbull": {
        "types": [
            "Fairy",
            "Fighting"
        ],
        "bs": {
            "hp": 90,
            "at": 120,
            "df": 75,
            "sa": 60,
            "sd": 60,
            "sp": 45
        },
        "weightkg": 48.7,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Grapploct": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 118,
            "df": 90,
            "sa": 70,
            "sd": 80,
            "sp": 42
        },
        "weightkg": 39,
        "abilities": {
            "0": "Limber"
        }
    },
    "Graveler": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 55,
            "at": 95,
            "df": 115,
            "sa": 45,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 105,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Graveler [Alolan]"
        ]
    },
    "Graveler [Alolan]": {
        "types": [
            "Rock",
            "Electric"
        ],
        "bs": {
            "hp": 55,
            "at": 95,
            "df": 115,
            "sa": 45,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 110,
        "abilities": {
            "0": "Magnet Pull"
        },
        "baseSpecies": "Graveler"
    },
    "Great Tusk": {
        "types": [
            "Ground",
            "Fighting"
        ],
        "bs": {
            "hp": 115,
            "at": 131,
            "df": 131,
            "sa": 53,
            "sd": 53,
            "sp": 87
        },
        "weightkg": 320,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Greavard": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 50,
            "at": 61,
            "df": 60,
            "sa": 30,
            "sd": 55,
            "sp": 34
        },
        "weightkg": 35,
        "abilities": {
            "0": "Sand Rush"
        }
    },
    "Greedent": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 120,
            "at": 95,
            "df": 95,
            "sa": 55,
            "sd": 75,
            "sp": 20
        },
        "weightkg": 6,
        "abilities": {
            "0": "Cheek Pouch"
        }
    },
    "Greninja": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 72,
            "at": 95,
            "df": 67,
            "sa": 103,
            "sd": 71,
            "sp": 122
        },
        "weightkg": 40,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Greninja [Form 1]",
            "Greninja [Ash-Greninja]",
            "Greninja [Mega Greninja]"
        ]
    },
    "Greninja [Form 1]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 72,
            "at": 95,
            "df": 67,
            "sa": 103,
            "sd": 71,
            "sp": 122
        },
        "weightkg": 40,
        "abilities": {
            "0": "Battle Bond"
        },
        "baseSpecies": "Greninja"
    },
    "Greninja [Ash-Greninja]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 72,
            "at": 145,
            "df": 67,
            "sa": 153,
            "sd": 71,
            "sp": 132
        },
        "weightkg": 40,
        "abilities": {
            "0": "Battle Bond"
        },
        "baseSpecies": "Greninja"
    },
    "Greninja [Mega Greninja]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 72,
            "at": 125,
            "df": 77,
            "sa": 133,
            "sd": 81,
            "sp": 142
        },
        "weightkg": 40,
        "abilities": {
            "0": "Protean"
        },
        "baseSpecies": "Greninja"
    },
    "Grimer": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 25
        },
        "weightkg": 30,
        "abilities": {
            "0": "Poison Touch"
        },
        "otherFormes": [
            "Grimer [Alolan]"
        ]
    },
    "Grimer [Alolan]": {
        "types": [
            "Poison",
            "Dark"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 25
        },
        "weightkg": 42,
        "abilities": {
            "0": "Poison Touch"
        },
        "baseSpecies": "Grimer"
    },
    "Grimmsnarl": {
        "types": [
            "Dark",
            "Fairy"
        ],
        "bs": {
            "hp": 95,
            "at": 120,
            "df": 65,
            "sa": 95,
            "sd": 75,
            "sp": 60
        },
        "weightkg": 61,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Grookey": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 50,
            "sa": 40,
            "sd": 40,
            "sp": 65
        },
        "weightkg": 5,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Grotle": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 75,
            "at": 89,
            "df": 85,
            "sa": 55,
            "sd": 65,
            "sp": 36
        },
        "weightkg": 97,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Groudon": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 100,
            "at": 150,
            "df": 140,
            "sa": 100,
            "sd": 90,
            "sp": 90
        },
        "weightkg": 950,
        "abilities": {
            "0": "Drought"
        },
        "otherFormes": [
            "Groudon [Primal Groudon]"
        ]
    },
    "Groudon [Primal Groudon]": {
        "types": [
            "Ground",
            "Fire"
        ],
        "bs": {
            "hp": 100,
            "at": 180,
            "df": 160,
            "sa": 150,
            "sd": 90,
            "sp": 90
        },
        "weightkg": 999.7,
        "abilities": {
            "0": "Desolate Land"
        },
        "baseSpecies": "Groudon"
    },
    "Grovyle": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 45,
            "sa": 85,
            "sd": 65,
            "sp": 95
        },
        "weightkg": 21.6,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Growlithe": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 55,
            "at": 70,
            "df": 45,
            "sa": 70,
            "sd": 50,
            "sp": 60
        },
        "weightkg": 19,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Growlithe [Hisuian]"
        ]
    },
    "Growlithe [Hisuian]": {
        "types": [
            "Fire",
            "Rock"
        ],
        "bs": {
            "hp": 60,
            "at": 75,
            "df": 45,
            "sa": 65,
            "sd": 50,
            "sp": 55
        },
        "weightkg": 22.7,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Growlithe"
    },
    "Grubbin": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 47,
            "at": 62,
            "df": 45,
            "sa": 55,
            "sd": 45,
            "sp": 46
        },
        "weightkg": 4.4,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Grumpig": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 45,
            "df": 65,
            "sa": 90,
            "sd": 110,
            "sp": 80
        },
        "weightkg": 71.5,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Gulpin": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 70,
            "at": 43,
            "df": 53,
            "sa": 43,
            "sd": 53,
            "sp": 40
        },
        "weightkg": 10.3,
        "abilities": {
            "0": "Liquid Ooze"
        }
    },
    "Gumshoos": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 88,
            "at": 110,
            "df": 60,
            "sa": 55,
            "sd": 60,
            "sp": 45
        },
        "weightkg": 14.2,
        "abilities": {
            "0": "Stakeout"
        }
    },
    "Gurdurr": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 85,
            "at": 105,
            "df": 85,
            "sa": 40,
            "sd": 50,
            "sp": 40
        },
        "weightkg": 40,
        "abilities": {
            "0": "Guts"
        }
    },
    "Guzzlord": {
        "types": [
            "Dark",
            "Dragon"
        ],
        "bs": {
            "hp": 223,
            "at": 101,
            "df": 53,
            "sa": 97,
            "sd": 53,
            "sp": 43
        },
        "weightkg": 888,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Gyarados": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 95,
            "at": 125,
            "df": 79,
            "sa": 60,
            "sd": 100,
            "sp": 81
        },
        "weightkg": 235,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Gyarados [Mega Gyarados]"
        ]
    },
    "Gyarados [Mega Gyarados]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 155,
            "df": 109,
            "sa": 70,
            "sd": 130,
            "sp": 81
        },
        "weightkg": 305,
        "abilities": {
            "0": "Mold Breaker"
        },
        "baseSpecies": "Gyarados"
    },
    "Hakamo-o": {
        "types": [
            "Dragon",
            "Fighting"
        ],
        "bs": {
            "hp": 55,
            "at": 75,
            "df": 90,
            "sa": 65,
            "sd": 70,
            "sp": 65
        },
        "weightkg": 47,
        "abilities": {
            "0": "Bulletproof"
        }
    },
    "Happiny": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 100,
            "at": 5,
            "df": 5,
            "sa": 15,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 24.4,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Hariyama": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 144,
            "at": 120,
            "df": 60,
            "sa": 40,
            "sd": 60,
            "sp": 50
        },
        "weightkg": 253.8,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Hatenna": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 42,
            "at": 30,
            "df": 45,
            "sa": 56,
            "sd": 53,
            "sp": 39
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Healer"
        }
    },
    "Hatterene": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 57,
            "at": 90,
            "df": 95,
            "sa": 136,
            "sd": 103,
            "sp": 29
        },
        "weightkg": 5.1,
        "abilities": {
            "0": "Healer"
        }
    },
    "Hattrem": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 57,
            "at": 40,
            "df": 65,
            "sa": 86,
            "sd": 73,
            "sp": 49
        },
        "weightkg": 4.8,
        "abilities": {
            "0": "Healer"
        }
    },
    "Haunter": {
        "types": [
            "Ghost",
            "Poison"
        ],
        "bs": {
            "hp": 45,
            "at": 50,
            "df": 45,
            "sa": 115,
            "sd": 55,
            "sp": 95
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Hawlucha": {
        "types": [
            "Fighting",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 92,
            "df": 75,
            "sa": 74,
            "sd": 63,
            "sp": 118
        },
        "weightkg": 21.5,
        "abilities": {
            "0": "Limber"
        },
        "otherFormes": [
            "Hawlucha [Mega Hawlucha]"
        ]
    },
    "Hawlucha [Mega Hawlucha]": {
        "types": [
            "Fighting",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 137,
            "df": 100,
            "sa": 74,
            "sd": 93,
            "sp": 118
        },
        "weightkg": 25,
        "abilities": {
            "0": "No Guard"
        },
        "baseSpecies": "Hawlucha"
    },
    "Haxorus": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 76,
            "at": 147,
            "df": 90,
            "sa": 60,
            "sd": 70,
            "sp": 97
        },
        "weightkg": 105.5,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Heatmor": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 85,
            "at": 97,
            "df": 66,
            "sa": 105,
            "sd": 66,
            "sp": 65
        },
        "weightkg": 58,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Heatran": {
        "types": [
            "Fire",
            "Steel"
        ],
        "bs": {
            "hp": 91,
            "at": 90,
            "df": 106,
            "sa": 130,
            "sd": 106,
            "sp": 77
        },
        "weightkg": 430,
        "abilities": {
            "0": "Flame Body"
        },
        "otherFormes": [
            "Heatran [Mega Heatran]"
        ]
    },
    "Heatran [Mega Heatran]": {
        "types": [
            "Fire",
            "Steel"
        ],
        "bs": {
            "hp": 91,
            "at": 120,
            "df": 106,
            "sa": 175,
            "sd": 141,
            "sp": 67
        },
        "weightkg": 570,
        "abilities": {
            "0": "Flame Body"
        },
        "baseSpecies": "Heatran"
    },
    "Heliolisk": {
        "types": [
            "Electric",
            "Normal"
        ],
        "bs": {
            "hp": 62,
            "at": 55,
            "df": 52,
            "sa": 109,
            "sd": 94,
            "sp": 109
        },
        "weightkg": 21,
        "abilities": {
            "0": "Solar Power"
        }
    },
    "Helioptile": {
        "types": [
            "Electric",
            "Normal"
        ],
        "bs": {
            "hp": 44,
            "at": 38,
            "df": 33,
            "sa": 61,
            "sd": 43,
            "sp": 70
        },
        "weightkg": 6,
        "abilities": {
            "0": "Solar Power"
        }
    },
    "Heracross": {
        "types": [
            "Bug",
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 125,
            "df": 75,
            "sa": 40,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 54,
        "abilities": {
            "0": "Swarm"
        },
        "otherFormes": [
            "Heracross [Mega Heracross]"
        ]
    },
    "Heracross [Mega Heracross]": {
        "types": [
            "Bug",
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 185,
            "df": 115,
            "sa": 40,
            "sd": 105,
            "sp": 75
        },
        "weightkg": 62.5,
        "abilities": {
            "0": "Skill Link"
        },
        "baseSpecies": "Heracross"
    },
    "Herdier": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 65,
            "at": 80,
            "df": 65,
            "sa": 35,
            "sd": 65,
            "sp": 60
        },
        "weightkg": 14.7,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Hippopotas": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 68,
            "at": 72,
            "df": 78,
            "sa": 38,
            "sd": 42,
            "sp": 32
        },
        "weightkg": 49.5,
        "abilities": {
            "0": "Sand Force"
        }
    },
    "Hippowdon": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 108,
            "at": 112,
            "df": 118,
            "sa": 68,
            "sd": 72,
            "sp": 47
        },
        "weightkg": 300,
        "abilities": {
            "0": "Sand Force"
        }
    },
    "Hitmonchan": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 50,
            "at": 105,
            "df": 79,
            "sa": 35,
            "sd": 110,
            "sp": 76
        },
        "weightkg": 50.2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Hitmonlee": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 50,
            "at": 120,
            "df": 53,
            "sa": 35,
            "sd": 110,
            "sp": 87
        },
        "weightkg": 49.8,
        "abilities": {
            "0": "Limber"
        }
    },
    "Hitmontop": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 50,
            "at": 95,
            "df": 95,
            "sa": 35,
            "sd": 110,
            "sp": 70
        },
        "weightkg": 48,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Honchkrow": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 100,
            "at": 125,
            "df": 52,
            "sa": 105,
            "sd": 52,
            "sp": 71
        },
        "weightkg": 27.3,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Honedge": {
        "types": [
            "Steel",
            "Ghost"
        ],
        "bs": {
            "hp": 45,
            "at": 80,
            "df": 100,
            "sa": 35,
            "sd": 37,
            "sp": 28
        },
        "weightkg": 2,
        "abilities": {
            "0": "No Guard"
        }
    },
    "Ho-Oh": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 106,
            "at": 130,
            "df": 90,
            "sa": 110,
            "sd": 154,
            "sp": 90
        },
        "weightkg": 199,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Hoopa": {
        "types": [
            "Psychic",
            "Ghost"
        ],
        "bs": {
            "hp": 80,
            "at": 110,
            "df": 60,
            "sa": 150,
            "sd": 130,
            "sp": 70
        },
        "weightkg": 9,
        "abilities": {
            "0": "Magician"
        },
        "otherFormes": [
            "Hoopa [Hoopa Unbound]"
        ]
    },
    "Hoopa [Hoopa Unbound]": {
        "types": [
            "Psychic",
            "Dark"
        ],
        "bs": {
            "hp": 80,
            "at": 160,
            "df": 60,
            "sa": 170,
            "sd": 130,
            "sp": 80
        },
        "weightkg": 490,
        "abilities": {
            "0": "Magician"
        },
        "baseSpecies": "Hoopa"
    },
    "Hoothoot": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 30,
            "df": 30,
            "sa": 36,
            "sd": 56,
            "sp": 50
        },
        "weightkg": 21.2,
        "abilities": {
            "0": "Tinted Lens"
        }
    },
    "Hoppip": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 35,
            "at": 35,
            "df": 40,
            "sa": 35,
            "sd": 55,
            "sp": 50
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Horsea": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 30,
            "at": 40,
            "df": 70,
            "sa": 70,
            "sd": 25,
            "sp": 60
        },
        "weightkg": 8,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Houndoom": {
        "types": [
            "Dark",
            "Fire"
        ],
        "bs": {
            "hp": 75,
            "at": 90,
            "df": 50,
            "sa": 110,
            "sd": 80,
            "sp": 95
        },
        "weightkg": 35,
        "abilities": {
            "0": "Early Bird"
        },
        "otherFormes": [
            "Houndoom [Mega Houndoom]"
        ]
    },
    "Houndoom [Mega Houndoom]": {
        "types": [
            "Dark",
            "Fire"
        ],
        "bs": {
            "hp": 75,
            "at": 90,
            "df": 90,
            "sa": 140,
            "sd": 90,
            "sp": 115
        },
        "weightkg": 49.5,
        "abilities": {
            "0": "Solar Power"
        },
        "baseSpecies": "Houndoom"
    },
    "Houndour": {
        "types": [
            "Dark",
            "Fire"
        ],
        "bs": {
            "hp": 45,
            "at": 60,
            "df": 30,
            "sa": 80,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 10.8,
        "abilities": {
            "0": "Early Bird"
        }
    },
    "Houndstone": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 72,
            "at": 101,
            "df": 100,
            "sa": 50,
            "sd": 97,
            "sp": 68
        },
        "weightkg": 15,
        "abilities": {
            "0": "Sand Rush"
        }
    },
    "Huntail": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 55,
            "at": 104,
            "df": 105,
            "sa": 94,
            "sd": 75,
            "sp": 52
        },
        "weightkg": 27,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Hydrapple": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 106,
            "at": 80,
            "df": 110,
            "sa": 120,
            "sd": 80,
            "sp": 44
        },
        "weightkg": 93,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Hydreigon": {
        "types": [
            "Dark",
            "Dragon"
        ],
        "bs": {
            "hp": 92,
            "at": 105,
            "df": 90,
            "sa": 125,
            "sd": 90,
            "sp": 98
        },
        "weightkg": 160,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Hypno": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 85,
            "at": 73,
            "df": 70,
            "sa": 73,
            "sd": 115,
            "sp": 67
        },
        "weightkg": 75.6,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Igglybuff": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 90,
            "at": 30,
            "df": 15,
            "sa": 40,
            "sd": 20,
            "sp": 15
        },
        "weightkg": 1,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Illumise": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 65,
            "at": 47,
            "df": 75,
            "sa": 73,
            "sd": 85,
            "sp": 85
        },
        "weightkg": 17.7,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Impidimp": {
        "types": [
            "Dark",
            "Fairy"
        ],
        "bs": {
            "hp": 45,
            "at": 45,
            "df": 30,
            "sa": 55,
            "sd": 40,
            "sp": 50
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Incineroar": {
        "types": [
            "Fire",
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 115,
            "df": 90,
            "sa": 80,
            "sd": 90,
            "sp": 60
        },
        "weightkg": 83,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Indeedee": {
        "types": [
            "Psychic",
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 55,
            "sa": 105,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 28,
        "abilities": {
            "0": "Inner Focus"
        },
        "otherFormes": [
            "Indeedee [Female]"
        ]
    },
    "Indeedee [Female]": {
        "types": [
            "Psychic",
            "Normal"
        ],
        "bs": {
            "hp": 70,
            "at": 55,
            "df": 65,
            "sa": 95,
            "sd": 105,
            "sp": 85
        },
        "weightkg": 28,
        "abilities": {
            "0": "Own Tempo"
        },
        "baseSpecies": "Indeedee"
    },
    "Infernape": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 76,
            "at": 104,
            "df": 71,
            "sa": 104,
            "sd": 71,
            "sp": 108
        },
        "weightkg": 55,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Inkay": {
        "types": [
            "Dark",
            "Psychic"
        ],
        "bs": {
            "hp": 53,
            "at": 54,
            "df": 53,
            "sa": 37,
            "sd": 46,
            "sp": 45
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Inteleon": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 65,
            "sa": 125,
            "sd": 65,
            "sp": 120
        },
        "weightkg": 45.2,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Iron Boulder": {
        "types": [
            "Rock",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 120,
            "df": 80,
            "sa": 68,
            "sd": 108,
            "sp": 124
        },
        "weightkg": 162.5,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Bundle": {
        "types": [
            "Ice",
            "Water"
        ],
        "bs": {
            "hp": 56,
            "at": 80,
            "df": 114,
            "sa": 124,
            "sd": 60,
            "sp": 136
        },
        "weightkg": 11,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Crown": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 72,
            "df": 100,
            "sa": 122,
            "sd": 108,
            "sp": 98
        },
        "weightkg": 156,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Hands": {
        "types": [
            "Fighting",
            "Electric"
        ],
        "bs": {
            "hp": 154,
            "at": 140,
            "df": 108,
            "sa": 50,
            "sd": 68,
            "sp": 50
        },
        "weightkg": 380.7,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Jugulis": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 94,
            "at": 80,
            "df": 86,
            "sa": 122,
            "sd": 80,
            "sp": 108
        },
        "weightkg": 111,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Leaves": {
        "types": [
            "Grass",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 130,
            "df": 88,
            "sa": 70,
            "sd": 108,
            "sp": 104
        },
        "weightkg": 125,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Moth": {
        "types": [
            "Fire",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 70,
            "df": 60,
            "sa": 140,
            "sd": 110,
            "sp": 110
        },
        "weightkg": 36,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Thorns": {
        "types": [
            "Rock",
            "Electric"
        ],
        "bs": {
            "hp": 100,
            "at": 134,
            "df": 110,
            "sa": 70,
            "sd": 84,
            "sp": 72
        },
        "weightkg": 303,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Treads": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 90,
            "at": 112,
            "df": 120,
            "sa": 72,
            "sd": 70,
            "sp": 106
        },
        "weightkg": 240,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Iron Valiant": {
        "types": [
            "Fairy",
            "Fighting"
        ],
        "bs": {
            "hp": 74,
            "at": 130,
            "df": 90,
            "sa": 120,
            "sd": 60,
            "sp": 116
        },
        "weightkg": 35,
        "abilities": {
            "0": "Quark Drive"
        }
    },
    "Ivysaur": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 62,
            "df": 63,
            "sa": 80,
            "sd": 80,
            "sp": 60
        },
        "weightkg": 13,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Jangmo-o": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 45,
            "at": 55,
            "df": 65,
            "sa": 45,
            "sd": 45,
            "sp": 45
        },
        "weightkg": 29.7,
        "abilities": {
            "0": "Bulletproof"
        }
    },
    "Jellicent": {
        "types": [
            "Water",
            "Ghost"
        ],
        "bs": {
            "hp": 100,
            "at": 60,
            "df": 70,
            "sa": 85,
            "sd": 105,
            "sp": 60
        },
        "weightkg": 135,
        "abilities": {
            "0": "Damp"
        }
    },
    "Jigglypuff": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 115,
            "at": 45,
            "df": 20,
            "sa": 45,
            "sd": 25,
            "sp": 20
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Jirachi": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 1.1,
        "abilities": {
            "0": "Serene Grace"
        }
    },
    "Jolteon": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 65,
            "at": 65,
            "df": 60,
            "sa": 110,
            "sd": 95,
            "sp": 130
        },
        "weightkg": 24.5,
        "abilities": {
            "0": "Quick Feet"
        }
    },
    "Joltik": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 50,
            "at": 47,
            "df": 50,
            "sa": 57,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 0.6,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Jumpluff": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 55,
            "df": 70,
            "sa": 55,
            "sd": 95,
            "sp": 110
        },
        "weightkg": 3,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Jynx": {
        "types": [
            "Ice",
            "Psychic"
        ],
        "bs": {
            "hp": 65,
            "at": 50,
            "df": 35,
            "sa": 115,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 40.6,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Kabuto": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 30,
            "at": 80,
            "df": 90,
            "sa": 55,
            "sd": 45,
            "sp": 55
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Kabutops": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 60,
            "at": 115,
            "df": 105,
            "sa": 65,
            "sd": 70,
            "sp": 80
        },
        "weightkg": 40.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Kadabra": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 40,
            "at": 35,
            "df": 30,
            "sa": 120,
            "sd": 70,
            "sp": 105
        },
        "weightkg": 56.5,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Kakuna": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 45,
            "at": 25,
            "df": 50,
            "sa": 25,
            "sd": 25,
            "sp": 35
        },
        "weightkg": 10,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Kangaskhan": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 105,
            "at": 95,
            "df": 80,
            "sa": 40,
            "sd": 80,
            "sp": 90
        },
        "weightkg": 80,
        "abilities": {
            "0": "Early Bird"
        },
        "otherFormes": [
            "Kangaskhan [Mega Kangaskhan]"
        ]
    },
    "Kangaskhan [Mega Kangaskhan]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 105,
            "at": 125,
            "df": 100,
            "sa": 60,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 100,
        "abilities": {
            "0": "Parental Bond"
        },
        "baseSpecies": "Kangaskhan"
    },
    "Karrablast": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 45,
            "sa": 40,
            "sd": 45,
            "sp": 60
        },
        "weightkg": 5.9,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Kartana": {
        "types": [
            "Grass",
            "Steel"
        ],
        "bs": {
            "hp": 59,
            "at": 181,
            "df": 131,
            "sa": 59,
            "sd": 31,
            "sp": 109
        },
        "weightkg": 0.1,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Kecleon": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 90,
            "df": 70,
            "sa": 60,
            "sd": 120,
            "sp": 40
        },
        "weightkg": 22,
        "abilities": {
            "0": "Color Change"
        }
    },
    "Keldeo": {
        "types": [
            "Water",
            "Fighting"
        ],
        "bs": {
            "hp": 91,
            "at": 72,
            "df": 90,
            "sa": 129,
            "sd": 90,
            "sp": 108
        },
        "weightkg": 48.5,
        "abilities": {
            "0": "Justified"
        },
        "otherFormes": [
            "Keldeo [Resolute Form]"
        ]
    },
    "Keldeo [Resolute Form]": {
        "types": [
            "Water",
            "Fighting"
        ],
        "bs": {
            "hp": 91,
            "at": 72,
            "df": 90,
            "sa": 129,
            "sd": 90,
            "sp": 108
        },
        "weightkg": 48.5,
        "abilities": {
            "0": "Justified"
        },
        "baseSpecies": "Keldeo"
    },
    "Kilowattrel": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 60,
            "sa": 105,
            "sd": 60,
            "sp": 125
        },
        "weightkg": 38.6,
        "abilities": {
            "0": "Wind Power"
        }
    },
    "Kingambit": {
        "types": [
            "Dark",
            "Steel"
        ],
        "bs": {
            "hp": 100,
            "at": 135,
            "df": 120,
            "sa": 60,
            "sd": 85,
            "sp": 50
        },
        "weightkg": 120,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Kingdra": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 75,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 152,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Kingler": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 130,
            "df": 115,
            "sa": 50,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 60,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Kirlia": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 38,
            "at": 35,
            "df": 35,
            "sa": 65,
            "sd": 55,
            "sp": 50
        },
        "weightkg": 20.2,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Klang": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 60,
            "at": 80,
            "df": 95,
            "sa": 70,
            "sd": 85,
            "sp": 50
        },
        "weightkg": 51,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Klawf": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 100,
            "df": 115,
            "sa": 35,
            "sd": 55,
            "sp": 75
        },
        "weightkg": 79,
        "abilities": {
            "0": "Anger Shell"
        }
    },
    "Kleavor": {
        "types": [
            "Bug",
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 135,
            "df": 95,
            "sa": 45,
            "sd": 70,
            "sp": 85
        },
        "weightkg": 89,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Klefki": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 57,
            "at": 80,
            "df": 91,
            "sa": 80,
            "sd": 87,
            "sp": 75
        },
        "weightkg": 3,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Klink": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 70,
            "sa": 45,
            "sd": 60,
            "sp": 30
        },
        "weightkg": 21,
        "abilities": {
            "0": "Plus"
        }
    },
    "Klinklang": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 115,
            "sa": 70,
            "sd": 85,
            "sp": 90
        },
        "weightkg": 81,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Koffing": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 65,
            "df": 95,
            "sa": 60,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 1,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Komala": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 65,
            "at": 115,
            "df": 65,
            "sa": 75,
            "sd": 95,
            "sp": 65
        },
        "weightkg": 19.9,
        "abilities": {
            "0": "Comatose"
        }
    },
    "Kommo-o": {
        "types": [
            "Dragon",
            "Fighting"
        ],
        "bs": {
            "hp": 75,
            "at": 110,
            "df": 125,
            "sa": 100,
            "sd": 105,
            "sp": 85
        },
        "weightkg": 78.2,
        "abilities": {
            "0": "Bulletproof"
        }
    },
    "Koraidon": {
        "types": [
            "Fighting",
            "Dragon"
        ],
        "bs": {
            "hp": 100,
            "at": 135,
            "df": 115,
            "sa": 85,
            "sd": 100,
            "sp": 135
        },
        "weightkg": 303,
        "abilities": {
            "0": "Orichalcum Pulse"
        }
    },
    "Krabby": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 30,
            "at": 105,
            "df": 90,
            "sa": 25,
            "sd": 25,
            "sp": 50
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Kricketot": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 37,
            "at": 25,
            "df": 41,
            "sa": 25,
            "sd": 41,
            "sp": 25
        },
        "weightkg": 2.2,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Kricketune": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 77,
            "at": 85,
            "df": 51,
            "sa": 55,
            "sd": 51,
            "sp": 65
        },
        "weightkg": 25.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Krokorok": {
        "types": [
            "Ground",
            "Dark"
        ],
        "bs": {
            "hp": 60,
            "at": 82,
            "df": 45,
            "sa": 45,
            "sd": 45,
            "sp": 74
        },
        "weightkg": 33.4,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Krookodile": {
        "types": [
            "Ground",
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 117,
            "df": 80,
            "sa": 65,
            "sd": 70,
            "sp": 92
        },
        "weightkg": 96.3,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Kubfu": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 60,
            "at": 90,
            "df": 60,
            "sa": 53,
            "sd": 50,
            "sp": 72
        },
        "weightkg": 12,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Kyogre": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 90,
            "sa": 150,
            "sd": 140,
            "sp": 90
        },
        "weightkg": 352,
        "abilities": {
            "0": "Drizzle"
        },
        "otherFormes": [
            "Kyogre [Primal Kyogre]"
        ]
    },
    "Kyogre [Primal Kyogre]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 150,
            "df": 90,
            "sa": 180,
            "sd": 160,
            "sp": 90
        },
        "weightkg": 430,
        "abilities": {
            "0": "Primordial Sea"
        },
        "baseSpecies": "Kyogre"
    },
    "Kyurem": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 125,
            "at": 130,
            "df": 90,
            "sa": 130,
            "sd": 90,
            "sp": 95
        },
        "weightkg": 325,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Kyurem [White Kyurem]",
            "Kyurem [Black Kyurem]",
            "Kyurem [Form 3]",
            "Kyurem [Form 4]"
        ]
    },
    "Kyurem [White Kyurem]": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 125,
            "at": 120,
            "df": 90,
            "sa": 170,
            "sd": 100,
            "sp": 95
        },
        "weightkg": 325,
        "abilities": {
            "0": "Turboblaze"
        },
        "baseSpecies": "Kyurem"
    },
    "Kyurem [Black Kyurem]": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 125,
            "at": 170,
            "df": 100,
            "sa": 120,
            "sd": 90,
            "sp": 95
        },
        "weightkg": 325,
        "abilities": {
            "0": "Teravolt"
        },
        "baseSpecies": "Kyurem"
    },
    "Kyurem [Form 3]": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 125,
            "at": 120,
            "df": 90,
            "sa": 170,
            "sd": 100,
            "sp": 95
        },
        "weightkg": 325,
        "abilities": {
            "0": "Turboblaze"
        },
        "baseSpecies": "Kyurem"
    },
    "Kyurem [Form 4]": {
        "types": [
            "Dragon",
            "Ice"
        ],
        "bs": {
            "hp": 125,
            "at": 170,
            "df": 100,
            "sa": 120,
            "sd": 90,
            "sp": 95
        },
        "weightkg": 325,
        "abilities": {
            "0": "Teravolt"
        },
        "baseSpecies": "Kyurem"
    },
    "Lairon": {
        "types": [
            "Steel",
            "Rock"
        ],
        "bs": {
            "hp": 60,
            "at": 90,
            "df": 140,
            "sa": 50,
            "sd": 50,
            "sp": 40
        },
        "weightkg": 120,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Lampent": {
        "types": [
            "Ghost",
            "Fire"
        ],
        "bs": {
            "hp": 60,
            "at": 40,
            "df": 60,
            "sa": 95,
            "sd": 60,
            "sp": 55
        },
        "weightkg": 13,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Landorus": {
        "types": [
            "Ground",
            "Flying"
        ],
        "bs": {
            "hp": 89,
            "at": 125,
            "df": 90,
            "sa": 115,
            "sd": 80,
            "sp": 101
        },
        "weightkg": 68,
        "abilities": {
            "0": "Sand Force"
        },
        "otherFormes": [
            "Landorus [Therian Forme]"
        ]
    },
    "Landorus [Therian Forme]": {
        "types": [
            "Ground",
            "Flying"
        ],
        "bs": {
            "hp": 89,
            "at": 145,
            "df": 90,
            "sa": 105,
            "sd": 80,
            "sp": 91
        },
        "weightkg": 68,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Landorus"
    },
    "Lanturn": {
        "types": [
            "Water",
            "Electric"
        ],
        "bs": {
            "hp": 125,
            "at": 58,
            "df": 58,
            "sa": 76,
            "sd": 76,
            "sp": 67
        },
        "weightkg": 22.5,
        "abilities": {
            "0": "Volt Absorb"
        }
    },
    "Lapras": {
        "types": [
            "Water",
            "Ice"
        ],
        "bs": {
            "hp": 130,
            "at": 85,
            "df": 80,
            "sa": 85,
            "sd": 95,
            "sp": 60
        },
        "weightkg": 220,
        "abilities": {
            "0": "Shell Armor"
        }
    },
    "Larvesta": {
        "types": [
            "Bug",
            "Fire"
        ],
        "bs": {
            "hp": 55,
            "at": 85,
            "df": 55,
            "sa": 50,
            "sd": 55,
            "sp": 60
        },
        "weightkg": 28.8,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Larvitar": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 50,
            "at": 64,
            "df": 50,
            "sa": 45,
            "sd": 50,
            "sp": 41
        },
        "weightkg": 72,
        "abilities": {
            "0": "Guts"
        }
    },
    "Latias": {
        "types": [
            "Dragon",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 90,
            "sa": 110,
            "sd": 130,
            "sp": 110
        },
        "weightkg": 40,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Latias [Mega Latias]"
        ]
    },
    "Latias [Mega Latias]": {
        "types": [
            "Dragon",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 120,
            "sa": 140,
            "sd": 150,
            "sp": 110
        },
        "weightkg": 52,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Latias"
    },
    "Latios": {
        "types": [
            "Dragon",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 90,
            "df": 80,
            "sa": 130,
            "sd": 110,
            "sp": 110
        },
        "weightkg": 60,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Latios [Mega Latios]"
        ]
    },
    "Latios [Mega Latios]": {
        "types": [
            "Dragon",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 130,
            "df": 100,
            "sa": 160,
            "sd": 120,
            "sp": 110
        },
        "weightkg": 70,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Latios"
    },
    "Leafeon": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 65,
            "at": 110,
            "df": 130,
            "sa": 60,
            "sd": 65,
            "sp": 95
        },
        "weightkg": 25.5,
        "abilities": {
            "0": "Leaf Guard"
        }
    },
    "Leavanny": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 75,
            "at": 103,
            "df": 80,
            "sa": 70,
            "sd": 80,
            "sp": 92
        },
        "weightkg": 20.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Lechonk": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 54,
            "at": 45,
            "df": 40,
            "sa": 35,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 10.2,
        "abilities": {
            "0": "Aroma Veil"
        }
    },
    "Ledian": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 35,
            "df": 50,
            "sa": 55,
            "sd": 110,
            "sp": 85
        },
        "weightkg": 35.6,
        "abilities": {
            "0": "Rattled"
        }
    },
    "Ledyba": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 20,
            "df": 30,
            "sa": 40,
            "sd": 80,
            "sp": 55
        },
        "weightkg": 10.8,
        "abilities": {
            "0": "Rattled"
        }
    },
    "Lickilicky": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 110,
            "at": 85,
            "df": 95,
            "sa": 80,
            "sd": 95,
            "sp": 50
        },
        "weightkg": 140,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Lickitung": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 90,
            "at": 55,
            "df": 75,
            "sa": 60,
            "sd": 75,
            "sp": 30
        },
        "weightkg": 65.5,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Liepard": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 64,
            "at": 88,
            "df": 50,
            "sa": 88,
            "sd": 50,
            "sp": 106
        },
        "weightkg": 37.5,
        "abilities": {
            "0": "Limber"
        }
    },
    "Lileep": {
        "types": [
            "Rock",
            "Grass"
        ],
        "bs": {
            "hp": 66,
            "at": 41,
            "df": 77,
            "sa": 61,
            "sd": 87,
            "sp": 23
        },
        "weightkg": 23.8,
        "abilities": {
            "0": "Suction Cups"
        }
    },
    "Lilligant": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 60,
            "df": 75,
            "sa": 110,
            "sd": 75,
            "sp": 90
        },
        "weightkg": 16.3,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Lilligant [Hisuian]"
        ]
    },
    "Lilligant [Hisuian]": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 70,
            "at": 105,
            "df": 75,
            "sa": 50,
            "sd": 75,
            "sp": 105
        },
        "weightkg": 19.2,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Lilligant"
    },
    "Lillipup": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 45,
            "at": 60,
            "df": 45,
            "sa": 25,
            "sd": 45,
            "sp": 55
        },
        "weightkg": 4.1,
        "abilities": {
            "0": "Vital Spirit"
        }
    },
    "Linoone": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 78,
            "at": 70,
            "df": 61,
            "sa": 50,
            "sd": 61,
            "sp": 100
        },
        "weightkg": 32.5,
        "abilities": {
            "0": "Gluttony"
        },
        "otherFormes": [
            "Linoone [Galarian]"
        ]
    },
    "Linoone [Galarian]": {
        "types": [
            "Dark",
            "Normal"
        ],
        "bs": {
            "hp": 78,
            "at": 70,
            "df": 61,
            "sa": 50,
            "sd": 61,
            "sp": 100
        },
        "weightkg": 32.5,
        "abilities": {
            "0": "Quick Feet"
        },
        "baseSpecies": "Linoone"
    },
    "Litleo": {
        "types": [
            "Fire",
            "Normal"
        ],
        "bs": {
            "hp": 62,
            "at": 50,
            "df": 58,
            "sa": 73,
            "sd": 54,
            "sp": 72
        },
        "weightkg": 13.5,
        "abilities": {
            "0": "Unnerve"
        }
    },
    "Litten": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 45,
            "at": 65,
            "df": 40,
            "sa": 60,
            "sd": 40,
            "sp": 70
        },
        "weightkg": 4.3,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Litwick": {
        "types": [
            "Ghost",
            "Fire"
        ],
        "bs": {
            "hp": 50,
            "at": 30,
            "df": 55,
            "sa": 65,
            "sd": 55,
            "sp": 20
        },
        "weightkg": 3.1,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Lokix": {
        "types": [
            "Bug",
            "Dark"
        ],
        "bs": {
            "hp": 71,
            "at": 102,
            "df": 78,
            "sa": 52,
            "sd": 55,
            "sp": 92
        },
        "weightkg": 17.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Lombre": {
        "types": [
            "Water",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 50,
            "sa": 60,
            "sd": 70,
            "sp": 50
        },
        "weightkg": 32.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Lopunny": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 65,
            "at": 76,
            "df": 84,
            "sa": 54,
            "sd": 96,
            "sp": 105
        },
        "weightkg": 33.3,
        "abilities": {
            "0": "Cute Charm"
        },
        "otherFormes": [
            "Lopunny [Mega Lopunny]"
        ]
    },
    "Lopunny [Mega Lopunny]": {
        "types": [
            "Normal",
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 136,
            "df": 94,
            "sa": 54,
            "sd": 96,
            "sp": 135
        },
        "weightkg": 28.3,
        "abilities": {
            "0": "Scrappy"
        },
        "baseSpecies": "Lopunny"
    },
    "Lotad": {
        "types": [
            "Water",
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 30,
            "sa": 40,
            "sd": 50,
            "sp": 30
        },
        "weightkg": 2.6,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Loudred": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 84,
            "at": 71,
            "df": 43,
            "sa": 71,
            "sd": 43,
            "sp": 48
        },
        "weightkg": 40.5,
        "abilities": {
            "0": "Soundproof"
        }
    },
    "Lucario": {
        "types": [
            "Fighting",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 70,
            "sa": 115,
            "sd": 70,
            "sp": 90
        },
        "weightkg": 54,
        "abilities": {
            "0": "Steadfast"
        },
        "otherFormes": [
            "Lucario [Mega Lucario]",
            "Lucario [Mega Lucario Z]"
        ]
    },
    "Lucario [Mega Lucario]": {
        "types": [
            "Fighting",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 145,
            "df": 88,
            "sa": 140,
            "sd": 70,
            "sp": 112
        },
        "weightkg": 57.5,
        "abilities": {
            "0": "Adaptability"
        },
        "baseSpecies": "Lucario"
    },
    "Lucario [Mega Lucario Z]": {
        "types": [
            "Fighting",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 100,
            "df": 70,
            "sa": 164,
            "sd": 70,
            "sp": 151
        },
        "weightkg": 49.4,
        "abilities": {
            "0": "Aura Guard"
        },
        "baseSpecies": "Lucario"
    },
    "Ludicolo": {
        "types": [
            "Water",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 70,
            "df": 70,
            "sa": 90,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 55,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Lugia": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 106,
            "at": 90,
            "df": 130,
            "sa": 90,
            "sd": 154,
            "sp": 110
        },
        "weightkg": 216,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Lumineon": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 69,
            "at": 69,
            "df": 76,
            "sa": 69,
            "sd": 86,
            "sp": 91
        },
        "weightkg": 24,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Lunala": {
        "types": [
            "Psychic",
            "Ghost"
        ],
        "bs": {
            "hp": 137,
            "at": 113,
            "df": 89,
            "sa": 137,
            "sd": 107,
            "sp": 97
        },
        "weightkg": 120,
        "abilities": {
            "0": "Shadow Shield"
        }
    },
    "Lunatone": {
        "types": [
            "Rock",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 55,
            "df": 65,
            "sa": 95,
            "sd": 85,
            "sp": 70
        },
        "weightkg": 168,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Lurantis": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 105,
            "df": 90,
            "sa": 80,
            "sd": 90,
            "sp": 45
        },
        "weightkg": 18.5,
        "abilities": {
            "0": "Leaf Guard"
        }
    },
    "Luvdisc": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 43,
            "at": 30,
            "df": 55,
            "sa": 40,
            "sd": 65,
            "sp": 97
        },
        "weightkg": 8.7,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Luxio": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 49,
            "sa": 60,
            "sd": 49,
            "sp": 60
        },
        "weightkg": 30.5,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Luxray": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 79,
            "sa": 95,
            "sd": 79,
            "sp": 70
        },
        "weightkg": 42,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Lycanroc": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 75,
            "at": 115,
            "df": 65,
            "sa": 55,
            "sd": 65,
            "sp": 112
        },
        "weightkg": 25,
        "abilities": {
            "0": "Sand Rush"
        },
        "otherFormes": [
            "Lycanroc [Midnight Form]",
            "Lycanroc [Dusk Form]"
        ]
    },
    "Lycanroc [Midnight Form]": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 85,
            "at": 115,
            "df": 75,
            "sa": 55,
            "sd": 75,
            "sp": 82
        },
        "weightkg": 25,
        "abilities": {
            "0": "Keen Eye"
        },
        "baseSpecies": "Lycanroc"
    },
    "Lycanroc [Dusk Form]": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 75,
            "at": 117,
            "df": 65,
            "sa": 55,
            "sd": 65,
            "sp": 110
        },
        "weightkg": 25,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Lycanroc"
    },
    "Mabosstiff": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 90,
            "sa": 60,
            "sd": 70,
            "sp": 85
        },
        "weightkg": 61,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Machamp": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 90,
            "at": 130,
            "df": 80,
            "sa": 65,
            "sd": 85,
            "sp": 55
        },
        "weightkg": 130,
        "abilities": {
            "0": "Guts"
        }
    },
    "Machoke": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 70,
            "sa": 50,
            "sd": 60,
            "sp": 45
        },
        "weightkg": 70.5,
        "abilities": {
            "0": "Guts"
        }
    },
    "Machop": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 70,
            "at": 80,
            "df": 50,
            "sa": 35,
            "sd": 35,
            "sp": 35
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Guts"
        }
    },
    "Magby": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 45,
            "at": 75,
            "df": 37,
            "sa": 70,
            "sd": 55,
            "sp": 83
        },
        "weightkg": 21.4,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Magcargo": {
        "types": [
            "Fire",
            "Rock"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 120,
            "sa": 90,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 55,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Magearna": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 95,
            "df": 115,
            "sa": 130,
            "sd": 115,
            "sp": 65
        },
        "weightkg": 80.5,
        "abilities": {
            "0": "Soul-Heart"
        },
        "otherFormes": [
            "Magearna [Original Color]",
            "Magearna [Mega Magearna]",
            "Magearna [Mega Magearna (Original Color)]"
        ]
    },
    "Magearna [Original Color]": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 95,
            "df": 115,
            "sa": 130,
            "sd": 115,
            "sp": 65
        },
        "weightkg": 80.5,
        "abilities": {
            "0": "Soul-Heart"
        },
        "baseSpecies": "Magearna"
    },
    "Magearna [Mega Magearna]": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 125,
            "df": 115,
            "sa": 170,
            "sd": 115,
            "sp": 95
        },
        "weightkg": 248.1,
        "abilities": {
            "0": "Soul-Heart"
        },
        "baseSpecies": "Magearna"
    },
    "Magearna [Mega Magearna (Original Color)]": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 125,
            "df": 115,
            "sa": 170,
            "sd": 115,
            "sp": 95
        },
        "weightkg": 248.1,
        "abilities": {
            "0": "Soul-Heart"
        },
        "baseSpecies": "Magearna"
    },
    "Magikarp": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 20,
            "at": 10,
            "df": 55,
            "sa": 15,
            "sd": 20,
            "sp": 80
        },
        "weightkg": 10,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Magmar": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 95,
            "df": 57,
            "sa": 100,
            "sd": 85,
            "sp": 93
        },
        "weightkg": 44.5,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Magmortar": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 75,
            "at": 95,
            "df": 67,
            "sa": 125,
            "sd": 95,
            "sp": 83
        },
        "weightkg": 68,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Magnemite": {
        "types": [
            "Electric",
            "Steel"
        ],
        "bs": {
            "hp": 25,
            "at": 35,
            "df": 70,
            "sa": 95,
            "sd": 55,
            "sp": 45
        },
        "weightkg": 6,
        "abilities": {
            "0": "Magnet Pull"
        }
    },
    "Magneton": {
        "types": [
            "Electric",
            "Steel"
        ],
        "bs": {
            "hp": 50,
            "at": 60,
            "df": 95,
            "sa": 120,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 60,
        "abilities": {
            "0": "Magnet Pull"
        }
    },
    "Magnezone": {
        "types": [
            "Electric",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 115,
            "sa": 130,
            "sd": 90,
            "sp": 60
        },
        "weightkg": 180,
        "abilities": {
            "0": "Magnet Pull"
        }
    },
    "Makuhita": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 72,
            "at": 60,
            "df": 30,
            "sa": 20,
            "sd": 30,
            "sp": 25
        },
        "weightkg": 86.4,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Malamar": {
        "types": [
            "Dark",
            "Psychic"
        ],
        "bs": {
            "hp": 86,
            "at": 92,
            "df": 88,
            "sa": 68,
            "sd": 75,
            "sp": 73
        },
        "weightkg": 47,
        "abilities": {
            "0": "Infiltrator"
        },
        "otherFormes": [
            "Malamar [Mega Malamar]"
        ]
    },
    "Malamar [Mega Malamar]": {
        "types": [
            "Dark",
            "Psychic"
        ],
        "bs": {
            "hp": 86,
            "at": 102,
            "df": 88,
            "sa": 98,
            "sd": 120,
            "sp": 88
        },
        "weightkg": 69.8,
        "abilities": {
            "0": "Contrary"
        },
        "baseSpecies": "Malamar"
    },
    "Mamoswine": {
        "types": [
            "Ice",
            "Ground"
        ],
        "bs": {
            "hp": 110,
            "at": 130,
            "df": 80,
            "sa": 70,
            "sd": 60,
            "sp": 80
        },
        "weightkg": 291,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Manaphy": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 1.4,
        "abilities": {
            "0": "Hydration"
        }
    },
    "Mandibuzz": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 110,
            "at": 65,
            "df": 105,
            "sa": 55,
            "sd": 95,
            "sp": 80
        },
        "weightkg": 39.5,
        "abilities": {
            "0": "Big Pecks"
        }
    },
    "Manectric": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 70,
            "at": 75,
            "df": 60,
            "sa": 105,
            "sd": 60,
            "sp": 105
        },
        "weightkg": 40.2,
        "abilities": {
            "0": "Static"
        },
        "otherFormes": [
            "Manectric [Mega Manectric]"
        ]
    },
    "Manectric [Mega Manectric]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 70,
            "at": 75,
            "df": 80,
            "sa": 135,
            "sd": 80,
            "sp": 135
        },
        "weightkg": 44,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Manectric"
    },
    "Mankey": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 40,
            "at": 80,
            "df": 35,
            "sa": 35,
            "sd": 45,
            "sp": 70
        },
        "weightkg": 28,
        "abilities": {
            "0": "Vital Spirit"
        }
    },
    "Mantine": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 85,
            "at": 40,
            "df": 70,
            "sa": 80,
            "sd": 140,
            "sp": 70
        },
        "weightkg": 220,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Mantyke": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 45,
            "at": 20,
            "df": 50,
            "sa": 60,
            "sd": 120,
            "sp": 50
        },
        "weightkg": 65,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Maractus": {
        "types": [
            "Grass",
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 86,
            "df": 67,
            "sa": 106,
            "sd": 67,
            "sp": 60
        },
        "weightkg": 28,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Mareanie": {
        "types": [
            "Poison",
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 53,
            "df": 62,
            "sa": 43,
            "sd": 52,
            "sp": 45
        },
        "weightkg": 8,
        "abilities": {
            "0": "Merciless"
        }
    },
    "Mareep": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 55,
            "at": 40,
            "df": 40,
            "sa": 65,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 7.8,
        "abilities": {
            "0": "Static"
        }
    },
    "Marill": {
        "types": [
            "Water",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 20,
            "df": 50,
            "sa": 20,
            "sd": 50,
            "sp": 40
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Marowak": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 60,
            "at": 80,
            "df": 110,
            "sa": 50,
            "sd": 80,
            "sp": 45
        },
        "weightkg": 45,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Marowak [Alolan]"
        ]
    },
    "Marowak [Alolan]": {
        "types": [
            "Fire",
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 80,
            "df": 110,
            "sa": 50,
            "sd": 80,
            "sp": 45
        },
        "weightkg": 34,
        "abilities": {
            "0": "Cursed Body"
        },
        "baseSpecies": "Marowak"
    },
    "Marshadow": {
        "types": [
            "Fighting",
            "Ghost"
        ],
        "bs": {
            "hp": 90,
            "at": 125,
            "df": 80,
            "sa": 90,
            "sd": 90,
            "sp": 125
        },
        "weightkg": 22.2,
        "abilities": {
            "0": "Technician"
        }
    },
    "Marshtomp": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 50
        },
        "weightkg": 28,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Maschiff": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 60,
            "at": 78,
            "df": 60,
            "sa": 40,
            "sd": 51,
            "sp": 51
        },
        "weightkg": 16,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Masquerain": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 60,
            "df": 62,
            "sa": 100,
            "sd": 82,
            "sp": 80
        },
        "weightkg": 3.6,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Maushold": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 74,
            "at": 75,
            "df": 70,
            "sa": 65,
            "sd": 75,
            "sp": 111
        },
        "weightkg": 2.8,
        "abilities": {
            "0": "Friend Guard"
        },
        "otherFormes": [
            "Maushold [Family of Three]"
        ]
    },
    "Maushold [Family of Three]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 74,
            "at": 75,
            "df": 70,
            "sa": 65,
            "sd": 75,
            "sp": 111
        },
        "weightkg": 2.3,
        "abilities": {
            "0": "Friend Guard"
        },
        "baseSpecies": "Maushold"
    },
    "Mawile": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 85,
            "df": 85,
            "sa": 55,
            "sd": 55,
            "sp": 50
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Hyper Cutter"
        },
        "otherFormes": [
            "Mawile [Mega Mawile]"
        ]
    },
    "Mawile [Mega Mawile]": {
        "types": [
            "Steel",
            "Fairy"
        ],
        "bs": {
            "hp": 50,
            "at": 105,
            "df": 125,
            "sa": 55,
            "sd": 95,
            "sp": 50
        },
        "weightkg": 23.5,
        "abilities": {
            "0": "Huge Power"
        },
        "baseSpecies": "Mawile"
    },
    "Medicham": {
        "types": [
            "Fighting",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 75,
            "sa": 60,
            "sd": 75,
            "sp": 80
        },
        "weightkg": 31.5,
        "abilities": {
            "0": "Pure Power"
        },
        "otherFormes": [
            "Medicham [Mega Medicham]"
        ]
    },
    "Medicham [Mega Medicham]": {
        "types": [
            "Fighting",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 85,
            "sa": 80,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 31.5,
        "abilities": {
            "0": "Pure Power"
        },
        "baseSpecies": "Medicham"
    },
    "Meditite": {
        "types": [
            "Fighting",
            "Psychic"
        ],
        "bs": {
            "hp": 30,
            "at": 40,
            "df": 55,
            "sa": 40,
            "sd": 55,
            "sp": 60
        },
        "weightkg": 11.2,
        "abilities": {
            "0": "Pure Power"
        }
    },
    "Meganium": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 82,
            "df": 100,
            "sa": 83,
            "sd": 100,
            "sp": 80
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "Overgrow"
        },
        "otherFormes": [
            "Meganium [Mega Meganium]"
        ]
    },
    "Meganium [Mega Meganium]": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 92,
            "df": 115,
            "sa": 143,
            "sd": 115,
            "sp": 80
        },
        "weightkg": 201,
        "abilities": {
            "0": "Mega Sol"
        },
        "baseSpecies": "Meganium"
    },
    "Melmetal": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 135,
            "at": 143,
            "df": 143,
            "sa": 80,
            "sd": 65,
            "sp": 34
        },
        "weightkg": 800,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Meloetta": {
        "types": [
            "Normal",
            "Psychic"
        ],
        "bs": {
            "hp": 100,
            "at": 77,
            "df": 77,
            "sa": 128,
            "sd": 128,
            "sp": 90
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Serene Grace"
        },
        "otherFormes": [
            "Meloetta [Pirouette Forme]"
        ]
    },
    "Meloetta [Pirouette Forme]": {
        "types": [
            "Normal",
            "Fighting"
        ],
        "bs": {
            "hp": 100,
            "at": 128,
            "df": 90,
            "sa": 77,
            "sd": 77,
            "sp": 128
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Serene Grace"
        },
        "baseSpecies": "Meloetta"
    },
    "Meltan": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 46,
            "at": 65,
            "df": 65,
            "sa": 55,
            "sd": 35,
            "sp": 34
        },
        "weightkg": 8,
        "abilities": {
            "0": "Magnet Pull"
        }
    },
    "Meowscarada": {
        "types": [
            "Grass",
            "Dark"
        ],
        "bs": {
            "hp": 76,
            "at": 110,
            "df": 70,
            "sa": 81,
            "sd": 70,
            "sp": 123
        },
        "weightkg": 31.2,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Meowstic": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 74,
            "at": 48,
            "df": 76,
            "sa": 83,
            "sd": 81,
            "sp": 104
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Meowstic [Female]",
            "Meowstic [Mega Meowstic]",
            "Meowstic [Form 3]"
        ]
    },
    "Meowstic [Female]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 74,
            "at": 48,
            "df": 76,
            "sa": 83,
            "sd": 81,
            "sp": 104
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Keen Eye"
        },
        "baseSpecies": "Meowstic"
    },
    "Meowstic [Mega Meowstic]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 74,
            "at": 48,
            "df": 76,
            "sa": 143,
            "sd": 101,
            "sp": 124
        },
        "weightkg": 10.1,
        "abilities": {
            "0": "Trace"
        },
        "baseSpecies": "Meowstic"
    },
    "Meowstic [Form 3]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 74,
            "at": 48,
            "df": 76,
            "sa": 143,
            "sd": 101,
            "sp": 124
        },
        "weightkg": 10.1,
        "abilities": {
            "0": "Trace"
        },
        "baseSpecies": "Meowstic"
    },
    "Meowth": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 35,
            "sa": 40,
            "sd": 40,
            "sp": 90
        },
        "weightkg": 4.2,
        "abilities": {
            "0": "Technician"
        },
        "otherFormes": [
            "Meowth [Alolan]",
            "Meowth [Galarian]"
        ]
    },
    "Meowth [Alolan]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 40,
            "at": 35,
            "df": 35,
            "sa": 50,
            "sd": 40,
            "sp": 90
        },
        "weightkg": 4.2,
        "abilities": {
            "0": "Technician"
        },
        "baseSpecies": "Meowth"
    },
    "Meowth [Galarian]": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 55,
            "sa": 40,
            "sd": 40,
            "sp": 40
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Meowth"
    },
    "Mesprit": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 105,
            "df": 105,
            "sa": 105,
            "sd": 105,
            "sp": 80
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Metagross": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 135,
            "df": 130,
            "sa": 95,
            "sd": 90,
            "sp": 70
        },
        "weightkg": 550,
        "abilities": {
            "0": "Clear Body"
        },
        "otherFormes": [
            "Metagross [Mega Metagross]"
        ]
    },
    "Metagross [Mega Metagross]": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 145,
            "df": 130,
            "sa": 120,
            "sd": 90,
            "sp": 120
        },
        "weightkg": 942.9,
        "abilities": {
            "0": "Tough Claws"
        },
        "baseSpecies": "Metagross"
    },
    "Metang": {
        "types": [
            "Steel",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 75,
            "df": 100,
            "sa": 55,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 202.5,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Metapod": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 20,
            "df": 55,
            "sa": 25,
            "sd": 25,
            "sp": 30
        },
        "weightkg": 9.9,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Mew": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 4,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Mewtwo": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 106,
            "at": 110,
            "df": 90,
            "sa": 154,
            "sd": 90,
            "sp": 130
        },
        "weightkg": 122,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Mewtwo [Mega Mewtwo X]",
            "Mewtwo [Mega Mewtwo Y]"
        ]
    },
    "Mewtwo [Mega Mewtwo X]": {
        "types": [
            "Psychic",
            "Fighting"
        ],
        "bs": {
            "hp": 106,
            "at": 190,
            "df": 100,
            "sa": 154,
            "sd": 100,
            "sp": 130
        },
        "weightkg": 127,
        "abilities": {
            "0": "Steadfast"
        },
        "baseSpecies": "Mewtwo"
    },
    "Mewtwo [Mega Mewtwo Y]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 106,
            "at": 150,
            "df": 70,
            "sa": 194,
            "sd": 120,
            "sp": 140
        },
        "weightkg": 33,
        "abilities": {
            "0": "Insomnia"
        },
        "baseSpecies": "Mewtwo"
    },
    "Mienfoo": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 45,
            "at": 85,
            "df": 50,
            "sa": 55,
            "sd": 50,
            "sp": 65
        },
        "weightkg": 20,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Mienshao": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 125,
            "df": 60,
            "sa": 95,
            "sd": 60,
            "sp": 105
        },
        "weightkg": 35.5,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Mightyena": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 90,
            "df": 70,
            "sa": 60,
            "sd": 60,
            "sp": 70
        },
        "weightkg": 37,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Milcery": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 45,
            "at": 40,
            "df": 40,
            "sa": 50,
            "sd": 61,
            "sp": 34
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Milotic": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 95,
            "at": 60,
            "df": 79,
            "sa": 100,
            "sd": 125,
            "sp": 81
        },
        "weightkg": 162,
        "abilities": {
            "0": "Marvel Scale"
        }
    },
    "Miltank": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 95,
            "at": 80,
            "df": 105,
            "sa": 40,
            "sd": 70,
            "sp": 100
        },
        "weightkg": 75.5,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Mime Jr.": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 20,
            "at": 25,
            "df": 45,
            "sa": 70,
            "sd": 90,
            "sp": 60
        },
        "weightkg": 13,
        "abilities": {
            "0": "Technician"
        }
    },
    "Mimikyu": {
        "types": [
            "Ghost",
            "Fairy"
        ],
        "bs": {
            "hp": 55,
            "at": 90,
            "df": 80,
            "sa": 50,
            "sd": 105,
            "sp": 96
        },
        "weightkg": 0.7,
        "abilities": {
            "0": "Disguise"
        },
        "otherFormes": [
            "Mimikyu [Busted Form]"
        ]
    },
    "Mimikyu [Busted Form]": {
        "types": [
            "Ghost",
            "Fairy"
        ],
        "bs": {
            "hp": 55,
            "at": 90,
            "df": 80,
            "sa": 50,
            "sd": 105,
            "sp": 96
        },
        "weightkg": 0.7,
        "abilities": {
            "0": "Disguise"
        },
        "baseSpecies": "Mimikyu"
    },
    "Minccino": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 50,
            "df": 40,
            "sa": 40,
            "sd": 40,
            "sp": 75
        },
        "weightkg": 5.8,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Minior": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 100,
            "sa": 60,
            "sd": 100,
            "sp": 60
        },
        "weightkg": 40,
        "abilities": {
            "0": "Shields Down"
        },
        "otherFormes": [
            "Minior [Red Core]",
            "Minior [Orange Core]",
            "Minior [Yellow Core]",
            "Minior [Green Core]",
            "Minior [Blue Core]",
            "Minior [Indigo Core]",
            "Minior [Violet Core]"
        ]
    },
    "Minior [Red Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Orange Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Yellow Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Green Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Blue Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Indigo Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minior [Violet Core]": {
        "types": [
            "Rock",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 120
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Shields Down"
        },
        "baseSpecies": "Minior"
    },
    "Minun": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 40,
            "df": 50,
            "sa": 75,
            "sd": 85,
            "sp": 95
        },
        "weightkg": 4.2,
        "abilities": {
            "0": "Static"
        }
    },
    "Miraidon": {
        "types": [
            "Electric",
            "Dragon"
        ],
        "bs": {
            "hp": 100,
            "at": 85,
            "df": 100,
            "sa": 135,
            "sd": 115,
            "sp": 135
        },
        "weightkg": 240,
        "abilities": {
            "0": "Hadron Engine"
        }
    },
    "Misdreavus": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 60,
            "sa": 85,
            "sd": 85,
            "sp": 85
        },
        "weightkg": 1,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Mismagius": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 60,
            "sa": 105,
            "sd": 105,
            "sp": 105
        },
        "weightkg": 4.4,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Moltres": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 90,
            "sa": 125,
            "sd": 85,
            "sp": 90
        },
        "weightkg": 60,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Moltres [Galarian]"
        ]
    },
    "Moltres [Galarian]": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 85,
            "df": 90,
            "sa": 100,
            "sd": 125,
            "sp": 90
        },
        "weightkg": 66,
        "abilities": {
            "0": "Berserk"
        },
        "baseSpecies": "Moltres"
    },
    "Monferno": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 64,
            "at": 78,
            "df": 52,
            "sa": 78,
            "sd": 52,
            "sp": 81
        },
        "weightkg": 22,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Morelull": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 40,
            "at": 35,
            "df": 55,
            "sa": 65,
            "sd": 75,
            "sp": 15
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Illuminate"
        }
    },
    "Morgrem": {
        "types": [
            "Dark",
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 45,
            "sa": 75,
            "sd": 55,
            "sp": 70
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Morpeko": {
        "types": [
            "Electric",
            "Dark"
        ],
        "bs": {
            "hp": 58,
            "at": 95,
            "df": 58,
            "sa": 70,
            "sd": 58,
            "sp": 97
        },
        "weightkg": 3,
        "abilities": {
            "0": "Hunger Switch"
        },
        "otherFormes": [
            "Morpeko [Hangry Mode]"
        ]
    },
    "Morpeko [Hangry Mode]": {
        "types": [
            "Electric",
            "Dark"
        ],
        "bs": {
            "hp": 58,
            "at": 95,
            "df": 58,
            "sa": 70,
            "sd": 58,
            "sp": 97
        },
        "weightkg": 3,
        "abilities": {
            "0": "Hunger Switch"
        },
        "baseSpecies": "Morpeko"
    },
    "Mothim": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 94,
            "df": 50,
            "sa": 94,
            "sd": 50,
            "sp": 66
        },
        "weightkg": 23.3,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Mr. Mime": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 65,
            "sa": 100,
            "sd": 120,
            "sp": 90
        },
        "weightkg": 54.5,
        "abilities": {
            "0": "Technician"
        },
        "otherFormes": [
            "Mr. Mime [Galarian]"
        ]
    },
    "Mr. Mime [Galarian]": {
        "types": [
            "Ice",
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 65,
            "sa": 90,
            "sd": 90,
            "sp": 100
        },
        "weightkg": 56.8,
        "abilities": {
            "0": "Vital Spirit"
        },
        "baseSpecies": "Mr. Mime"
    },
    "Mr. Rime": {
        "types": [
            "Ice",
            "Psychic"
        ],
        "bs": {
            "hp": 80,
            "at": 85,
            "df": 75,
            "sa": 110,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 58.2,
        "abilities": {
            "0": "Tangled Feet"
        }
    },
    "Mudbray": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 100,
            "df": 70,
            "sa": 45,
            "sd": 55,
            "sp": 45
        },
        "weightkg": 110,
        "abilities": {
            "0": "Tangling Hair"
        }
    },
    "Mudkip": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 70,
            "df": 50,
            "sa": 50,
            "sd": 50,
            "sp": 40
        },
        "weightkg": 7.6,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Mudsdale": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 100,
            "at": 125,
            "df": 100,
            "sa": 55,
            "sd": 85,
            "sp": 35
        },
        "weightkg": 920,
        "abilities": {
            "0": "Tangling Hair"
        }
    },
    "Muk": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 105,
            "at": 105,
            "df": 75,
            "sa": 65,
            "sd": 100,
            "sp": 50
        },
        "weightkg": 30,
        "abilities": {
            "0": "Poison Touch"
        },
        "otherFormes": [
            "Muk [Alolan]"
        ]
    },
    "Muk [Alolan]": {
        "types": [
            "Poison",
            "Dark"
        ],
        "bs": {
            "hp": 105,
            "at": 105,
            "df": 75,
            "sa": 65,
            "sd": 100,
            "sp": 50
        },
        "weightkg": 52,
        "abilities": {
            "0": "Poison Touch"
        },
        "baseSpecies": "Muk"
    },
    "Munchlax": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 135,
            "at": 85,
            "df": 40,
            "sa": 40,
            "sd": 85,
            "sp": 5
        },
        "weightkg": 105,
        "abilities": {
            "0": "Immunity"
        }
    },
    "Munkidori": {
        "types": [
            "Poison",
            "Psychic"
        ],
        "bs": {
            "hp": 88,
            "at": 75,
            "df": 66,
            "sa": 130,
            "sd": 90,
            "sp": 106
        },
        "weightkg": 12.2,
        "abilities": {
            "0": "Toxic Chain"
        }
    },
    "Munna": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 76,
            "at": 25,
            "df": 45,
            "sa": 67,
            "sd": 55,
            "sp": 24
        },
        "weightkg": 23.3,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Murkrow": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 42,
            "sa": 85,
            "sd": 42,
            "sp": 91
        },
        "weightkg": 2.1,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Musharna": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 116,
            "at": 55,
            "df": 85,
            "sa": 107,
            "sd": 95,
            "sp": 29
        },
        "weightkg": 60.5,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Nacli": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 75,
            "sa": 35,
            "sd": 35,
            "sp": 25
        },
        "weightkg": 16,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Naclstack": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 100,
            "sa": 35,
            "sd": 65,
            "sp": 35
        },
        "weightkg": 105,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Naganadel": {
        "types": [
            "Poison",
            "Dragon"
        ],
        "bs": {
            "hp": 73,
            "at": 73,
            "df": 73,
            "sa": 127,
            "sd": 73,
            "sp": 121
        },
        "weightkg": 150,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Natu": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 50,
            "df": 45,
            "sa": 70,
            "sd": 45,
            "sp": 70
        },
        "weightkg": 2,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Necrozma": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 97,
            "at": 107,
            "df": 101,
            "sa": 127,
            "sd": 89,
            "sp": 79
        },
        "weightkg": 230,
        "abilities": {
            "0": "Prism Armor"
        },
        "otherFormes": [
            "Necrozma [Dusk Mane]",
            "Necrozma [Dawn Wings]",
            "Necrozma [Ultra Necrozma]",
            "Necrozma [Form 4]"
        ]
    },
    "Necrozma [Dusk Mane]": {
        "types": [
            "Psychic",
            "Steel"
        ],
        "bs": {
            "hp": 97,
            "at": 157,
            "df": 127,
            "sa": 113,
            "sd": 109,
            "sp": 77
        },
        "weightkg": 460,
        "abilities": {
            "0": "Prism Armor"
        },
        "baseSpecies": "Necrozma"
    },
    "Necrozma [Dawn Wings]": {
        "types": [
            "Psychic",
            "Ghost"
        ],
        "bs": {
            "hp": 97,
            "at": 113,
            "df": 109,
            "sa": 157,
            "sd": 127,
            "sp": 77
        },
        "weightkg": 350,
        "abilities": {
            "0": "Prism Armor"
        },
        "baseSpecies": "Necrozma"
    },
    "Necrozma [Ultra Necrozma]": {
        "types": [
            "Psychic",
            "Dragon"
        ],
        "bs": {
            "hp": 97,
            "at": 167,
            "df": 97,
            "sa": 167,
            "sd": 97,
            "sp": 129
        },
        "weightkg": 230,
        "abilities": {
            "0": "Neuroforce"
        },
        "baseSpecies": "Necrozma"
    },
    "Necrozma [Form 4]": {
        "types": [
            "Psychic",
            "Dragon"
        ],
        "bs": {
            "hp": 97,
            "at": 167,
            "df": 97,
            "sa": 167,
            "sd": 97,
            "sp": 129
        },
        "weightkg": 230,
        "abilities": {
            "0": "Neuroforce"
        },
        "baseSpecies": "Necrozma"
    },
    "Nickit": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 40,
            "at": 28,
            "df": 28,
            "sa": 47,
            "sd": 52,
            "sp": 50
        },
        "weightkg": 8.9,
        "abilities": {
            "0": "Unburden"
        }
    },
    "Nidoking": {
        "types": [
            "Poison",
            "Ground"
        ],
        "bs": {
            "hp": 81,
            "at": 102,
            "df": 77,
            "sa": 85,
            "sd": 75,
            "sp": 85
        },
        "weightkg": 62,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nidoqueen": {
        "types": [
            "Poison",
            "Ground"
        ],
        "bs": {
            "hp": 90,
            "at": 92,
            "df": 87,
            "sa": 75,
            "sd": 85,
            "sp": 76
        },
        "weightkg": 60,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nidoran♀": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 55,
            "at": 47,
            "df": 52,
            "sa": 40,
            "sd": 40,
            "sp": 41
        },
        "weightkg": 7,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nidoran♂": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 46,
            "at": 57,
            "df": 40,
            "sa": 40,
            "sd": 40,
            "sp": 50
        },
        "weightkg": 9,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nidorina": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 70,
            "at": 62,
            "df": 67,
            "sa": 55,
            "sd": 55,
            "sp": 56
        },
        "weightkg": 20,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nidorino": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 61,
            "at": 72,
            "df": 57,
            "sa": 55,
            "sd": 55,
            "sp": 65
        },
        "weightkg": 19.5,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Nihilego": {
        "types": [
            "Rock",
            "Poison"
        ],
        "bs": {
            "hp": 109,
            "at": 53,
            "df": 47,
            "sa": 127,
            "sd": 131,
            "sp": 103
        },
        "weightkg": 55.5,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Nincada": {
        "types": [
            "Bug",
            "Ground"
        ],
        "bs": {
            "hp": 31,
            "at": 45,
            "df": 90,
            "sa": 30,
            "sd": 30,
            "sp": 40
        },
        "weightkg": 5.5,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Ninetales": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 73,
            "at": 76,
            "df": 75,
            "sa": 81,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 19.9,
        "abilities": {
            "0": "Magic Guard"
        },
        "otherFormes": [
            "Ninetales [Alolan]"
        ]
    },
    "Ninetales [Alolan]": {
        "types": [
            "Ice",
            "Fairy"
        ],
        "bs": {
            "hp": 73,
            "at": 67,
            "df": 75,
            "sa": 81,
            "sd": 100,
            "sp": 109
        },
        "weightkg": 19.9,
        "abilities": {
            "0": "Snow Cloak"
        },
        "baseSpecies": "Ninetales"
    },
    "Ninjask": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 61,
            "at": 90,
            "df": 45,
            "sa": 50,
            "sd": 50,
            "sp": 160
        },
        "weightkg": 12,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Noctowl": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 100,
            "at": 50,
            "df": 50,
            "sa": 86,
            "sd": 96,
            "sp": 70
        },
        "weightkg": 40.8,
        "abilities": {
            "0": "Tinted Lens"
        }
    },
    "Noibat": {
        "types": [
            "Flying",
            "Dragon"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 35,
            "sa": 45,
            "sd": 40,
            "sp": 55
        },
        "weightkg": 8,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Noivern": {
        "types": [
            "Flying",
            "Dragon"
        ],
        "bs": {
            "hp": 85,
            "at": 70,
            "df": 80,
            "sa": 97,
            "sd": 80,
            "sp": 123
        },
        "weightkg": 85,
        "abilities": {
            "0": "Infiltrator"
        }
    },
    "Nosepass": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 30,
            "at": 45,
            "df": 135,
            "sa": 45,
            "sd": 90,
            "sp": 30
        },
        "weightkg": 97,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Numel": {
        "types": [
            "Fire",
            "Ground"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 40,
            "sa": 65,
            "sd": 45,
            "sp": 35
        },
        "weightkg": 24,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Nuzleaf": {
        "types": [
            "Grass",
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 70,
            "df": 40,
            "sa": 60,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 28,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Nymble": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 33,
            "at": 46,
            "df": 40,
            "sa": 21,
            "sd": 25,
            "sp": 45
        },
        "weightkg": 1,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Obstagoon": {
        "types": [
            "Dark",
            "Normal"
        ],
        "bs": {
            "hp": 93,
            "at": 90,
            "df": 101,
            "sa": 60,
            "sd": 81,
            "sp": 95
        },
        "weightkg": 46,
        "abilities": {
            "0": "Reckless"
        }
    },
    "Octillery": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 105,
            "df": 75,
            "sa": 105,
            "sd": 75,
            "sp": 45
        },
        "weightkg": 28.5,
        "abilities": {
            "0": "Suction Cups"
        }
    },
    "Oddish": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 45,
            "at": 50,
            "df": 55,
            "sa": 75,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 5.4,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Ogerpon": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Defiant"
        },
        "otherFormes": [
            "Ogerpon [Wellspring Mask]",
            "Ogerpon [Hearthflame Mask]",
            "Ogerpon [Cornerstone Mask]",
            "Ogerpon [Form 4]",
            "Ogerpon [Wellspring Mask] [Form 5]",
            "Ogerpon [Hearthflame Mask] [Form 6]",
            "Ogerpon [Cornerstone Mask] [Form 7]",
            "Ogerpon [Terastal Teal Mask]",
            "Ogerpon [Terastal Wellspring Mask]",
            "Ogerpon [Terastal Hearthflame Mask]",
            "Ogerpon [Terastal Cornerstone Mask]"
        ]
    },
    "Ogerpon [Wellspring Mask]": {
        "types": [
            "Grass",
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Water Absorb"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Hearthflame Mask]": {
        "types": [
            "Grass",
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Mold Breaker"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Cornerstone Mask]": {
        "types": [
            "Grass",
            "Rock"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Sturdy"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Form 4]": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Defiant"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Wellspring Mask] [Form 5]": {
        "types": [
            "Grass",
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Water Absorb"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Hearthflame Mask] [Form 6]": {
        "types": [
            "Grass",
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Mold Breaker"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Cornerstone Mask] [Form 7]": {
        "types": [
            "Grass",
            "Rock"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Sturdy"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Terastal Teal Mask]": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Embody Aspect"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Terastal Wellspring Mask]": {
        "types": [
            "Grass",
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Embody Aspect"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Terastal Hearthflame Mask]": {
        "types": [
            "Grass",
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Embody Aspect"
        },
        "baseSpecies": "Ogerpon"
    },
    "Ogerpon [Terastal Cornerstone Mask]": {
        "types": [
            "Grass",
            "Rock"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 84,
            "sa": 60,
            "sd": 96,
            "sp": 110
        },
        "weightkg": 39.8,
        "abilities": {
            "0": "Embody Aspect"
        },
        "baseSpecies": "Ogerpon"
    },
    "Oinkologne": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 110,
            "at": 100,
            "df": 75,
            "sa": 59,
            "sd": 80,
            "sp": 65
        },
        "weightkg": 120,
        "abilities": {
            "0": "Aroma Veil"
        },
        "otherFormes": [
            "Oinkologne [Female]"
        ]
    },
    "Oinkologne [Female]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 115,
            "at": 90,
            "df": 70,
            "sa": 59,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 120,
        "abilities": {
            "0": "Aroma Veil"
        },
        "baseSpecies": "Oinkologne"
    },
    "Okidogi": {
        "types": [
            "Poison",
            "Fighting"
        ],
        "bs": {
            "hp": 88,
            "at": 128,
            "df": 115,
            "sa": 58,
            "sd": 86,
            "sp": 80
        },
        "weightkg": 92,
        "abilities": {
            "0": "Toxic Chain"
        }
    },
    "Omanyte": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 35,
            "at": 40,
            "df": 100,
            "sa": 90,
            "sd": 55,
            "sp": 35
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Omastar": {
        "types": [
            "Rock",
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 60,
            "df": 125,
            "sa": 115,
            "sd": 70,
            "sp": 55
        },
        "weightkg": 35,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Onix": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 35,
            "at": 45,
            "df": 160,
            "sa": 30,
            "sd": 45,
            "sp": 70
        },
        "weightkg": 210,
        "abilities": {
            "0": "Rock Head"
        }
    },
    "Oranguru": {
        "types": [
            "Normal",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 60,
            "df": 80,
            "sa": 90,
            "sd": 110,
            "sp": 60
        },
        "weightkg": 76,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Orbeetle": {
        "types": [
            "Bug",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 45,
            "df": 110,
            "sa": 80,
            "sd": 120,
            "sp": 90
        },
        "weightkg": 40.8,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Oricorio": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 70,
            "df": 70,
            "sa": 98,
            "sd": 70,
            "sp": 93
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Dancer"
        },
        "otherFormes": [
            "Oricorio [Pom-Pom Style]",
            "Oricorio [Pa'u Style]",
            "Oricorio [Sensu Style]"
        ]
    },
    "Oricorio [Pom-Pom Style]": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 70,
            "df": 70,
            "sa": 98,
            "sd": 70,
            "sp": 93
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Dancer"
        },
        "baseSpecies": "Oricorio"
    },
    "Oricorio [Pa'u Style]": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 70,
            "df": 70,
            "sa": 98,
            "sd": 70,
            "sp": 93
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Dancer"
        },
        "baseSpecies": "Oricorio"
    },
    "Oricorio [Sensu Style]": {
        "types": [
            "Ghost",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 70,
            "df": 70,
            "sa": 98,
            "sd": 70,
            "sp": 93
        },
        "weightkg": 3.4,
        "abilities": {
            "0": "Dancer"
        },
        "baseSpecies": "Oricorio"
    },
    "Orthworm": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 145,
            "sa": 60,
            "sd": 55,
            "sp": 65
        },
        "weightkg": 310,
        "abilities": {
            "0": "Sand Force"
        }
    },
    "Oshawott": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 45,
            "sa": 63,
            "sd": 45,
            "sp": 45
        },
        "weightkg": 5.9,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Overqwil": {
        "types": [
            "Dark",
            "Poison"
        ],
        "bs": {
            "hp": 85,
            "at": 115,
            "df": 95,
            "sa": 65,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 60.5,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Pachirisu": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 45,
            "df": 70,
            "sa": 45,
            "sd": 90,
            "sp": 95
        },
        "weightkg": 3.9,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Palafin": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 70,
            "df": 72,
            "sa": 53,
            "sd": 62,
            "sp": 100
        },
        "weightkg": 60.2,
        "abilities": {
            "0": "Zero to Hero"
        },
        "otherFormes": [
            "Palafin [Hero Form]"
        ]
    },
    "Palafin [Hero Form]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 160,
            "df": 97,
            "sa": 106,
            "sd": 87,
            "sp": 100
        },
        "weightkg": 97.4,
        "abilities": {
            "0": "Zero to Hero"
        },
        "baseSpecies": "Palafin"
    },
    "Palkia": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 120,
            "df": 100,
            "sa": 150,
            "sd": 120,
            "sp": 100
        },
        "weightkg": 336,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Palkia [Origin Forme]"
        ]
    },
    "Palkia [Origin Forme]": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 100,
            "sa": 150,
            "sd": 120,
            "sp": 120
        },
        "weightkg": 659,
        "abilities": {
            "0": "Pressure"
        },
        "baseSpecies": "Palkia"
    },
    "Palossand": {
        "types": [
            "Ghost",
            "Ground"
        ],
        "bs": {
            "hp": 85,
            "at": 75,
            "df": 110,
            "sa": 100,
            "sd": 75,
            "sp": 35
        },
        "weightkg": 250,
        "abilities": {
            "0": "Cursed Body"
        }
    },
    "Palpitoad": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 75,
            "at": 65,
            "df": 55,
            "sa": 65,
            "sd": 55,
            "sp": 69
        },
        "weightkg": 17,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Pancham": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 67,
            "at": 82,
            "df": 62,
            "sa": 46,
            "sd": 48,
            "sp": 43
        },
        "weightkg": 8,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Pangoro": {
        "types": [
            "Fighting",
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 124,
            "df": 78,
            "sa": 69,
            "sd": 71,
            "sp": 58
        },
        "weightkg": 136,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Panpour": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 53,
            "df": 48,
            "sa": 53,
            "sd": 48,
            "sp": 64
        },
        "weightkg": 13.5,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Pansage": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 53,
            "df": 48,
            "sa": 53,
            "sd": 48,
            "sp": 64
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Pansear": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 50,
            "at": 53,
            "df": 48,
            "sa": 53,
            "sd": 48,
            "sp": 64
        },
        "weightkg": 11,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Paras": {
        "types": [
            "Bug",
            "Grass"
        ],
        "bs": {
            "hp": 35,
            "at": 70,
            "df": 55,
            "sa": 45,
            "sd": 55,
            "sp": 25
        },
        "weightkg": 5.4,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Parasect": {
        "types": [
            "Bug",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 95,
            "df": 80,
            "sa": 60,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 29.5,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Passimian": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 100,
            "at": 120,
            "df": 90,
            "sa": 40,
            "sd": 60,
            "sp": 80
        },
        "weightkg": 82.8,
        "abilities": {
            "0": "Receiver"
        }
    },
    "Patrat": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 45,
            "at": 55,
            "df": 39,
            "sa": 35,
            "sd": 39,
            "sp": 42
        },
        "weightkg": 11.6,
        "abilities": {
            "0": "Run Away"
        }
    },
    "Pawmi": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 45,
            "at": 50,
            "df": 20,
            "sa": 40,
            "sd": 25,
            "sp": 60
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Static"
        }
    },
    "Pawmo": {
        "types": [
            "Electric",
            "Fighting"
        ],
        "bs": {
            "hp": 60,
            "at": 75,
            "df": 40,
            "sa": 50,
            "sd": 40,
            "sp": 85
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Pawmot": {
        "types": [
            "Electric",
            "Fighting"
        ],
        "bs": {
            "hp": 70,
            "at": 115,
            "df": 70,
            "sa": 70,
            "sd": 60,
            "sp": 105
        },
        "weightkg": 41,
        "abilities": {
            "0": "Iron Fist"
        }
    },
    "Pawniard": {
        "types": [
            "Dark",
            "Steel"
        ],
        "bs": {
            "hp": 45,
            "at": 85,
            "df": 70,
            "sa": 40,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 10.2,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Pecharunt": {
        "types": [
            "Poison",
            "Ghost"
        ],
        "bs": {
            "hp": 88,
            "at": 88,
            "df": 160,
            "sa": 88,
            "sd": 88,
            "sp": 88
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Poison Puppeteer"
        }
    },
    "Pelipper": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 100,
            "sa": 95,
            "sd": 70,
            "sp": 65
        },
        "weightkg": 28,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Perrserker": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 100,
            "sa": 50,
            "sd": 60,
            "sp": 50
        },
        "weightkg": 28,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Persian": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 65,
            "at": 70,
            "df": 60,
            "sa": 65,
            "sd": 65,
            "sp": 115
        },
        "weightkg": 32,
        "abilities": {
            "0": "Technician"
        },
        "otherFormes": [
            "Persian [Alolan]"
        ]
    },
    "Persian [Alolan]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 60,
            "sa": 75,
            "sd": 65,
            "sp": 115
        },
        "weightkg": 33,
        "abilities": {
            "0": "Fur Coat"
        },
        "baseSpecies": "Persian"
    },
    "Petilil": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 45,
            "at": 35,
            "df": 50,
            "sa": 70,
            "sd": 50,
            "sp": 30
        },
        "weightkg": 6.6,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Phanpy": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 90,
            "at": 60,
            "df": 60,
            "sa": 40,
            "sd": 40,
            "sp": 40
        },
        "weightkg": 33.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Phantump": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 43,
            "at": 70,
            "df": 48,
            "sa": 50,
            "sd": 60,
            "sp": 38
        },
        "weightkg": 7,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Pheromosa": {
        "types": [
            "Bug",
            "Fighting"
        ],
        "bs": {
            "hp": 71,
            "at": 137,
            "df": 37,
            "sa": 137,
            "sd": 37,
            "sp": 151
        },
        "weightkg": 25,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Phione": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 80,
            "sa": 80,
            "sd": 80,
            "sp": 80
        },
        "weightkg": 3.1,
        "abilities": {
            "0": "Hydration"
        }
    },
    "Pichu": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 20,
            "at": 40,
            "df": 15,
            "sa": 35,
            "sd": 35,
            "sp": 60
        },
        "weightkg": 2,
        "abilities": {
            "0": "Static"
        },
        "otherFormes": [
            "Pichu [Spiky-Eared]"
        ]
    },
    "Pichu [Spiky-Eared]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 20,
            "at": 40,
            "df": 15,
            "sa": 35,
            "sd": 35,
            "sp": 60
        },
        "weightkg": 2,
        "abilities": {
            "0": "Static"
        },
        "baseSpecies": "Pichu"
    },
    "Pidgeot": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 83,
            "at": 80,
            "df": 75,
            "sa": 70,
            "sd": 70,
            "sp": 101
        },
        "weightkg": 39.5,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Pidgeot [Mega Pidgeot]"
        ]
    },
    "Pidgeot [Mega Pidgeot]": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 83,
            "at": 80,
            "df": 80,
            "sa": 135,
            "sd": 80,
            "sp": 121
        },
        "weightkg": 50.5,
        "abilities": {
            "0": "No Guard"
        },
        "baseSpecies": "Pidgeot"
    },
    "Pidgeotto": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 63,
            "at": 60,
            "df": 55,
            "sa": 50,
            "sd": 50,
            "sp": 71
        },
        "weightkg": 30,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Pidgey": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 40,
            "sa": 35,
            "sd": 35,
            "sp": 56
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Pidove": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 50,
            "at": 55,
            "df": 50,
            "sa": 36,
            "sd": 30,
            "sp": 43
        },
        "weightkg": 2.1,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Pignite": {
        "types": [
            "Fire",
            "Fighting"
        ],
        "bs": {
            "hp": 90,
            "at": 93,
            "df": 55,
            "sa": 70,
            "sd": 55,
            "sp": 55
        },
        "weightkg": 55.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Pikachu": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 35,
            "at": 55,
            "df": 40,
            "sa": 50,
            "sd": 50,
            "sp": 90
        },
        "weightkg": 6,
        "abilities": {
            "0": "Static"
        }
    },
    "Pikipek": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 35,
            "at": 75,
            "df": 30,
            "sa": 30,
            "sd": 30,
            "sp": 65
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Piloswine": {
        "types": [
            "Ice",
            "Ground"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 80,
            "sa": 60,
            "sd": 60,
            "sp": 50
        },
        "weightkg": 55.8,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Pincurchin": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 48,
            "at": 101,
            "df": 95,
            "sa": 91,
            "sd": 85,
            "sp": 15
        },
        "weightkg": 1,
        "abilities": {
            "0": "Static"
        }
    },
    "Pineco": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 90,
            "sa": 35,
            "sd": 35,
            "sp": 15
        },
        "weightkg": 7.2,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Pinsir": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 65,
            "at": 125,
            "df": 100,
            "sa": 55,
            "sd": 70,
            "sp": 85
        },
        "weightkg": 55,
        "abilities": {
            "0": "Hyper Cutter"
        },
        "otherFormes": [
            "Pinsir [Mega Pinsir]"
        ]
    },
    "Pinsir [Mega Pinsir]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 155,
            "df": 120,
            "sa": 65,
            "sd": 90,
            "sp": 105
        },
        "weightkg": 59,
        "abilities": {
            "0": "Aerilate"
        },
        "baseSpecies": "Pinsir"
    },
    "Piplup": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 53,
            "at": 51,
            "df": 53,
            "sa": 61,
            "sd": 56,
            "sp": 40
        },
        "weightkg": 5.2,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Plusle": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 50,
            "df": 40,
            "sa": 85,
            "sd": 75,
            "sp": 95
        },
        "weightkg": 4.2,
        "abilities": {
            "0": "Static"
        }
    },
    "Poipole": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 67,
            "at": 73,
            "df": 67,
            "sa": 73,
            "sd": 67,
            "sp": 73
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Politoed": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 90,
            "at": 75,
            "df": 75,
            "sa": 90,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 33.9,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Poliwag": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 40,
            "at": 50,
            "df": 40,
            "sa": 40,
            "sd": 40,
            "sp": 90
        },
        "weightkg": 12.4,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Poliwhirl": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 65,
            "at": 65,
            "df": 65,
            "sa": 50,
            "sd": 50,
            "sp": 90
        },
        "weightkg": 20,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Poliwrath": {
        "types": [
            "Water",
            "Fighting"
        ],
        "bs": {
            "hp": 90,
            "at": 95,
            "df": 95,
            "sa": 70,
            "sd": 90,
            "sp": 70
        },
        "weightkg": 54,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Poltchageist": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 45,
            "sa": 74,
            "sd": 54,
            "sp": 50
        },
        "weightkg": 1.1,
        "abilities": {
            "0": "Hospitality"
        },
        "otherFormes": [
            "Poltchageist [Artisan Form]"
        ]
    },
    "Poltchageist [Artisan Form]": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 45,
            "sa": 74,
            "sd": 54,
            "sp": 50
        },
        "weightkg": 1.1,
        "abilities": {
            "0": "Hospitality"
        },
        "baseSpecies": "Poltchageist"
    },
    "Polteageist": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 65,
            "sa": 134,
            "sd": 114,
            "sp": 70
        },
        "weightkg": 0.4,
        "abilities": {
            "0": "Cursed Body"
        },
        "otherFormes": [
            "Polteageist [Antique Form]"
        ]
    },
    "Polteageist [Antique Form]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 60,
            "at": 65,
            "df": 65,
            "sa": 134,
            "sd": 114,
            "sp": 70
        },
        "weightkg": 0.4,
        "abilities": {
            "0": "Cursed Body"
        },
        "baseSpecies": "Polteageist"
    },
    "Ponyta": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 50,
            "at": 85,
            "df": 55,
            "sa": 65,
            "sd": 65,
            "sp": 90
        },
        "weightkg": 30,
        "abilities": {
            "0": "Flame Body"
        },
        "otherFormes": [
            "Ponyta [Galarian]"
        ]
    },
    "Ponyta [Galarian]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 50,
            "at": 85,
            "df": 55,
            "sa": 65,
            "sd": 65,
            "sp": 90
        },
        "weightkg": 24,
        "abilities": {
            "0": "Pastel Veil"
        },
        "baseSpecies": "Ponyta"
    },
    "Poochyena": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 35,
            "at": 55,
            "df": 35,
            "sa": 30,
            "sd": 30,
            "sp": 35
        },
        "weightkg": 13.6,
        "abilities": {
            "0": "Quick Feet"
        }
    },
    "Popplio": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 54,
            "df": 54,
            "sa": 66,
            "sd": 56,
            "sp": 40
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Porygon": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 65,
            "at": 60,
            "df": 70,
            "sa": 85,
            "sd": 75,
            "sp": 40
        },
        "weightkg": 36.5,
        "abilities": {
            "0": "Trace"
        }
    },
    "Porygon2": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 85,
            "at": 80,
            "df": 90,
            "sa": 105,
            "sd": 95,
            "sp": 60
        },
        "weightkg": 32.5,
        "abilities": {
            "0": "Trace"
        }
    },
    "Porygon-Z": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 85,
            "at": 80,
            "df": 70,
            "sa": 135,
            "sd": 75,
            "sp": 90
        },
        "weightkg": 34,
        "abilities": {
            "0": "Adaptability"
        }
    },
    "Primarina": {
        "types": [
            "Water",
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 74,
            "df": 74,
            "sa": 126,
            "sd": 116,
            "sp": 60
        },
        "weightkg": 44,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Primeape": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 105,
            "df": 60,
            "sa": 60,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 32,
        "abilities": {
            "0": "Vital Spirit"
        }
    },
    "Prinplup": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 64,
            "at": 66,
            "df": 68,
            "sa": 81,
            "sd": 76,
            "sp": 50
        },
        "weightkg": 23,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Probopass": {
        "types": [
            "Rock",
            "Steel"
        ],
        "bs": {
            "hp": 60,
            "at": 55,
            "df": 145,
            "sa": 75,
            "sd": 150,
            "sp": 40
        },
        "weightkg": 340,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Psyduck": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 52,
            "df": 48,
            "sa": 65,
            "sd": 50,
            "sp": 55
        },
        "weightkg": 19.6,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Pumpkaboo": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 44,
            "at": 66,
            "df": 70,
            "sa": 44,
            "sd": 55,
            "sp": 56
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Frisk"
        },
        "otherFormes": [
            "Pumpkaboo [Average Size]",
            "Pumpkaboo [Large Size]",
            "Pumpkaboo [Super Size]"
        ]
    },
    "Pumpkaboo [Average Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 49,
            "at": 66,
            "df": 70,
            "sa": 44,
            "sd": 55,
            "sp": 51
        },
        "weightkg": 5,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Pumpkaboo"
    },
    "Pumpkaboo [Large Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 54,
            "at": 66,
            "df": 70,
            "sa": 44,
            "sd": 55,
            "sp": 46
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Pumpkaboo"
    },
    "Pumpkaboo [Super Size]": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 59,
            "at": 66,
            "df": 70,
            "sa": 44,
            "sd": 55,
            "sp": 41
        },
        "weightkg": 15,
        "abilities": {
            "0": "Frisk"
        },
        "baseSpecies": "Pumpkaboo"
    },
    "Pupitar": {
        "types": [
            "Rock",
            "Ground"
        ],
        "bs": {
            "hp": 70,
            "at": 84,
            "df": 70,
            "sa": 65,
            "sd": 70,
            "sp": 51
        },
        "weightkg": 152,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Purrloin": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 41,
            "at": 50,
            "df": 37,
            "sa": 50,
            "sd": 37,
            "sp": 66
        },
        "weightkg": 10.1,
        "abilities": {
            "0": "Limber"
        }
    },
    "Purugly": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 71,
            "at": 82,
            "df": 64,
            "sa": 64,
            "sd": 59,
            "sp": 112
        },
        "weightkg": 43.8,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Pyroar": {
        "types": [
            "Fire",
            "Normal"
        ],
        "bs": {
            "hp": 86,
            "at": 68,
            "df": 72,
            "sa": 109,
            "sd": 66,
            "sp": 106
        },
        "weightkg": 81.5,
        "abilities": {
            "0": "Unnerve"
        },
        "otherFormes": [
            "Pyroar [Mega Pyroar]"
        ]
    },
    "Pyroar [Mega Pyroar]": {
        "types": [
            "Fire",
            "Normal"
        ],
        "bs": {
            "hp": 86,
            "at": 88,
            "df": 92,
            "sa": 129,
            "sd": 86,
            "sp": 126
        },
        "weightkg": 93.3,
        "abilities": {
            "0": "Fire Mane"
        },
        "baseSpecies": "Pyroar"
    },
    "Pyukumuku": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 60,
            "df": 130,
            "sa": 30,
            "sd": 130,
            "sp": 5
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Quagsire": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 95,
            "at": 85,
            "df": 85,
            "sa": 65,
            "sd": 65,
            "sp": 35
        },
        "weightkg": 75,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Quaquaval": {
        "types": [
            "Water",
            "Fighting"
        ],
        "bs": {
            "hp": 85,
            "at": 120,
            "df": 80,
            "sa": 85,
            "sd": 75,
            "sp": 85
        },
        "weightkg": 61.9,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Quaxly": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 65,
            "df": 45,
            "sa": 50,
            "sd": 45,
            "sp": 50
        },
        "weightkg": 6.1,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Quaxwell": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 65,
            "sa": 65,
            "sd": 60,
            "sp": 65
        },
        "weightkg": 21.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Quilava": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 58,
            "at": 64,
            "df": 58,
            "sa": 80,
            "sd": 65,
            "sp": 80
        },
        "weightkg": 19,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Quilladin": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 61,
            "at": 78,
            "df": 95,
            "sa": 56,
            "sd": 58,
            "sp": 57
        },
        "weightkg": 29,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Qwilfish": {
        "types": [
            "Water",
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 95,
            "df": 85,
            "sa": 55,
            "sd": 55,
            "sp": 85
        },
        "weightkg": 3.9,
        "abilities": {
            "0": "Poison Point"
        },
        "otherFormes": [
            "Qwilfish [Hisuian]"
        ]
    },
    "Qwilfish [Hisuian]": {
        "types": [
            "Dark",
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 95,
            "df": 85,
            "sa": 55,
            "sd": 55,
            "sp": 85
        },
        "weightkg": 3.9,
        "abilities": {
            "0": "Poison Point"
        },
        "baseSpecies": "Qwilfish"
    },
    "Raboot": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 86,
            "df": 60,
            "sa": 55,
            "sd": 60,
            "sp": 94
        },
        "weightkg": 9,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Rabsca": {
        "types": [
            "Bug",
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 50,
            "df": 85,
            "sa": 115,
            "sd": 100,
            "sp": 45
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Raging Bolt": {
        "types": [
            "Electric",
            "Dragon"
        ],
        "bs": {
            "hp": 125,
            "at": 73,
            "df": 91,
            "sa": 137,
            "sd": 89,
            "sp": 75
        },
        "weightkg": 480,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Raichu": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 90,
            "df": 55,
            "sa": 90,
            "sd": 80,
            "sp": 110
        },
        "weightkg": 30,
        "abilities": {
            "0": "Static"
        },
        "otherFormes": [
            "Raichu [Alolan]",
            "Raichu [Mega Raichu X]",
            "Raichu [Mega Raichu Y]"
        ]
    },
    "Raichu [Alolan]": {
        "types": [
            "Electric",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 50,
            "sa": 95,
            "sd": 85,
            "sp": 110
        },
        "weightkg": 21,
        "abilities": {
            "0": "Surge Surfer"
        },
        "baseSpecies": "Raichu"
    },
    "Raichu [Mega Raichu X]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 135,
            "df": 95,
            "sa": 90,
            "sd": 95,
            "sp": 110
        },
        "weightkg": 38,
        "abilities": {
            "0": "Transistor"
        },
        "baseSpecies": "Raichu"
    },
    "Raichu [Mega Raichu Y]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 55,
            "sa": 160,
            "sd": 80,
            "sp": 130
        },
        "weightkg": 26,
        "abilities": {
            "0": "No Guard"
        },
        "baseSpecies": "Raichu"
    },
    "Raikou": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 90,
            "at": 85,
            "df": 75,
            "sa": 115,
            "sd": 100,
            "sp": 115
        },
        "weightkg": 178,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Ralts": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 28,
            "at": 25,
            "df": 25,
            "sa": 45,
            "sd": 35,
            "sp": 40
        },
        "weightkg": 6.6,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Rampardos": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 97,
            "at": 165,
            "df": 60,
            "sa": 65,
            "sd": 50,
            "sp": 58
        },
        "weightkg": 102.5,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Rapidash": {
        "types": [
            "Fire",
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 100,
            "df": 70,
            "sa": 80,
            "sd": 80,
            "sp": 105
        },
        "weightkg": 95,
        "abilities": {
            "0": "Reckless"
        },
        "otherFormes": [
            "Rapidash [Galarian]"
        ]
    },
    "Rapidash [Galarian]": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 100,
            "df": 70,
            "sa": 80,
            "sd": 80,
            "sp": 105
        },
        "weightkg": 80,
        "abilities": {
            "0": "Pastel Veil"
        },
        "baseSpecies": "Rapidash"
    },
    "Raticate": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 81,
            "df": 60,
            "sa": 50,
            "sd": 70,
            "sp": 97
        },
        "weightkg": 18.5,
        "abilities": {
            "0": "Hustle"
        },
        "otherFormes": [
            "Raticate [Alolan]"
        ]
    },
    "Raticate [Alolan]": {
        "types": [
            "Dark",
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 71,
            "df": 70,
            "sa": 40,
            "sd": 80,
            "sp": 77
        },
        "weightkg": 25.5,
        "abilities": {
            "0": "Thick Fat"
        },
        "baseSpecies": "Raticate"
    },
    "Rattata": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 30,
            "at": 56,
            "df": 35,
            "sa": 25,
            "sd": 35,
            "sp": 72
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Hustle"
        },
        "otherFormes": [
            "Rattata [Alolan]"
        ]
    },
    "Rattata [Alolan]": {
        "types": [
            "Dark",
            "Normal"
        ],
        "bs": {
            "hp": 30,
            "at": 56,
            "df": 35,
            "sa": 25,
            "sd": 35,
            "sp": 72
        },
        "weightkg": 3.8,
        "abilities": {
            "0": "Thick Fat"
        },
        "baseSpecies": "Rattata"
    },
    "Rayquaza": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 105,
            "at": 150,
            "df": 90,
            "sa": 150,
            "sd": 90,
            "sp": 95
        },
        "weightkg": 206.5,
        "abilities": {
            "0": "Air Lock"
        },
        "otherFormes": [
            "Rayquaza [Mega Rayquaza]"
        ]
    },
    "Rayquaza [Mega Rayquaza]": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 105,
            "at": 180,
            "df": 100,
            "sa": 180,
            "sd": 100,
            "sp": 115
        },
        "weightkg": 392,
        "abilities": {
            "0": "Delta Stream"
        },
        "baseSpecies": "Rayquaza"
    },
    "Regice": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 80,
            "at": 50,
            "df": 100,
            "sa": 100,
            "sd": 200,
            "sp": 50
        },
        "weightkg": 175,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Regidrago": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 200,
            "at": 100,
            "df": 50,
            "sa": 100,
            "sd": 50,
            "sp": 80
        },
        "weightkg": 200,
        "abilities": {
            "0": "Dragon's Maw"
        }
    },
    "Regieleki": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 50,
            "sa": 100,
            "sd": 50,
            "sp": 200
        },
        "weightkg": 145,
        "abilities": {
            "0": "Transistor"
        }
    },
    "Regigigas": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 110,
            "at": 160,
            "df": 110,
            "sa": 80,
            "sd": 110,
            "sp": 100
        },
        "weightkg": 420,
        "abilities": {
            "0": "Slow Start"
        }
    },
    "Regirock": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 200,
            "sa": 50,
            "sd": 100,
            "sp": 50
        },
        "weightkg": 230,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Registeel": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 80,
            "at": 75,
            "df": 150,
            "sa": 75,
            "sd": 150,
            "sp": 50
        },
        "weightkg": 205,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Relicanth": {
        "types": [
            "Water",
            "Rock"
        ],
        "bs": {
            "hp": 100,
            "at": 90,
            "df": 130,
            "sa": 45,
            "sd": 65,
            "sp": 55
        },
        "weightkg": 23.4,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Rellor": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 41,
            "at": 50,
            "df": 60,
            "sa": 31,
            "sd": 58,
            "sp": 30
        },
        "weightkg": 1,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Remoraid": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 35,
            "at": 65,
            "df": 35,
            "sa": 65,
            "sd": 35,
            "sp": 65
        },
        "weightkg": 12,
        "abilities": {
            "0": "Hustle"
        }
    },
    "Reshiram": {
        "types": [
            "Dragon",
            "Fire"
        ],
        "bs": {
            "hp": 100,
            "at": 120,
            "df": 100,
            "sa": 150,
            "sd": 120,
            "sp": 90
        },
        "weightkg": 330,
        "abilities": {
            "0": "Turboblaze"
        }
    },
    "Reuniclus": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 110,
            "at": 65,
            "df": 75,
            "sa": 125,
            "sd": 85,
            "sp": 30
        },
        "weightkg": 20.1,
        "abilities": {
            "0": "Magic Guard"
        }
    },
    "Revavroom": {
        "types": [
            "Steel",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Overcoat"
        },
        "otherFormes": [
            "Revavroom [Form 1]",
            "Revavroom [Form 2]",
            "Revavroom [Form 3]",
            "Revavroom [Form 4]",
            "Revavroom [Form 5]"
        ]
    },
    "Revavroom [Form 1]": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Speed Boost"
        },
        "baseSpecies": "Revavroom"
    },
    "Revavroom [Form 2]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Misty Surge"
        },
        "baseSpecies": "Revavroom"
    },
    "Revavroom [Form 3]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Stamina"
        },
        "baseSpecies": "Revavroom"
    },
    "Revavroom [Form 4]": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Toxic Debris"
        },
        "baseSpecies": "Revavroom"
    },
    "Revavroom [Form 5]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 80,
            "at": 119,
            "df": 90,
            "sa": 54,
            "sd": 67,
            "sp": 90
        },
        "weightkg": 120,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Revavroom"
    },
    "Rhydon": {
        "types": [
            "Ground",
            "Rock"
        ],
        "bs": {
            "hp": 105,
            "at": 130,
            "df": 120,
            "sa": 45,
            "sd": 45,
            "sp": 40
        },
        "weightkg": 120,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Rhyhorn": {
        "types": [
            "Ground",
            "Rock"
        ],
        "bs": {
            "hp": 80,
            "at": 85,
            "df": 95,
            "sa": 30,
            "sd": 30,
            "sp": 25
        },
        "weightkg": 115,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Rhyperior": {
        "types": [
            "Ground",
            "Rock"
        ],
        "bs": {
            "hp": 115,
            "at": 140,
            "df": 130,
            "sa": 55,
            "sd": 55,
            "sp": 40
        },
        "weightkg": 282.8,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Ribombee": {
        "types": [
            "Bug",
            "Fairy"
        ],
        "bs": {
            "hp": 60,
            "at": 55,
            "df": 60,
            "sa": 95,
            "sd": 70,
            "sp": 124
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Rillaboom": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 100,
            "at": 125,
            "df": 90,
            "sa": 60,
            "sd": 70,
            "sp": 85
        },
        "weightkg": 90,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Riolu": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 40,
            "at": 70,
            "df": 40,
            "sa": 35,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 20.2,
        "abilities": {
            "0": "Steadfast"
        }
    },
    "Roaring Moon": {
        "types": [
            "Dragon",
            "Dark"
        ],
        "bs": {
            "hp": 105,
            "at": 139,
            "df": 71,
            "sa": 55,
            "sd": 101,
            "sp": 119
        },
        "weightkg": 380,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Rockruff": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 45,
            "at": 65,
            "df": 40,
            "sa": 30,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 9.2,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Rockruff [Form 2]"
        ]
    },
    "Rockruff [Form 2]": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 45,
            "at": 65,
            "df": 40,
            "sa": 30,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 9.2,
        "abilities": {
            "0": "Own Tempo"
        },
        "baseSpecies": "Rockruff"
    },
    "Roggenrola": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 55,
            "at": 75,
            "df": 85,
            "sa": 25,
            "sd": 25,
            "sp": 15
        },
        "weightkg": 18,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Rolycoly": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 30,
            "at": 40,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 30
        },
        "weightkg": 12,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Rookidee": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 38,
            "at": 47,
            "df": 35,
            "sa": 33,
            "sd": 35,
            "sp": 57
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Unnerve"
        }
    },
    "Roselia": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 50,
            "at": 60,
            "df": 45,
            "sa": 100,
            "sd": 80,
            "sp": 65
        },
        "weightkg": 2,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Roserade": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 70,
            "df": 65,
            "sa": 125,
            "sd": 105,
            "sp": 90
        },
        "weightkg": 14.5,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Rotom": {
        "types": [
            "Electric",
            "Ghost"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 77,
            "sa": 95,
            "sd": 77,
            "sp": 91
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Rotom [Heat Rotom]",
            "Rotom [Wash Rotom]",
            "Rotom [Frost Rotom]",
            "Rotom [Fan Rotom]",
            "Rotom [Mow Rotom]"
        ]
    },
    "Rotom [Heat Rotom]": {
        "types": [
            "Electric",
            "Fire"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 107,
            "sa": 105,
            "sd": 107,
            "sp": 86
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Rotom"
    },
    "Rotom [Wash Rotom]": {
        "types": [
            "Electric",
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 107,
            "sa": 105,
            "sd": 107,
            "sp": 86
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Rotom"
    },
    "Rotom [Frost Rotom]": {
        "types": [
            "Electric",
            "Ice"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 107,
            "sa": 105,
            "sd": 107,
            "sp": 86
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Rotom"
    },
    "Rotom [Fan Rotom]": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 107,
            "sa": 105,
            "sd": 107,
            "sp": 86
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Motor Drive"
        },
        "baseSpecies": "Rotom"
    },
    "Rotom [Mow Rotom]": {
        "types": [
            "Electric",
            "Grass"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 107,
            "sa": 105,
            "sd": 107,
            "sp": 86
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Rotom"
    },
    "Rowlet": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 68,
            "at": 55,
            "df": 55,
            "sa": 50,
            "sd": 50,
            "sp": 42
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Rufflet": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 83,
            "df": 50,
            "sa": 37,
            "sd": 50,
            "sp": 60
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Runerigus": {
        "types": [
            "Ground",
            "Ghost"
        ],
        "bs": {
            "hp": 58,
            "at": 95,
            "df": 145,
            "sa": 50,
            "sd": 105,
            "sp": 30
        },
        "weightkg": 66.6,
        "abilities": {
            "0": "Wandering Spirit"
        }
    },
    "Sableye": {
        "types": [
            "Dark",
            "Ghost"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 75,
            "sa": 65,
            "sd": 65,
            "sp": 50
        },
        "weightkg": 11,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Sableye [Mega Sableye]"
        ]
    },
    "Sableye [Mega Sableye]": {
        "types": [
            "Dark",
            "Ghost"
        ],
        "bs": {
            "hp": 50,
            "at": 85,
            "df": 125,
            "sa": 85,
            "sd": 115,
            "sp": 20
        },
        "weightkg": 161,
        "abilities": {
            "0": "Magic Bounce"
        },
        "baseSpecies": "Sableye"
    },
    "Salamence": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 95,
            "at": 135,
            "df": 80,
            "sa": 110,
            "sd": 80,
            "sp": 100
        },
        "weightkg": 102.6,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Salamence [Mega Salamence]"
        ]
    },
    "Salamence [Mega Salamence]": {
        "types": [
            "Dragon",
            "Flying"
        ],
        "bs": {
            "hp": 95,
            "at": 145,
            "df": 130,
            "sa": 120,
            "sd": 90,
            "sp": 120
        },
        "weightkg": 112.6,
        "abilities": {
            "0": "Aerilate"
        },
        "baseSpecies": "Salamence"
    },
    "Salandit": {
        "types": [
            "Poison",
            "Fire"
        ],
        "bs": {
            "hp": 48,
            "at": 44,
            "df": 40,
            "sa": 71,
            "sd": 40,
            "sp": 77
        },
        "weightkg": 4.8,
        "abilities": {
            "0": "Corrosion"
        }
    },
    "Salazzle": {
        "types": [
            "Poison",
            "Fire"
        ],
        "bs": {
            "hp": 68,
            "at": 64,
            "df": 60,
            "sa": 111,
            "sd": 60,
            "sp": 117
        },
        "weightkg": 22.2,
        "abilities": {
            "0": "Corrosion"
        }
    },
    "Samurott": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 95,
            "at": 100,
            "df": 85,
            "sa": 108,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 94.6,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Samurott [Hisuian]"
        ]
    },
    "Samurott [Hisuian]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 90,
            "at": 108,
            "df": 80,
            "sa": 100,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 58.2,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Samurott"
    },
    "Sandaconda": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 72,
            "at": 107,
            "df": 125,
            "sa": 65,
            "sd": 70,
            "sp": 71
        },
        "weightkg": 65.5,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Sandile": {
        "types": [
            "Ground",
            "Dark"
        ],
        "bs": {
            "hp": 50,
            "at": 72,
            "df": 35,
            "sa": 35,
            "sd": 35,
            "sp": 65
        },
        "weightkg": 15.2,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Sandshrew": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 85,
            "sa": 20,
            "sd": 30,
            "sp": 40
        },
        "weightkg": 12,
        "abilities": {
            "0": "Sand Force"
        },
        "otherFormes": [
            "Sandshrew [Alolan]"
        ]
    },
    "Sandshrew [Alolan]": {
        "types": [
            "Ice",
            "Steel"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 90,
            "sa": 10,
            "sd": 35,
            "sp": 40
        },
        "weightkg": 40,
        "abilities": {
            "0": "Slush Rush"
        },
        "baseSpecies": "Sandshrew"
    },
    "Sandslash": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 75,
            "at": 100,
            "df": 110,
            "sa": 45,
            "sd": 55,
            "sp": 65
        },
        "weightkg": 29.5,
        "abilities": {
            "0": "Sand Force"
        },
        "otherFormes": [
            "Sandslash [Alolan]"
        ]
    },
    "Sandslash [Alolan]": {
        "types": [
            "Ice",
            "Steel"
        ],
        "bs": {
            "hp": 75,
            "at": 100,
            "df": 120,
            "sa": 25,
            "sd": 65,
            "sp": 65
        },
        "weightkg": 55,
        "abilities": {
            "0": "Slush Rush"
        },
        "baseSpecies": "Sandslash"
    },
    "Sandygast": {
        "types": [
            "Ghost",
            "Ground"
        ],
        "bs": {
            "hp": 55,
            "at": 55,
            "df": 80,
            "sa": 70,
            "sd": 45,
            "sp": 15
        },
        "weightkg": 70,
        "abilities": {
            "0": "Cursed Body"
        }
    },
    "Sandy Shocks": {
        "types": [
            "Electric",
            "Ground"
        ],
        "bs": {
            "hp": 85,
            "at": 81,
            "df": 97,
            "sa": 121,
            "sd": 85,
            "sp": 101
        },
        "weightkg": 60,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Sawk": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 75,
            "sa": 30,
            "sd": 75,
            "sp": 85
        },
        "weightkg": 51,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Sawsbuck": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 92.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Sawsbuck [Summer Form]",
            "Sawsbuck [Autumn Form]",
            "Sawsbuck [Winter Form]"
        ]
    },
    "Sawsbuck [Summer Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 92.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Sawsbuck"
    },
    "Sawsbuck [Autumn Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 92.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Sawsbuck"
    },
    "Sawsbuck [Winter Form]": {
        "types": [
            "Normal",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 70,
            "sa": 60,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 92.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "baseSpecies": "Sawsbuck"
    },
    "Scatterbug": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 38,
            "at": 35,
            "df": 40,
            "sa": 27,
            "sd": 25,
            "sp": 35
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Sceptile": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 65,
            "sa": 105,
            "sd": 85,
            "sp": 120
        },
        "weightkg": 52.2,
        "abilities": {
            "0": "Overgrow"
        },
        "otherFormes": [
            "Sceptile [Mega Sceptile]"
        ]
    },
    "Sceptile [Mega Sceptile]": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 75,
            "sa": 145,
            "sd": 85,
            "sp": 145
        },
        "weightkg": 55.2,
        "abilities": {
            "0": "Limber"
        },
        "baseSpecies": "Sceptile"
    },
    "Scizor": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 130,
            "df": 100,
            "sa": 55,
            "sd": 80,
            "sp": 65
        },
        "weightkg": 118,
        "abilities": {
            "0": "Swarm"
        },
        "otherFormes": [
            "Scizor [Mega Scizor]"
        ]
    },
    "Scizor [Mega Scizor]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 70,
            "at": 150,
            "df": 140,
            "sa": 65,
            "sd": 100,
            "sp": 75
        },
        "weightkg": 125,
        "abilities": {
            "0": "Technician"
        },
        "baseSpecies": "Scizor"
    },
    "Scolipede": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 100,
            "df": 89,
            "sa": 55,
            "sd": 69,
            "sp": 112
        },
        "weightkg": 200.5,
        "abilities": {
            "0": "Poison Point"
        },
        "otherFormes": [
            "Scolipede [Mega Scolipede]"
        ]
    },
    "Scolipede [Mega Scolipede]": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 140,
            "df": 149,
            "sa": 75,
            "sd": 99,
            "sp": 62
        },
        "weightkg": 230.5,
        "abilities": {
            "0": "Shell Armor"
        },
        "baseSpecies": "Scolipede"
    },
    "Scorbunny": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 50,
            "at": 71,
            "df": 40,
            "sa": 40,
            "sd": 40,
            "sp": 69
        },
        "weightkg": 4.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Scovillain": {
        "types": [
            "Grass",
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 108,
            "df": 65,
            "sa": 108,
            "sd": 65,
            "sp": 75
        },
        "weightkg": 15,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Scovillain [Mega Scovillain]"
        ]
    },
    "Scovillain [Mega Scovillain]": {
        "types": [
            "Grass",
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 138,
            "df": 85,
            "sa": 138,
            "sd": 85,
            "sp": 75
        },
        "weightkg": 22,
        "abilities": {
            "0": "Spicy Spray"
        },
        "baseSpecies": "Scovillain"
    },
    "Scrafty": {
        "types": [
            "Dark",
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 115,
            "sa": 45,
            "sd": 115,
            "sp": 58
        },
        "weightkg": 30,
        "abilities": {
            "0": "Shed Skin"
        },
        "otherFormes": [
            "Scrafty [Mega Scrafty]"
        ]
    },
    "Scrafty [Mega Scrafty]": {
        "types": [
            "Dark",
            "Fighting"
        ],
        "bs": {
            "hp": 65,
            "at": 130,
            "df": 135,
            "sa": 55,
            "sd": 135,
            "sp": 68
        },
        "weightkg": 31,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Scrafty"
    },
    "Scraggy": {
        "types": [
            "Dark",
            "Fighting"
        ],
        "bs": {
            "hp": 50,
            "at": 75,
            "df": 70,
            "sa": 35,
            "sd": 70,
            "sp": 48
        },
        "weightkg": 11.8,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Scream Tail": {
        "types": [
            "Fairy",
            "Psychic"
        ],
        "bs": {
            "hp": 115,
            "at": 65,
            "df": 99,
            "sa": 65,
            "sd": 115,
            "sp": 111
        },
        "weightkg": 8,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Scyther": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 110,
            "df": 80,
            "sa": 55,
            "sd": 80,
            "sp": 105
        },
        "weightkg": 56,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Seadra": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 55,
            "at": 65,
            "df": 95,
            "sa": 95,
            "sd": 45,
            "sp": 85
        },
        "weightkg": 25,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Seaking": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 92,
            "df": 65,
            "sa": 65,
            "sd": 80,
            "sp": 68
        },
        "weightkg": 39,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Sealeo": {
        "types": [
            "Ice",
            "Water"
        ],
        "bs": {
            "hp": 90,
            "at": 60,
            "df": 70,
            "sa": 75,
            "sd": 70,
            "sp": 45
        },
        "weightkg": 87.6,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Seedot": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 50,
            "sa": 30,
            "sd": 30,
            "sp": 30
        },
        "weightkg": 4,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Seel": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 65,
            "at": 45,
            "df": 55,
            "sa": 45,
            "sd": 70,
            "sp": 45
        },
        "weightkg": 90,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Seismitoad": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 105,
            "at": 95,
            "df": 75,
            "sa": 85,
            "sd": 75,
            "sp": 74
        },
        "weightkg": 62,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Sentret": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 35,
            "at": 46,
            "df": 34,
            "sa": 35,
            "sd": 45,
            "sp": 20
        },
        "weightkg": 6,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Serperior": {
        "types": [
            "Grass",
            "Dragon"
        ],
        "bs": {
            "hp": 75,
            "at": 75,
            "df": 95,
            "sa": 75,
            "sd": 95,
            "sp": 113
        },
        "weightkg": 63,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Servine": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 75,
            "sa": 60,
            "sd": 75,
            "sp": 83
        },
        "weightkg": 16,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Seviper": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 73,
            "at": 100,
            "df": 60,
            "sa": 100,
            "sd": 60,
            "sp": 65
        },
        "weightkg": 52.5,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Sewaddle": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 45,
            "at": 53,
            "df": 70,
            "sa": 40,
            "sd": 60,
            "sp": 42
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Sharpedo": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 120,
            "df": 40,
            "sa": 95,
            "sd": 40,
            "sp": 95
        },
        "weightkg": 88.8,
        "abilities": {
            "0": "Rough Skin"
        },
        "otherFormes": [
            "Sharpedo [Mega Sharpedo]"
        ]
    },
    "Sharpedo [Mega Sharpedo]": {
        "types": [
            "Water",
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 140,
            "df": 70,
            "sa": 110,
            "sd": 65,
            "sp": 105
        },
        "weightkg": 130.3,
        "abilities": {
            "0": "Strong Jaw"
        },
        "baseSpecies": "Sharpedo"
    },
    "Shaymin": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 2.1,
        "abilities": {
            "0": "Natural Cure"
        },
        "otherFormes": [
            "Shaymin [Sky Forme]"
        ]
    },
    "Shaymin [Sky Forme]": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 100,
            "at": 103,
            "df": 75,
            "sa": 120,
            "sd": 75,
            "sp": 127
        },
        "weightkg": 5.2,
        "abilities": {
            "0": "Serene Grace"
        },
        "baseSpecies": "Shaymin"
    },
    "Shedinja": {
        "types": [
            "Bug",
            "Ghost"
        ],
        "bs": {
            "hp": 1,
            "at": 90,
            "df": 45,
            "sa": 30,
            "sd": 30,
            "sp": 40
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Wonder Guard"
        }
    },
    "Shelgon": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 65,
            "at": 95,
            "df": 100,
            "sa": 60,
            "sd": 50,
            "sp": 50
        },
        "weightkg": 110.5,
        "abilities": {
            "0": "Rock Head"
        }
    },
    "Shellder": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 30,
            "at": 65,
            "df": 100,
            "sa": 45,
            "sd": 25,
            "sp": 40
        },
        "weightkg": 4,
        "abilities": {
            "0": "Shell Armor"
        }
    },
    "Shellos": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 76,
            "at": 48,
            "df": 48,
            "sa": 57,
            "sd": 62,
            "sp": 34
        },
        "weightkg": 6.3,
        "abilities": {
            "0": "Sticky Hold"
        },
        "otherFormes": [
            "Shellos [East Sea]"
        ]
    },
    "Shellos [East Sea]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 76,
            "at": 48,
            "df": 48,
            "sa": 57,
            "sd": 62,
            "sp": 34
        },
        "weightkg": 6.3,
        "abilities": {
            "0": "Sticky Hold"
        },
        "baseSpecies": "Shellos"
    },
    "Shelmet": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 40,
            "df": 85,
            "sa": 40,
            "sd": 65,
            "sp": 25
        },
        "weightkg": 7.7,
        "abilities": {
            "0": "Hydration"
        }
    },
    "Shieldon": {
        "types": [
            "Rock",
            "Steel"
        ],
        "bs": {
            "hp": 30,
            "at": 42,
            "df": 118,
            "sa": 42,
            "sd": 88,
            "sp": 30
        },
        "weightkg": 57,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Shiftry": {
        "types": [
            "Grass",
            "Dark"
        ],
        "bs": {
            "hp": 90,
            "at": 100,
            "df": 60,
            "sa": 90,
            "sd": 60,
            "sp": 80
        },
        "weightkg": 59.6,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Shiinotic": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 60,
            "at": 45,
            "df": 80,
            "sa": 90,
            "sd": 100,
            "sp": 30
        },
        "weightkg": 11.5,
        "abilities": {
            "0": "Illuminate"
        }
    },
    "Shinx": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 45,
            "at": 65,
            "df": 34,
            "sa": 40,
            "sd": 34,
            "sp": 45
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Shroodle": {
        "types": [
            "Poison",
            "Normal"
        ],
        "bs": {
            "hp": 40,
            "at": 65,
            "df": 35,
            "sa": 40,
            "sd": 35,
            "sp": 75
        },
        "weightkg": 0.7,
        "abilities": {
            "0": "Unburden"
        }
    },
    "Shroomish": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 40,
            "df": 60,
            "sa": 40,
            "sd": 60,
            "sp": 35
        },
        "weightkg": 4.5,
        "abilities": {
            "0": "Effect Spore"
        }
    },
    "Shuckle": {
        "types": [
            "Bug",
            "Rock"
        ],
        "bs": {
            "hp": 20,
            "at": 10,
            "df": 230,
            "sa": 10,
            "sd": 230,
            "sp": 5
        },
        "weightkg": 20.5,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Shuppet": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 44,
            "at": 75,
            "df": 35,
            "sa": 63,
            "sd": 33,
            "sp": 45
        },
        "weightkg": 2.3,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Sigilyph": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 72,
            "at": 58,
            "df": 80,
            "sa": 103,
            "sd": 80,
            "sp": 97
        },
        "weightkg": 14,
        "abilities": {
            "0": "Wonder Skin"
        }
    },
    "Silcoon": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 35,
            "df": 55,
            "sa": 25,
            "sd": 25,
            "sp": 15
        },
        "weightkg": 10,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Silicobra": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 52,
            "at": 57,
            "df": 75,
            "sa": 35,
            "sd": 50,
            "sp": 46
        },
        "weightkg": 7.6,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Silvally": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "otherFormes": [
            "Silvally [Type: Fighting]",
            "Silvally [Type: Flying]",
            "Silvally [Type: Poison]",
            "Silvally [Type: Ground]",
            "Silvally [Type: Rock]",
            "Silvally [Type: Bug]",
            "Silvally [Type: Ghost]",
            "Silvally [Type: Steel]",
            "Silvally [Type: Unknown]",
            "Silvally [Type: Fire]",
            "Silvally [Type: Water]",
            "Silvally [Type: Grass]",
            "Silvally [Type: Electric]",
            "Silvally [Type: Psychic]",
            "Silvally [Type: Ice]",
            "Silvally [Type: Dragon]",
            "Silvally [Type: Dark]",
            "Silvally [Type: Fairy]"
        ]
    },
    "Silvally [Type: Fighting]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Flying]": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Poison]": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Ground]": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Rock]": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Bug]": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Ghost]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Steel]": {
        "types": [
            "Steel"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Unknown]": {
        "types": [
            "???"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Fire]": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Water]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Grass]": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Electric]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Psychic]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Ice]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Dragon]": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Dark]": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Silvally [Type: Fairy]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 100.5,
        "abilities": {
            "0": "RKS System"
        },
        "baseSpecies": "Silvally"
    },
    "Simipour": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 98,
            "df": 63,
            "sa": 98,
            "sd": 63,
            "sp": 101
        },
        "weightkg": 29,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Simisage": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 75,
            "at": 98,
            "df": 63,
            "sa": 98,
            "sd": 63,
            "sp": 101
        },
        "weightkg": 30.5,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Simisear": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 75,
            "at": 98,
            "df": 63,
            "sa": 98,
            "sd": 63,
            "sp": 101
        },
        "weightkg": 28,
        "abilities": {
            "0": "Gluttony"
        }
    },
    "Sinistcha": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 71,
            "at": 60,
            "df": 106,
            "sa": 121,
            "sd": 80,
            "sp": 70
        },
        "weightkg": 4.9,
        "abilities": {
            "0": "Hospitality"
        },
        "otherFormes": [
            "Sinistcha [Masterpiece Form]"
        ]
    },
    "Sinistcha [Masterpiece Form]": {
        "types": [
            "Grass",
            "Ghost"
        ],
        "bs": {
            "hp": 71,
            "at": 60,
            "df": 106,
            "sa": 121,
            "sd": 80,
            "sp": 70
        },
        "weightkg": 4.9,
        "abilities": {
            "0": "Hospitality"
        },
        "baseSpecies": "Sinistcha"
    },
    "Sinistea": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 45,
            "sa": 74,
            "sd": 54,
            "sp": 50
        },
        "weightkg": 0.2,
        "abilities": {
            "0": "Cursed Body"
        },
        "otherFormes": [
            "Sinistea [Antique Form]"
        ]
    },
    "Sinistea [Antique Form]": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 45,
            "sa": 74,
            "sd": 54,
            "sp": 50
        },
        "weightkg": 0.2,
        "abilities": {
            "0": "Cursed Body"
        },
        "baseSpecies": "Sinistea"
    },
    "Sirfetch'd": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 62,
            "at": 135,
            "df": 95,
            "sa": 68,
            "sd": 82,
            "sp": 65
        },
        "weightkg": 117,
        "abilities": {
            "0": "Steadfast"
        }
    },
    "Sizzlipede": {
        "types": [
            "Fire",
            "Bug"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 45,
            "sa": 50,
            "sd": 50,
            "sp": 45
        },
        "weightkg": 1,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Skarmory": {
        "types": [
            "Steel",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 80,
            "df": 140,
            "sa": 40,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 50.5,
        "abilities": {
            "0": "Keen Eye"
        },
        "otherFormes": [
            "Skarmory [Mega Skarmory]"
        ]
    },
    "Skarmory [Mega Skarmory]": {
        "types": [
            "Steel",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 140,
            "df": 110,
            "sa": 40,
            "sd": 100,
            "sp": 110
        },
        "weightkg": 40.4,
        "abilities": {
            "0": "Stalwart"
        },
        "baseSpecies": "Skarmory"
    },
    "Skeledirge": {
        "types": [
            "Fire",
            "Ghost"
        ],
        "bs": {
            "hp": 104,
            "at": 75,
            "df": 100,
            "sa": 110,
            "sd": 75,
            "sp": 66
        },
        "weightkg": 326.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Skiddo": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 66,
            "at": 65,
            "df": 48,
            "sa": 62,
            "sd": 57,
            "sp": 52
        },
        "weightkg": 31,
        "abilities": {
            "0": "Grass Pelt"
        }
    },
    "Skiploom": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 45,
            "df": 50,
            "sa": 45,
            "sd": 65,
            "sp": 80
        },
        "weightkg": 1,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Skitty": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 50,
            "at": 45,
            "df": 45,
            "sa": 35,
            "sd": 35,
            "sp": 50
        },
        "weightkg": 11,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Skorupi": {
        "types": [
            "Poison",
            "Bug"
        ],
        "bs": {
            "hp": 40,
            "at": 50,
            "df": 90,
            "sa": 30,
            "sd": 55,
            "sp": 65
        },
        "weightkg": 12,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Skrelp": {
        "types": [
            "Poison",
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 60,
            "df": 60,
            "sa": 60,
            "sd": 60,
            "sp": 30
        },
        "weightkg": 7.3,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Skuntank": {
        "types": [
            "Poison",
            "Dark"
        ],
        "bs": {
            "hp": 103,
            "at": 93,
            "df": 67,
            "sa": 71,
            "sd": 61,
            "sp": 84
        },
        "weightkg": 38,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Skwovet": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 70,
            "at": 55,
            "df": 55,
            "sa": 35,
            "sd": 35,
            "sp": 25
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Cheek Pouch"
        }
    },
    "Slaking": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 150,
            "at": 160,
            "df": 100,
            "sa": 95,
            "sd": 65,
            "sp": 100
        },
        "weightkg": 130.5,
        "abilities": {
            "0": "Truant"
        }
    },
    "Slakoth": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 60,
            "sa": 35,
            "sd": 35,
            "sp": 30
        },
        "weightkg": 24,
        "abilities": {
            "0": "Truant"
        }
    },
    "Sliggoo": {
        "types": [
            "Dragon"
        ],
        "bs": {
            "hp": 68,
            "at": 75,
            "df": 53,
            "sa": 83,
            "sd": 113,
            "sp": 60
        },
        "weightkg": 17.5,
        "abilities": {
            "0": "Gooey"
        },
        "otherFormes": [
            "Sliggoo [Hisuian]"
        ]
    },
    "Sliggoo [Hisuian]": {
        "types": [
            "Steel",
            "Dragon"
        ],
        "bs": {
            "hp": 58,
            "at": 75,
            "df": 83,
            "sa": 83,
            "sd": 113,
            "sp": 40
        },
        "weightkg": 68.5,
        "abilities": {
            "0": "Gooey"
        },
        "baseSpecies": "Sliggoo"
    },
    "Slither Wing": {
        "types": [
            "Bug",
            "Fighting"
        ],
        "bs": {
            "hp": 85,
            "at": 135,
            "df": 79,
            "sa": 85,
            "sd": 105,
            "sp": 81
        },
        "weightkg": 92,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Slowbro": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 75,
            "df": 110,
            "sa": 100,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 78.5,
        "abilities": {
            "0": "Oblivious"
        },
        "otherFormes": [
            "Slowbro [Galarian]",
            "Slowbro [Mega Slowbro]"
        ]
    },
    "Slowbro [Galarian]": {
        "types": [
            "Poison",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 100,
            "df": 95,
            "sa": 100,
            "sd": 70,
            "sp": 30
        },
        "weightkg": 70.5,
        "abilities": {
            "0": "Own Tempo"
        },
        "baseSpecies": "Slowbro"
    },
    "Slowbro [Mega Slowbro]": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 75,
            "df": 180,
            "sa": 130,
            "sd": 80,
            "sp": 30
        },
        "weightkg": 120,
        "abilities": {
            "0": "Shell Armor"
        },
        "baseSpecies": "Slowbro"
    },
    "Slowking": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 75,
            "df": 80,
            "sa": 100,
            "sd": 110,
            "sp": 30
        },
        "weightkg": 79.5,
        "abilities": {
            "0": "Oblivious"
        },
        "otherFormes": [
            "Slowking [Galarian]"
        ]
    },
    "Slowking [Galarian]": {
        "types": [
            "Poison",
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 65,
            "df": 80,
            "sa": 110,
            "sd": 110,
            "sp": 30
        },
        "weightkg": 79.5,
        "abilities": {
            "0": "Own Tempo"
        },
        "baseSpecies": "Slowking"
    },
    "Slowpoke": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 65,
            "df": 65,
            "sa": 40,
            "sd": 40,
            "sp": 15
        },
        "weightkg": 36,
        "abilities": {
            "0": "Oblivious"
        },
        "otherFormes": [
            "Slowpoke [Galarian]"
        ]
    },
    "Slowpoke [Galarian]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 65,
            "df": 65,
            "sa": 40,
            "sd": 40,
            "sp": 15
        },
        "weightkg": 36,
        "abilities": {
            "0": "Own Tempo"
        },
        "baseSpecies": "Slowpoke"
    },
    "Slugma": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 40,
            "sa": 70,
            "sd": 40,
            "sp": 20
        },
        "weightkg": 35,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Slurpuff": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 82,
            "at": 80,
            "df": 86,
            "sa": 85,
            "sd": 75,
            "sp": 72
        },
        "weightkg": 5,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Smeargle": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 55,
            "at": 20,
            "df": 35,
            "sa": 20,
            "sd": 45,
            "sp": 75
        },
        "weightkg": 58,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Smoliv": {
        "types": [
            "Grass",
            "Normal"
        ],
        "bs": {
            "hp": 41,
            "at": 35,
            "df": 45,
            "sa": 58,
            "sd": 51,
            "sp": 30
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Early Bird"
        }
    },
    "Smoochum": {
        "types": [
            "Ice",
            "Psychic"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 15,
            "sa": 85,
            "sd": 65,
            "sp": 65
        },
        "weightkg": 6,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Sneasel": {
        "types": [
            "Dark",
            "Ice"
        ],
        "bs": {
            "hp": 55,
            "at": 95,
            "df": 55,
            "sa": 35,
            "sd": 75,
            "sp": 115
        },
        "weightkg": 28,
        "abilities": {
            "0": "Inner Focus"
        },
        "otherFormes": [
            "Sneasel [Hisuian]"
        ]
    },
    "Sneasel [Hisuian]": {
        "types": [
            "Fighting",
            "Poison"
        ],
        "bs": {
            "hp": 55,
            "at": 95,
            "df": 55,
            "sa": 35,
            "sd": 75,
            "sp": 115
        },
        "weightkg": 27,
        "abilities": {
            "0": "Inner Focus"
        },
        "baseSpecies": "Sneasel"
    },
    "Sneasler": {
        "types": [
            "Fighting",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 130,
            "df": 60,
            "sa": 40,
            "sd": 80,
            "sp": 120
        },
        "weightkg": 43,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Snivy": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 45,
            "at": 45,
            "df": 55,
            "sa": 45,
            "sd": 55,
            "sp": 63
        },
        "weightkg": 8.1,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Snom": {
        "types": [
            "Ice",
            "Bug"
        ],
        "bs": {
            "hp": 30,
            "at": 25,
            "df": 35,
            "sa": 45,
            "sd": 30,
            "sp": 20
        },
        "weightkg": 3.8,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Snorlax": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 160,
            "at": 110,
            "df": 65,
            "sa": 65,
            "sd": 110,
            "sp": 30
        },
        "weightkg": 460,
        "abilities": {
            "0": "Immunity"
        }
    },
    "Snorunt": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 50,
            "sa": 50,
            "sd": 50,
            "sp": 50
        },
        "weightkg": 16.8,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Snover": {
        "types": [
            "Grass",
            "Ice"
        ],
        "bs": {
            "hp": 60,
            "at": 62,
            "df": 50,
            "sa": 62,
            "sd": 60,
            "sp": 40
        },
        "weightkg": 50.5,
        "abilities": {
            "0": "Soundproof"
        }
    },
    "Snubbull": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 60,
            "at": 80,
            "df": 50,
            "sa": 40,
            "sd": 40,
            "sp": 30
        },
        "weightkg": 7.8,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Sobble": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 40,
            "df": 40,
            "sa": 70,
            "sd": 40,
            "sp": 70
        },
        "weightkg": 4,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Solgaleo": {
        "types": [
            "Psychic",
            "Steel"
        ],
        "bs": {
            "hp": 137,
            "at": 137,
            "df": 107,
            "sa": 113,
            "sd": 89,
            "sp": 97
        },
        "weightkg": 230,
        "abilities": {
            "0": "Full Metal Body"
        }
    },
    "Solosis": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 45,
            "at": 30,
            "df": 40,
            "sa": 105,
            "sd": 50,
            "sp": 20
        },
        "weightkg": 1,
        "abilities": {
            "0": "Magic Guard"
        }
    },
    "Solrock": {
        "types": [
            "Rock",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 95,
            "df": 85,
            "sa": 55,
            "sd": 65,
            "sp": 70
        },
        "weightkg": 154,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Spearow": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 60,
            "df": 30,
            "sa": 31,
            "sd": 31,
            "sp": 70
        },
        "weightkg": 2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Spectrier": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 100,
            "at": 65,
            "df": 60,
            "sa": 145,
            "sd": 80,
            "sp": 130
        },
        "weightkg": 44.5,
        "abilities": {
            "0": "Grim Neigh"
        }
    },
    "Spewpa": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 45,
            "at": 22,
            "df": 60,
            "sa": 27,
            "sd": 30,
            "sp": 29
        },
        "weightkg": 8.4,
        "abilities": {
            "0": "Shed Skin"
        }
    },
    "Spheal": {
        "types": [
            "Ice",
            "Water"
        ],
        "bs": {
            "hp": 70,
            "at": 40,
            "df": 50,
            "sa": 55,
            "sd": 50,
            "sp": 25
        },
        "weightkg": 39.5,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Spidops": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 60,
            "at": 79,
            "df": 92,
            "sa": 52,
            "sd": 86,
            "sp": 35
        },
        "weightkg": 16.5,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Spinarak": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 60,
            "df": 40,
            "sa": 40,
            "sd": 40,
            "sp": 30
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Spinda": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 60,
            "df": 60,
            "sa": 60,
            "sd": 60,
            "sp": 60
        },
        "weightkg": 5,
        "abilities": {
            "0": "Contrary"
        }
    },
    "Spiritomb": {
        "types": [
            "Ghost",
            "Dark"
        ],
        "bs": {
            "hp": 50,
            "at": 92,
            "df": 108,
            "sa": 92,
            "sd": 108,
            "sp": 35
        },
        "weightkg": 108,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Spoink": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 25,
            "df": 35,
            "sa": 70,
            "sd": 80,
            "sp": 60
        },
        "weightkg": 30.6,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Sprigatito": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 61,
            "df": 54,
            "sa": 45,
            "sd": 45,
            "sp": 65
        },
        "weightkg": 4.1,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Spritzee": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 78,
            "at": 52,
            "df": 60,
            "sa": 63,
            "sd": 65,
            "sp": 23
        },
        "weightkg": 0.5,
        "abilities": {
            "0": "Healer"
        }
    },
    "Squawkabilly": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 82,
            "at": 96,
            "df": 51,
            "sa": 45,
            "sd": 51,
            "sp": 92
        },
        "weightkg": 2.4,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Squawkabilly [Blue Plumage]",
            "Squawkabilly [Yellow Plumage]",
            "Squawkabilly [White Plumage]"
        ]
    },
    "Squawkabilly [Blue Plumage]": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 82,
            "at": 96,
            "df": 51,
            "sa": 45,
            "sd": 51,
            "sp": 92
        },
        "weightkg": 2.4,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Squawkabilly"
    },
    "Squawkabilly [Yellow Plumage]": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 82,
            "at": 96,
            "df": 51,
            "sa": 45,
            "sd": 51,
            "sp": 92
        },
        "weightkg": 2.4,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Squawkabilly"
    },
    "Squawkabilly [White Plumage]": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 82,
            "at": 96,
            "df": 51,
            "sa": 45,
            "sd": 51,
            "sp": 92
        },
        "weightkg": 2.4,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Squawkabilly"
    },
    "Squirtle": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 44,
            "at": 48,
            "df": 65,
            "sa": 50,
            "sd": 64,
            "sp": 43
        },
        "weightkg": 9,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Stakataka": {
        "types": [
            "Rock",
            "Steel"
        ],
        "bs": {
            "hp": 61,
            "at": 131,
            "df": 211,
            "sa": 53,
            "sd": 101,
            "sp": 13
        },
        "weightkg": 820,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Stantler": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 73,
            "at": 95,
            "df": 62,
            "sa": 85,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 71.2,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Staraptor": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 85,
            "at": 120,
            "df": 70,
            "sa": 50,
            "sd": 60,
            "sp": 100
        },
        "weightkg": 24.9,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Staraptor [Mega Staraptor]"
        ]
    },
    "Staraptor [Mega Staraptor]": {
        "types": [
            "Fighting",
            "Flying"
        ],
        "bs": {
            "hp": 85,
            "at": 140,
            "df": 100,
            "sa": 60,
            "sd": 90,
            "sp": 110
        },
        "weightkg": 50,
        "abilities": {
            "0": "Contrary"
        },
        "baseSpecies": "Staraptor"
    },
    "Staravia": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 75,
            "df": 50,
            "sa": 40,
            "sd": 40,
            "sp": 80
        },
        "weightkg": 15.5,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Starly": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 30,
            "sa": 30,
            "sd": 30,
            "sp": 60
        },
        "weightkg": 2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Starmie": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 75,
            "df": 85,
            "sa": 100,
            "sd": 85,
            "sp": 115
        },
        "weightkg": 80,
        "abilities": {
            "0": "Analytic"
        },
        "otherFormes": [
            "Starmie [Mega Starmie]"
        ]
    },
    "Starmie [Mega Starmie]": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 60,
            "at": 140,
            "df": 105,
            "sa": 130,
            "sd": 105,
            "sp": 120
        },
        "weightkg": 80,
        "abilities": {
            "0": "Huge Power"
        },
        "baseSpecies": "Starmie"
    },
    "Staryu": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 30,
            "at": 45,
            "df": 55,
            "sa": 70,
            "sd": 55,
            "sp": 85
        },
        "weightkg": 34.5,
        "abilities": {
            "0": "Analytic"
        }
    },
    "Steelix": {
        "types": [
            "Steel",
            "Ground"
        ],
        "bs": {
            "hp": 75,
            "at": 85,
            "df": 200,
            "sa": 55,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 400,
        "abilities": {
            "0": "Rock Head"
        },
        "otherFormes": [
            "Steelix [Mega Steelix]"
        ]
    },
    "Steelix [Mega Steelix]": {
        "types": [
            "Steel",
            "Ground"
        ],
        "bs": {
            "hp": 75,
            "at": 125,
            "df": 230,
            "sa": 55,
            "sd": 95,
            "sp": 30
        },
        "weightkg": 740,
        "abilities": {
            "0": "Sand Force"
        },
        "baseSpecies": "Steelix"
    },
    "Steenee": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 52,
            "at": 40,
            "df": 48,
            "sa": 40,
            "sd": 48,
            "sp": 62
        },
        "weightkg": 8.2,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Stonjourner": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 100,
            "at": 125,
            "df": 135,
            "sa": 20,
            "sd": 20,
            "sp": 70
        },
        "weightkg": 520,
        "abilities": {
            "0": "Power Spot"
        }
    },
    "Stoutland": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 85,
            "at": 110,
            "df": 90,
            "sa": 45,
            "sd": 90,
            "sp": 80
        },
        "weightkg": 61,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Stufful": {
        "types": [
            "Normal",
            "Fighting"
        ],
        "bs": {
            "hp": 70,
            "at": 75,
            "df": 50,
            "sa": 45,
            "sd": 50,
            "sp": 50
        },
        "weightkg": 6.8,
        "abilities": {
            "0": "Fluffy"
        }
    },
    "Stunfisk": {
        "types": [
            "Ground",
            "Electric"
        ],
        "bs": {
            "hp": 109,
            "at": 66,
            "df": 84,
            "sa": 81,
            "sd": 99,
            "sp": 32
        },
        "weightkg": 11,
        "abilities": {
            "0": "Static"
        },
        "otherFormes": [
            "Stunfisk [Galarian]"
        ]
    },
    "Stunfisk [Galarian]": {
        "types": [
            "Ground",
            "Steel"
        ],
        "bs": {
            "hp": 109,
            "at": 81,
            "df": 99,
            "sa": 66,
            "sd": 84,
            "sp": 32
        },
        "weightkg": 20.5,
        "abilities": {
            "0": "Mimicry"
        },
        "baseSpecies": "Stunfisk"
    },
    "Stunky": {
        "types": [
            "Poison",
            "Dark"
        ],
        "bs": {
            "hp": 63,
            "at": 63,
            "df": 47,
            "sa": 41,
            "sd": 41,
            "sp": 74
        },
        "weightkg": 19.2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Sudowoodo": {
        "types": [
            "Rock"
        ],
        "bs": {
            "hp": 70,
            "at": 100,
            "df": 115,
            "sa": 30,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 38,
        "abilities": {
            "0": "Sturdy"
        }
    },
    "Suicune": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 75,
            "df": 115,
            "sa": 90,
            "sd": 115,
            "sp": 85
        },
        "weightkg": 187,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Sunflora": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 75,
            "at": 75,
            "df": 55,
            "sa": 105,
            "sd": 85,
            "sp": 30
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Sunkern": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 30,
            "at": 30,
            "df": 30,
            "sa": 30,
            "sd": 30,
            "sp": 30
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Surskit": {
        "types": [
            "Bug",
            "Water"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 32,
            "sa": 50,
            "sd": 52,
            "sp": 65
        },
        "weightkg": 1.7,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Swablu": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 45,
            "at": 40,
            "df": 60,
            "sa": 40,
            "sd": 75,
            "sp": 50
        },
        "weightkg": 1.2,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Swadloon": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 55,
            "at": 63,
            "df": 90,
            "sa": 50,
            "sd": 80,
            "sp": 42
        },
        "weightkg": 7.3,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Swalot": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 100,
            "at": 73,
            "df": 83,
            "sa": 73,
            "sd": 83,
            "sp": 55
        },
        "weightkg": 80,
        "abilities": {
            "0": "Liquid Ooze"
        }
    },
    "Swampert": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 100,
            "at": 110,
            "df": 90,
            "sa": 85,
            "sd": 90,
            "sp": 60
        },
        "weightkg": 81.9,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Swampert [Mega Swampert]"
        ]
    },
    "Swampert [Mega Swampert]": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 100,
            "at": 150,
            "df": 110,
            "sa": 95,
            "sd": 110,
            "sp": 70
        },
        "weightkg": 102,
        "abilities": {
            "0": "Swift Swim"
        },
        "baseSpecies": "Swampert"
    },
    "Swanna": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 75,
            "at": 87,
            "df": 63,
            "sa": 87,
            "sd": 63,
            "sp": 98
        },
        "weightkg": 24.2,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Swellow": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 60,
            "sa": 75,
            "sd": 50,
            "sp": 125
        },
        "weightkg": 19.8,
        "abilities": {
            "0": "Guts"
        }
    },
    "Swinub": {
        "types": [
            "Ice",
            "Ground"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 40,
            "sa": 30,
            "sd": 30,
            "sp": 50
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Swirlix": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 62,
            "at": 48,
            "df": 66,
            "sa": 59,
            "sd": 57,
            "sp": 49
        },
        "weightkg": 3.5,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Swoobat": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 67,
            "at": 57,
            "df": 55,
            "sa": 77,
            "sd": 55,
            "sp": 114
        },
        "weightkg": 10.5,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Sylveon": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 95,
            "at": 65,
            "df": 65,
            "sa": 110,
            "sd": 130,
            "sp": 60
        },
        "weightkg": 23.5,
        "abilities": {
            "0": "Cute Charm"
        }
    },
    "Tadbulb": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 61,
            "at": 31,
            "df": 41,
            "sa": 59,
            "sd": 35,
            "sp": 45
        },
        "weightkg": 0.4,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Taillow": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 30,
            "sa": 30,
            "sd": 30,
            "sp": 85
        },
        "weightkg": 2.3,
        "abilities": {
            "0": "Guts"
        }
    },
    "Talonflame": {
        "types": [
            "Fire",
            "Flying"
        ],
        "bs": {
            "hp": 78,
            "at": 81,
            "df": 71,
            "sa": 74,
            "sd": 69,
            "sp": 126
        },
        "weightkg": 24.5,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Tandemaus": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 45,
            "sa": 40,
            "sd": 45,
            "sp": 75
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Own Tempo"
        }
    },
    "Tangela": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 65,
            "at": 55,
            "df": 115,
            "sa": 100,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 35,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Tangrowth": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 125,
            "sa": 110,
            "sd": 50,
            "sp": 50
        },
        "weightkg": 128.6,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Tapu Bulu": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 130,
            "df": 115,
            "sa": 85,
            "sd": 95,
            "sp": 75
        },
        "weightkg": 45.5,
        "abilities": {
            "0": "Telepathy"
        }
    },
    "Tapu Fini": {
        "types": [
            "Water",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 75,
            "df": 115,
            "sa": 95,
            "sd": 130,
            "sp": 85
        },
        "weightkg": 21.2,
        "abilities": {
            "0": "Telepathy"
        }
    },
    "Tapu Koko": {
        "types": [
            "Electric",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 115,
            "df": 85,
            "sa": 95,
            "sd": 75,
            "sp": 130
        },
        "weightkg": 20.5,
        "abilities": {
            "0": "Telepathy"
        }
    },
    "Tapu Lele": {
        "types": [
            "Psychic",
            "Fairy"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 75,
            "sa": 130,
            "sd": 115,
            "sp": 95
        },
        "weightkg": 18.6,
        "abilities": {
            "0": "Telepathy"
        }
    },
    "Tarountula": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 35,
            "at": 41,
            "df": 45,
            "sa": 29,
            "sd": 40,
            "sp": 20
        },
        "weightkg": 4,
        "abilities": {
            "0": "Insomnia"
        }
    },
    "Tatsugiri": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 50,
            "df": 60,
            "sa": 120,
            "sd": 95,
            "sp": 82
        },
        "weightkg": 8,
        "abilities": {
            "0": "Torrent"
        },
        "otherFormes": [
            "Tatsugiri [Droopy Form]",
            "Tatsugiri [Stretchy Form]",
            "Tatsugiri [Mega Tatsugiri (Curly Form)]",
            "Tatsugiri [Mega Tatsugiri (Droopy Form)]",
            "Tatsugiri [Mega Tatsugiri (Stretchy Form)]"
        ]
    },
    "Tatsugiri [Droopy Form]": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 50,
            "df": 60,
            "sa": 120,
            "sd": 95,
            "sp": 82
        },
        "weightkg": 8,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Tatsugiri"
    },
    "Tatsugiri [Stretchy Form]": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 50,
            "df": 60,
            "sa": 120,
            "sd": 95,
            "sp": 82
        },
        "weightkg": 8,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Tatsugiri"
    },
    "Tatsugiri [Mega Tatsugiri (Curly Form)]": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 65,
            "df": 90,
            "sa": 135,
            "sd": 125,
            "sp": 92
        },
        "weightkg": 24,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Tatsugiri"
    },
    "Tatsugiri [Mega Tatsugiri (Droopy Form)]": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 65,
            "df": 90,
            "sa": 135,
            "sd": 125,
            "sp": 92
        },
        "weightkg": 24,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Tatsugiri"
    },
    "Tatsugiri [Mega Tatsugiri (Stretchy Form)]": {
        "types": [
            "Dragon",
            "Water"
        ],
        "bs": {
            "hp": 68,
            "at": 65,
            "df": 90,
            "sa": 135,
            "sd": 125,
            "sp": 92
        },
        "weightkg": 24,
        "abilities": {
            "0": "Torrent"
        },
        "baseSpecies": "Tatsugiri"
    },
    "Tauros": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 75,
            "at": 100,
            "df": 95,
            "sa": 40,
            "sd": 70,
            "sp": 110
        },
        "weightkg": 88.4,
        "abilities": {
            "0": "Intimidate"
        },
        "otherFormes": [
            "Tauros [Paldean (Combat Breed)]",
            "Tauros [Paldean (Blaze Breed)]",
            "Tauros [Paldean (Aqua Breed)]"
        ]
    },
    "Tauros [Paldean (Combat Breed)]": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 75,
            "at": 110,
            "df": 105,
            "sa": 30,
            "sd": 70,
            "sp": 100
        },
        "weightkg": 115,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Tauros"
    },
    "Tauros [Paldean (Blaze Breed)]": {
        "types": [
            "Fighting",
            "Fire"
        ],
        "bs": {
            "hp": 75,
            "at": 110,
            "df": 105,
            "sa": 30,
            "sd": 70,
            "sp": 100
        },
        "weightkg": 85,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Tauros"
    },
    "Tauros [Paldean (Aqua Breed)]": {
        "types": [
            "Fighting",
            "Water"
        ],
        "bs": {
            "hp": 75,
            "at": 110,
            "df": 105,
            "sa": 30,
            "sd": 70,
            "sp": 100
        },
        "weightkg": 110,
        "abilities": {
            "0": "Intimidate"
        },
        "baseSpecies": "Tauros"
    },
    "Teddiursa": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 80,
            "df": 50,
            "sa": 50,
            "sd": 50,
            "sp": 40
        },
        "weightkg": 8.8,
        "abilities": {
            "0": "Quick Feet"
        }
    },
    "Tentacool": {
        "types": [
            "Water",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 35,
            "sa": 50,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 45.5,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Tentacruel": {
        "types": [
            "Water",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 70,
            "df": 65,
            "sa": 80,
            "sd": 120,
            "sp": 100
        },
        "weightkg": 55,
        "abilities": {
            "0": "Clear Body"
        }
    },
    "Tepig": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 63,
            "df": 45,
            "sa": 45,
            "sd": 45,
            "sp": 45
        },
        "weightkg": 9.9,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Terapagos": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 90,
            "at": 65,
            "df": 85,
            "sa": 65,
            "sd": 85,
            "sp": 60
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Tera Shift"
        },
        "otherFormes": [
            "Terapagos [Terastal Form]",
            "Terapagos [Stellar Form]"
        ]
    },
    "Terapagos [Terastal Form]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 110,
            "sa": 105,
            "sd": 110,
            "sp": 85
        },
        "weightkg": 16,
        "abilities": {
            "0": "Tera Shell"
        },
        "baseSpecies": "Terapagos"
    },
    "Terapagos [Stellar Form]": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 160,
            "at": 105,
            "df": 110,
            "sa": 130,
            "sd": 110,
            "sp": 85
        },
        "weightkg": 77,
        "abilities": {
            "0": "Teraform Zero"
        },
        "baseSpecies": "Terapagos"
    },
    "Terrakion": {
        "types": [
            "Rock",
            "Fighting"
        ],
        "bs": {
            "hp": 91,
            "at": 129,
            "df": 90,
            "sa": 72,
            "sd": 90,
            "sp": 108
        },
        "weightkg": 260,
        "abilities": {
            "0": "Justified"
        }
    },
    "Thievul": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 70,
            "at": 58,
            "df": 58,
            "sa": 87,
            "sd": 92,
            "sp": 90
        },
        "weightkg": 19.9,
        "abilities": {
            "0": "Unburden"
        }
    },
    "Throh": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 120,
            "at": 100,
            "df": 85,
            "sa": 30,
            "sd": 85,
            "sp": 45
        },
        "weightkg": 55.5,
        "abilities": {
            "0": "Guts"
        }
    },
    "Thundurus": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 79,
            "at": 115,
            "df": 70,
            "sa": 125,
            "sd": 80,
            "sp": 111
        },
        "weightkg": 61,
        "abilities": {
            "0": "Prankster"
        },
        "otherFormes": [
            "Thundurus [Therian Forme]"
        ]
    },
    "Thundurus [Therian Forme]": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 79,
            "at": 105,
            "df": 70,
            "sa": 145,
            "sd": 80,
            "sp": 101
        },
        "weightkg": 61,
        "abilities": {
            "0": "Volt Absorb"
        },
        "baseSpecies": "Thundurus"
    },
    "Thwackey": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 70,
            "sa": 55,
            "sd": 60,
            "sp": 80
        },
        "weightkg": 14,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Timburr": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 55,
            "sa": 25,
            "sd": 35,
            "sp": 35
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Guts"
        }
    },
    "Ting-Lu": {
        "types": [
            "Dark",
            "Ground"
        ],
        "bs": {
            "hp": 155,
            "at": 110,
            "df": 125,
            "sa": 55,
            "sd": 80,
            "sp": 45
        },
        "weightkg": 699.7,
        "abilities": {
            "0": "Vessel of Ruin"
        }
    },
    "Tinkatink": {
        "types": [
            "Fairy",
            "Steel"
        ],
        "bs": {
            "hp": 50,
            "at": 45,
            "df": 45,
            "sa": 35,
            "sd": 64,
            "sp": 58
        },
        "weightkg": 8.9,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Tinkaton": {
        "types": [
            "Fairy",
            "Steel"
        ],
        "bs": {
            "hp": 85,
            "at": 75,
            "df": 77,
            "sa": 70,
            "sd": 105,
            "sp": 94
        },
        "weightkg": 112.8,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Tinkatuff": {
        "types": [
            "Fairy",
            "Steel"
        ],
        "bs": {
            "hp": 65,
            "at": 55,
            "df": 55,
            "sa": 45,
            "sd": 82,
            "sp": 78
        },
        "weightkg": 59.1,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Tirtouga": {
        "types": [
            "Water",
            "Rock"
        ],
        "bs": {
            "hp": 54,
            "at": 78,
            "df": 103,
            "sa": 53,
            "sd": 45,
            "sp": 22
        },
        "weightkg": 16.5,
        "abilities": {
            "0": "Solid Rock"
        }
    },
    "Toedscool": {
        "types": [
            "Ground",
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 35,
            "sa": 50,
            "sd": 100,
            "sp": 70
        },
        "weightkg": 33,
        "abilities": {
            "0": "Mycelium Might"
        }
    },
    "Toedscruel": {
        "types": [
            "Ground",
            "Grass"
        ],
        "bs": {
            "hp": 80,
            "at": 70,
            "df": 65,
            "sa": 80,
            "sd": 120,
            "sp": 100
        },
        "weightkg": 58,
        "abilities": {
            "0": "Mycelium Might"
        }
    },
    "Togedemaru": {
        "types": [
            "Electric",
            "Steel"
        ],
        "bs": {
            "hp": 65,
            "at": 98,
            "df": 63,
            "sa": 40,
            "sd": 73,
            "sp": 96
        },
        "weightkg": 3.3,
        "abilities": {
            "0": "Iron Barbs"
        }
    },
    "Togekiss": {
        "types": [
            "Fairy",
            "Flying"
        ],
        "bs": {
            "hp": 85,
            "at": 50,
            "df": 95,
            "sa": 120,
            "sd": 115,
            "sp": 80
        },
        "weightkg": 38,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Togepi": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 35,
            "at": 20,
            "df": 65,
            "sa": 40,
            "sd": 65,
            "sp": 20
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Togetic": {
        "types": [
            "Fairy",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 40,
            "df": 85,
            "sa": 80,
            "sd": 105,
            "sp": 40
        },
        "weightkg": 3.2,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Torchic": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 45,
            "at": 60,
            "df": 40,
            "sa": 70,
            "sd": 50,
            "sp": 45
        },
        "weightkg": 2.5,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Torkoal": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 70,
            "at": 85,
            "df": 140,
            "sa": 85,
            "sd": 70,
            "sp": 20
        },
        "weightkg": 80.4,
        "abilities": {
            "0": "White Smoke"
        }
    },
    "Tornadus": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 79,
            "at": 115,
            "df": 70,
            "sa": 125,
            "sd": 80,
            "sp": 111
        },
        "weightkg": 63,
        "abilities": {
            "0": "Prankster"
        },
        "otherFormes": [
            "Tornadus [Therian Forme]"
        ]
    },
    "Tornadus [Therian Forme]": {
        "types": [
            "Flying"
        ],
        "bs": {
            "hp": 79,
            "at": 100,
            "df": 80,
            "sa": 110,
            "sd": 90,
            "sp": 121
        },
        "weightkg": 63,
        "abilities": {
            "0": "Regenerator"
        },
        "baseSpecies": "Tornadus"
    },
    "Torracat": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 65,
            "at": 85,
            "df": 50,
            "sa": 80,
            "sd": 50,
            "sp": 90
        },
        "weightkg": 25,
        "abilities": {
            "0": "Blaze"
        }
    },
    "Torterra": {
        "types": [
            "Grass",
            "Ground"
        ],
        "bs": {
            "hp": 95,
            "at": 109,
            "df": 105,
            "sa": 75,
            "sd": 85,
            "sp": 56
        },
        "weightkg": 310,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Totodile": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 65,
            "df": 64,
            "sa": 44,
            "sd": 48,
            "sp": 43
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Toucannon": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 120,
            "df": 75,
            "sa": 75,
            "sd": 75,
            "sp": 60
        },
        "weightkg": 26,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Toxapex": {
        "types": [
            "Poison",
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 63,
            "df": 152,
            "sa": 53,
            "sd": 142,
            "sp": 35
        },
        "weightkg": 14.5,
        "abilities": {
            "0": "Merciless"
        }
    },
    "Toxel": {
        "types": [
            "Electric",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 38,
            "df": 35,
            "sa": 54,
            "sd": 35,
            "sp": 40
        },
        "weightkg": 11,
        "abilities": {
            "0": "Static"
        }
    },
    "Toxicroak": {
        "types": [
            "Poison",
            "Fighting"
        ],
        "bs": {
            "hp": 83,
            "at": 106,
            "df": 65,
            "sa": 86,
            "sd": 65,
            "sp": 85
        },
        "weightkg": 44.4,
        "abilities": {
            "0": "Poison Touch"
        }
    },
    "Toxtricity": {
        "types": [
            "Electric",
            "Poison"
        ],
        "bs": {
            "hp": 75,
            "at": 98,
            "df": 70,
            "sa": 114,
            "sd": 70,
            "sp": 75
        },
        "weightkg": 40,
        "abilities": {
            "0": "Punk Rock"
        },
        "otherFormes": [
            "Toxtricity [Low Key Form]"
        ]
    },
    "Toxtricity [Low Key Form]": {
        "types": [
            "Electric",
            "Poison"
        ],
        "bs": {
            "hp": 75,
            "at": 98,
            "df": 70,
            "sa": 114,
            "sd": 70,
            "sp": 75
        },
        "weightkg": 40,
        "abilities": {
            "0": "Punk Rock"
        },
        "baseSpecies": "Toxtricity"
    },
    "Tranquill": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 62,
            "at": 77,
            "df": 62,
            "sa": 50,
            "sd": 42,
            "sp": 65
        },
        "weightkg": 15,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Trapinch": {
        "types": [
            "Ground"
        ],
        "bs": {
            "hp": 45,
            "at": 100,
            "df": 45,
            "sa": 45,
            "sd": 45,
            "sp": 10
        },
        "weightkg": 15,
        "abilities": {
            "0": "Hyper Cutter"
        }
    },
    "Treecko": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 35,
            "sa": 65,
            "sd": 55,
            "sp": 70
        },
        "weightkg": 5,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Trevenant": {
        "types": [
            "Ghost",
            "Grass"
        ],
        "bs": {
            "hp": 85,
            "at": 110,
            "df": 76,
            "sa": 65,
            "sd": 82,
            "sp": 56
        },
        "weightkg": 71,
        "abilities": {
            "0": "Natural Cure"
        }
    },
    "Tropius": {
        "types": [
            "Grass",
            "Flying"
        ],
        "bs": {
            "hp": 99,
            "at": 68,
            "df": 83,
            "sa": 72,
            "sd": 87,
            "sp": 51
        },
        "weightkg": 100,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Trubbish": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 62,
            "sa": 40,
            "sd": 62,
            "sp": 65
        },
        "weightkg": 31,
        "abilities": {
            "0": "Aftermath"
        }
    },
    "Trumbeak": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 55,
            "at": 85,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 75
        },
        "weightkg": 14.8,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Tsareena": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 72,
            "at": 120,
            "df": 98,
            "sa": 50,
            "sd": 98,
            "sp": 72
        },
        "weightkg": 21.4,
        "abilities": {
            "0": "Sweet Veil"
        }
    },
    "Turtonator": {
        "types": [
            "Fire",
            "Dragon"
        ],
        "bs": {
            "hp": 60,
            "at": 78,
            "df": 135,
            "sa": 91,
            "sd": 85,
            "sp": 36
        },
        "weightkg": 212,
        "abilities": {
            "0": "Shell Armor"
        }
    },
    "Turtwig": {
        "types": [
            "Grass"
        ],
        "bs": {
            "hp": 55,
            "at": 68,
            "df": 64,
            "sa": 45,
            "sd": 55,
            "sp": 31
        },
        "weightkg": 10.2,
        "abilities": {
            "0": "Overgrow"
        }
    },
    "Tympole": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 50,
            "at": 50,
            "df": 40,
            "sa": 50,
            "sd": 40,
            "sp": 64
        },
        "weightkg": 4.5,
        "abilities": {
            "0": "Swift Swim"
        }
    },
    "Tynamo": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 35,
            "at": 55,
            "df": 40,
            "sa": 45,
            "sd": 40,
            "sp": 60
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Type: Null": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 95,
            "at": 95,
            "df": 95,
            "sa": 95,
            "sd": 95,
            "sp": 59
        },
        "weightkg": 120.5,
        "abilities": {
            "0": "Battle Armor"
        }
    },
    "Typhlosion": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 78,
            "at": 84,
            "df": 78,
            "sa": 109,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 79.5,
        "abilities": {
            "0": "Blaze"
        },
        "otherFormes": [
            "Typhlosion [Hisuian]"
        ]
    },
    "Typhlosion [Hisuian]": {
        "types": [
            "Fire",
            "Ghost"
        ],
        "bs": {
            "hp": 73,
            "at": 84,
            "df": 78,
            "sa": 119,
            "sd": 85,
            "sp": 95
        },
        "weightkg": 69.7,
        "abilities": {
            "0": "Blaze"
        },
        "baseSpecies": "Typhlosion"
    },
    "Tyranitar": {
        "types": [
            "Rock",
            "Dark"
        ],
        "bs": {
            "hp": 100,
            "at": 134,
            "df": 110,
            "sa": 95,
            "sd": 100,
            "sp": 61
        },
        "weightkg": 202,
        "abilities": {
            "0": "Unnerve"
        },
        "otherFormes": [
            "Tyranitar [Mega Tyranitar]"
        ]
    },
    "Tyranitar [Mega Tyranitar]": {
        "types": [
            "Rock",
            "Dark"
        ],
        "bs": {
            "hp": 100,
            "at": 164,
            "df": 150,
            "sa": 95,
            "sd": 120,
            "sp": 71
        },
        "weightkg": 255,
        "abilities": {
            "0": "Unnerve"
        },
        "baseSpecies": "Tyranitar"
    },
    "Tyrantrum": {
        "types": [
            "Rock",
            "Dragon"
        ],
        "bs": {
            "hp": 82,
            "at": 121,
            "df": 119,
            "sa": 69,
            "sd": 59,
            "sp": 71
        },
        "weightkg": 270,
        "abilities": {
            "0": "Strong Jaw"
        }
    },
    "Tyrogue": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 35,
            "at": 35,
            "df": 35,
            "sa": 35,
            "sd": 35,
            "sp": 35
        },
        "weightkg": 21,
        "abilities": {
            "0": "Guts"
        }
    },
    "Tyrunt": {
        "types": [
            "Rock",
            "Dragon"
        ],
        "bs": {
            "hp": 58,
            "at": 89,
            "df": 77,
            "sa": 45,
            "sd": 45,
            "sp": 48
        },
        "weightkg": 26,
        "abilities": {
            "0": "Strong Jaw"
        }
    },
    "Umbreon": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 95,
            "at": 65,
            "df": 110,
            "sa": 60,
            "sd": 130,
            "sp": 65
        },
        "weightkg": 27,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Unfezant": {
        "types": [
            "Normal",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 115,
            "df": 80,
            "sa": 65,
            "sd": 55,
            "sp": 93
        },
        "weightkg": 29,
        "abilities": {
            "0": "Super Luck"
        }
    },
    "Unown": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Unown [B]",
            "Unown [C]",
            "Unown [D]",
            "Unown [E]",
            "Unown [F]",
            "Unown [G]",
            "Unown [H]",
            "Unown [I]",
            "Unown [J]",
            "Unown [K]",
            "Unown [L]",
            "Unown [M]",
            "Unown [N]",
            "Unown [O]",
            "Unown [P]",
            "Unown [Q]",
            "Unown [R]",
            "Unown [S]",
            "Unown [T]",
            "Unown [U]",
            "Unown [V]",
            "Unown [W]",
            "Unown [X]",
            "Unown [Y]",
            "Unown [Z]",
            "Unown [?]",
            "Unown [!]"
        ]
    },
    "Unown [B]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [C]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [D]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [E]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [F]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [G]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [H]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [I]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [J]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [K]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [L]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [M]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [N]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [O]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [P]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [Q]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [R]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [S]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [T]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [U]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [V]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [W]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [X]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [Y]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [Z]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [?]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Unown [!]": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 48,
            "at": 72,
            "df": 48,
            "sa": 72,
            "sd": 48,
            "sp": 48
        },
        "weightkg": 5,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Unown"
    },
    "Ursaluna": {
        "types": [
            "Ground",
            "Normal"
        ],
        "bs": {
            "hp": 130,
            "at": 140,
            "df": 105,
            "sa": 45,
            "sd": 80,
            "sp": 50
        },
        "weightkg": 290,
        "abilities": {
            "0": "Guts"
        },
        "otherFormes": [
            "Ursaluna [Bloodmoon Ursaluna]"
        ]
    },
    "Ursaluna [Bloodmoon Ursaluna]": {
        "types": [
            "Ground",
            "Normal"
        ],
        "bs": {
            "hp": 113,
            "at": 70,
            "df": 120,
            "sa": 135,
            "sd": 65,
            "sp": 52
        },
        "weightkg": 333,
        "abilities": {
            "0": "Mind's Eye"
        },
        "baseSpecies": "Ursaluna"
    },
    "Ursaring": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 90,
            "at": 130,
            "df": 75,
            "sa": 75,
            "sd": 75,
            "sp": 55
        },
        "weightkg": 125.8,
        "abilities": {
            "0": "Guts"
        }
    },
    "Urshifu": {
        "types": [
            "Fighting",
            "Dark"
        ],
        "bs": {
            "hp": 100,
            "at": 130,
            "df": 100,
            "sa": 63,
            "sd": 60,
            "sp": 97
        },
        "weightkg": 105,
        "abilities": {
            "0": "Unseen Fist"
        },
        "otherFormes": [
            "Urshifu [Rapid Strike Style]"
        ]
    },
    "Urshifu [Rapid Strike Style]": {
        "types": [
            "Fighting",
            "Water"
        ],
        "bs": {
            "hp": 100,
            "at": 130,
            "df": 100,
            "sa": 63,
            "sd": 60,
            "sp": 97
        },
        "weightkg": 105,
        "abilities": {
            "0": "Unseen Fist"
        },
        "baseSpecies": "Urshifu"
    },
    "Uxie": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 75,
            "at": 75,
            "df": 130,
            "sa": 75,
            "sd": 130,
            "sp": 95
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Vanillish": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 51,
            "at": 65,
            "df": 65,
            "sa": 80,
            "sd": 75,
            "sp": 59
        },
        "weightkg": 41,
        "abilities": {
            "0": "Ice Body"
        }
    },
    "Vanillite": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 36,
            "at": 50,
            "df": 50,
            "sa": 65,
            "sd": 60,
            "sp": 44
        },
        "weightkg": 5.7,
        "abilities": {
            "0": "Ice Body"
        }
    },
    "Vanilluxe": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 71,
            "at": 95,
            "df": 85,
            "sa": 110,
            "sd": 95,
            "sp": 79
        },
        "weightkg": 57.5,
        "abilities": {
            "0": "Ice Body"
        }
    },
    "Vaporeon": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 130,
            "at": 65,
            "df": 60,
            "sa": 110,
            "sd": 95,
            "sp": 65
        },
        "weightkg": 29,
        "abilities": {
            "0": "Hydration"
        }
    },
    "Varoom": {
        "types": [
            "Steel",
            "Poison"
        ],
        "bs": {
            "hp": 45,
            "at": 70,
            "df": 63,
            "sa": 30,
            "sd": 45,
            "sp": 47
        },
        "weightkg": 35,
        "abilities": {
            "0": "Overcoat"
        }
    },
    "Veluza": {
        "types": [
            "Water",
            "Psychic"
        ],
        "bs": {
            "hp": 90,
            "at": 102,
            "df": 73,
            "sa": 78,
            "sd": 65,
            "sp": 70
        },
        "weightkg": 90,
        "abilities": {
            "0": "Mold Breaker"
        }
    },
    "Venipede": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 30,
            "at": 45,
            "df": 59,
            "sa": 30,
            "sd": 39,
            "sp": 57
        },
        "weightkg": 5.3,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Venomoth": {
        "types": [
            "Bug",
            "Psychic"
        ],
        "bs": {
            "hp": 70,
            "at": 65,
            "df": 60,
            "sa": 90,
            "sd": 75,
            "sp": 90
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Venonat": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 60,
            "at": 55,
            "df": 50,
            "sa": 40,
            "sd": 55,
            "sp": 45
        },
        "weightkg": 30,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Venusaur": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 82,
            "df": 83,
            "sa": 100,
            "sd": 100,
            "sp": 80
        },
        "weightkg": 100,
        "abilities": {
            "0": "Overgrow"
        },
        "otherFormes": [
            "Venusaur [Mega Venusaur]"
        ]
    },
    "Venusaur [Mega Venusaur]": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 100,
            "df": 123,
            "sa": 122,
            "sd": 120,
            "sp": 80
        },
        "weightkg": 155.5,
        "abilities": {
            "0": "Thick Fat"
        },
        "baseSpecies": "Venusaur"
    },
    "Vespiquen": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 80,
            "df": 102,
            "sa": 80,
            "sd": 102,
            "sp": 40
        },
        "weightkg": 38.5,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Vibrava": {
        "types": [
            "Ground",
            "Dragon"
        ],
        "bs": {
            "hp": 50,
            "at": 70,
            "df": 50,
            "sa": 50,
            "sd": 50,
            "sp": 70
        },
        "weightkg": 15.3,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Victini": {
        "types": [
            "Psychic",
            "Fire"
        ],
        "bs": {
            "hp": 100,
            "at": 100,
            "df": 100,
            "sa": 100,
            "sd": 100,
            "sp": 100
        },
        "weightkg": 4,
        "abilities": {
            "0": "Victory Star"
        }
    },
    "Victreebel": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 105,
            "df": 65,
            "sa": 100,
            "sd": 70,
            "sp": 70
        },
        "weightkg": 15.5,
        "abilities": {
            "0": "Chlorophyll"
        },
        "otherFormes": [
            "Victreebel [Mega Victreebel]"
        ]
    },
    "Victreebel [Mega Victreebel]": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 80,
            "at": 125,
            "df": 85,
            "sa": 135,
            "sd": 95,
            "sp": 70
        },
        "weightkg": 125.5,
        "abilities": {
            "0": "Innards Out"
        },
        "baseSpecies": "Victreebel"
    },
    "Vigoroth": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 80,
            "at": 80,
            "df": 80,
            "sa": 55,
            "sd": 55,
            "sp": 90
        },
        "weightkg": 46.5,
        "abilities": {
            "0": "Vital Spirit"
        }
    },
    "Vikavolt": {
        "types": [
            "Bug",
            "Electric"
        ],
        "bs": {
            "hp": 77,
            "at": 70,
            "df": 90,
            "sa": 145,
            "sd": 75,
            "sp": 43
        },
        "weightkg": 45,
        "abilities": {
            "0": "Levitate"
        }
    },
    "Vileplume": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 75,
            "at": 80,
            "df": 85,
            "sa": 110,
            "sd": 90,
            "sp": 50
        },
        "weightkg": 18.6,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Virizion": {
        "types": [
            "Grass",
            "Fighting"
        ],
        "bs": {
            "hp": 91,
            "at": 90,
            "df": 72,
            "sa": 90,
            "sd": 129,
            "sp": 108
        },
        "weightkg": 200,
        "abilities": {
            "0": "Justified"
        }
    },
    "Vivillon": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "otherFormes": [
            "Vivillon [Continental Pattern]",
            "Vivillon [Elegant Pattern]",
            "Vivillon [Garden Pattern]",
            "Vivillon [High Plains Pattern]",
            "Vivillon [Icy Snow Pattern]",
            "Vivillon [Jungle Pattern]",
            "Vivillon [Marine Pattern]",
            "Vivillon [Meadow Pattern]",
            "Vivillon [Modern Pattern]",
            "Vivillon [Monsoon Pattern]",
            "Vivillon [Ocean Pattern]",
            "Vivillon [Polar Pattern]",
            "Vivillon [River Pattern]",
            "Vivillon [Sandstorm Pattern]",
            "Vivillon [Savanna Pattern]",
            "Vivillon [Sun Pattern]",
            "Vivillon [Tundra Pattern]",
            "Vivillon [Fancy Pattern]",
            "Vivillon [Poké Ball Pattern]"
        ]
    },
    "Vivillon [Continental Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Elegant Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Garden Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [High Plains Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Icy Snow Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Jungle Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Marine Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Meadow Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Modern Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Monsoon Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Ocean Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Polar Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [River Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Sandstorm Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Savanna Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Sun Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Tundra Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Fancy Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Vivillon [Poké Ball Pattern]": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 80,
            "at": 52,
            "df": 50,
            "sa": 90,
            "sd": 50,
            "sp": 89
        },
        "weightkg": 17,
        "abilities": {
            "0": "Shield Dust"
        },
        "baseSpecies": "Vivillon"
    },
    "Volbeat": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 65,
            "at": 73,
            "df": 75,
            "sa": 47,
            "sd": 85,
            "sp": 85
        },
        "weightkg": 17.7,
        "abilities": {
            "0": "Swarm"
        }
    },
    "Volcanion": {
        "types": [
            "Fire",
            "Water"
        ],
        "bs": {
            "hp": 80,
            "at": 110,
            "df": 120,
            "sa": 130,
            "sd": 90,
            "sp": 70
        },
        "weightkg": 195,
        "abilities": {
            "0": "Pressure"
        }
    },
    "Volcarona": {
        "types": [
            "Bug",
            "Fire"
        ],
        "bs": {
            "hp": 85,
            "at": 60,
            "df": 65,
            "sa": 135,
            "sd": 105,
            "sp": 100
        },
        "weightkg": 46,
        "abilities": {
            "0": "Flame Body"
        }
    },
    "Voltorb": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 50,
            "sa": 55,
            "sd": 55,
            "sp": 100
        },
        "weightkg": 10.4,
        "abilities": {
            "0": "Aftermath"
        },
        "otherFormes": [
            "Voltorb [Hisuian]"
        ]
    },
    "Voltorb [Hisuian]": {
        "types": [
            "Electric",
            "Grass"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 50,
            "sa": 55,
            "sd": 55,
            "sp": 100
        },
        "weightkg": 13,
        "abilities": {
            "0": "Aftermath"
        },
        "baseSpecies": "Voltorb"
    },
    "Vullaby": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 70,
            "at": 55,
            "df": 75,
            "sa": 45,
            "sd": 65,
            "sp": 60
        },
        "weightkg": 9,
        "abilities": {
            "0": "Big Pecks"
        }
    },
    "Vulpix": {
        "types": [
            "Fire"
        ],
        "bs": {
            "hp": 38,
            "at": 41,
            "df": 40,
            "sa": 50,
            "sd": 65,
            "sp": 65
        },
        "weightkg": 9.9,
        "abilities": {
            "0": "Magic Guard"
        },
        "otherFormes": [
            "Vulpix [Alolan]"
        ]
    },
    "Vulpix [Alolan]": {
        "types": [
            "Ice"
        ],
        "bs": {
            "hp": 38,
            "at": 41,
            "df": 40,
            "sa": 50,
            "sd": 65,
            "sp": 65
        },
        "weightkg": 9.9,
        "abilities": {
            "0": "Snow Cloak"
        },
        "baseSpecies": "Vulpix"
    },
    "Wailmer": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 130,
            "at": 70,
            "df": 35,
            "sa": 70,
            "sd": 35,
            "sp": 60
        },
        "weightkg": 130,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Wailord": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 170,
            "at": 90,
            "df": 45,
            "sa": 90,
            "sd": 45,
            "sp": 60
        },
        "weightkg": 398,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Walking Wake": {
        "types": [
            "Water",
            "Dragon"
        ],
        "bs": {
            "hp": 99,
            "at": 83,
            "df": 91,
            "sa": 125,
            "sd": 83,
            "sp": 109
        },
        "weightkg": 280,
        "abilities": {
            "0": "Protosynthesis"
        }
    },
    "Walrein": {
        "types": [
            "Ice",
            "Water"
        ],
        "bs": {
            "hp": 110,
            "at": 80,
            "df": 90,
            "sa": 95,
            "sd": 90,
            "sp": 65
        },
        "weightkg": 150.6,
        "abilities": {
            "0": "Thick Fat"
        }
    },
    "Wartortle": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 59,
            "at": 63,
            "df": 80,
            "sa": 65,
            "sd": 80,
            "sp": 58
        },
        "weightkg": 22.5,
        "abilities": {
            "0": "Torrent"
        }
    },
    "Watchog": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 60,
            "at": 85,
            "df": 69,
            "sa": 60,
            "sd": 69,
            "sp": 77
        },
        "weightkg": 27,
        "abilities": {
            "0": "No Guard"
        }
    },
    "Wattrel": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 40,
            "df": 35,
            "sa": 55,
            "sd": 40,
            "sp": 70
        },
        "weightkg": 3.6,
        "abilities": {
            "0": "Wind Power"
        }
    },
    "Weavile": {
        "types": [
            "Dark",
            "Ice"
        ],
        "bs": {
            "hp": 70,
            "at": 120,
            "df": 65,
            "sa": 45,
            "sd": 85,
            "sp": 125
        },
        "weightkg": 34,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Weedle": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 35,
            "df": 30,
            "sa": 20,
            "sd": 20,
            "sp": 50
        },
        "weightkg": 3.2,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Weepinbell": {
        "types": [
            "Grass",
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 50,
            "sa": 85,
            "sd": 45,
            "sp": 55
        },
        "weightkg": 6.4,
        "abilities": {
            "0": "Chlorophyll"
        }
    },
    "Weezing": {
        "types": [
            "Poison"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 120,
            "sa": 85,
            "sd": 70,
            "sp": 60
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Levitate"
        },
        "otherFormes": [
            "Weezing [Galarian]"
        ]
    },
    "Weezing [Galarian]": {
        "types": [
            "Poison",
            "Fairy"
        ],
        "bs": {
            "hp": 65,
            "at": 90,
            "df": 120,
            "sa": 85,
            "sd": 70,
            "sp": 60
        },
        "weightkg": 16,
        "abilities": {
            "0": "Levitate"
        },
        "baseSpecies": "Weezing"
    },
    "Whimsicott": {
        "types": [
            "Grass",
            "Fairy"
        ],
        "bs": {
            "hp": 60,
            "at": 67,
            "df": 85,
            "sa": 77,
            "sd": 75,
            "sp": 116
        },
        "weightkg": 6.6,
        "abilities": {
            "0": "Prankster"
        }
    },
    "Whirlipede": {
        "types": [
            "Bug",
            "Poison"
        ],
        "bs": {
            "hp": 40,
            "at": 55,
            "df": 99,
            "sa": 40,
            "sd": 79,
            "sp": 47
        },
        "weightkg": 58.5,
        "abilities": {
            "0": "Poison Point"
        }
    },
    "Whiscash": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 110,
            "at": 78,
            "df": 73,
            "sa": 76,
            "sd": 71,
            "sp": 60
        },
        "weightkg": 23.6,
        "abilities": {
            "0": "Oblivious"
        }
    },
    "Whismur": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 64,
            "at": 51,
            "df": 23,
            "sa": 51,
            "sd": 23,
            "sp": 28
        },
        "weightkg": 16.3,
        "abilities": {
            "0": "Soundproof"
        }
    },
    "Wigglytuff": {
        "types": [
            "Normal",
            "Fairy"
        ],
        "bs": {
            "hp": 140,
            "at": 70,
            "df": 45,
            "sa": 85,
            "sd": 50,
            "sp": 45
        },
        "weightkg": 12,
        "abilities": {
            "0": "Sheer Force"
        }
    },
    "Wiglett": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 10,
            "at": 55,
            "df": 25,
            "sa": 35,
            "sd": 25,
            "sp": 95
        },
        "weightkg": 1.8,
        "abilities": {
            "0": "Rattled"
        }
    },
    "Wimpod": {
        "types": [
            "Bug",
            "Water"
        ],
        "bs": {
            "hp": 25,
            "at": 35,
            "df": 40,
            "sa": 20,
            "sd": 30,
            "sp": 80
        },
        "weightkg": 12,
        "abilities": {
            "0": "Wimp Out"
        }
    },
    "Wingull": {
        "types": [
            "Water",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 30,
            "df": 30,
            "sa": 55,
            "sd": 30,
            "sp": 85
        },
        "weightkg": 9.5,
        "abilities": {
            "0": "Keen Eye"
        }
    },
    "Wishiwashi": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 45,
            "at": 20,
            "df": 20,
            "sa": 25,
            "sd": 25,
            "sp": 40
        },
        "weightkg": 0.3,
        "abilities": {
            "0": "Schooling"
        },
        "otherFormes": [
            "Wishiwashi [School Form]"
        ]
    },
    "Wishiwashi [School Form]": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 45,
            "at": 140,
            "df": 130,
            "sa": 140,
            "sd": 135,
            "sp": 30
        },
        "weightkg": 78.6,
        "abilities": {
            "0": "Schooling"
        },
        "baseSpecies": "Wishiwashi"
    },
    "Wobbuffet": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 190,
            "at": 33,
            "df": 58,
            "sa": 33,
            "sd": 58,
            "sp": 33
        },
        "weightkg": 28.5,
        "abilities": {
            "0": "Shadow Tag"
        }
    },
    "Wo-Chien": {
        "types": [
            "Dark",
            "Grass"
        ],
        "bs": {
            "hp": 85,
            "at": 85,
            "df": 100,
            "sa": 95,
            "sd": 135,
            "sp": 70
        },
        "weightkg": 74.2,
        "abilities": {
            "0": "Tablets of Ruin"
        }
    },
    "Woobat": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 45,
            "df": 43,
            "sa": 55,
            "sd": 43,
            "sp": 72
        },
        "weightkg": 2.1,
        "abilities": {
            "0": "Unaware"
        }
    },
    "Wooloo": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 42,
            "at": 40,
            "df": 55,
            "sa": 40,
            "sd": 45,
            "sp": 48
        },
        "weightkg": 6,
        "abilities": {
            "0": "Fluffy"
        }
    },
    "Wooper": {
        "types": [
            "Water",
            "Ground"
        ],
        "bs": {
            "hp": 55,
            "at": 45,
            "df": 45,
            "sa": 25,
            "sd": 25,
            "sp": 15
        },
        "weightkg": 8.5,
        "abilities": {
            "0": "Unaware"
        },
        "otherFormes": [
            "Wooper [Paldean]"
        ]
    },
    "Wooper [Paldean]": {
        "types": [
            "Poison",
            "Ground"
        ],
        "bs": {
            "hp": 55,
            "at": 45,
            "df": 45,
            "sa": 25,
            "sd": 25,
            "sp": 15
        },
        "weightkg": 11,
        "abilities": {
            "0": "Poison Point"
        },
        "baseSpecies": "Wooper"
    },
    "Wormadam": {
        "types": [
            "Bug",
            "Grass"
        ],
        "bs": {
            "hp": 60,
            "at": 59,
            "df": 85,
            "sa": 79,
            "sd": 105,
            "sp": 36
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Anticipation"
        },
        "otherFormes": [
            "Wormadam [Sandy Cloak]",
            "Wormadam [Trash Cloak]"
        ]
    },
    "Wormadam [Sandy Cloak]": {
        "types": [
            "Bug",
            "Ground"
        ],
        "bs": {
            "hp": 60,
            "at": 79,
            "df": 105,
            "sa": 59,
            "sd": 85,
            "sp": 36
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Anticipation"
        },
        "baseSpecies": "Wormadam"
    },
    "Wormadam [Trash Cloak]": {
        "types": [
            "Bug",
            "Steel"
        ],
        "bs": {
            "hp": 60,
            "at": 69,
            "df": 95,
            "sa": 69,
            "sd": 95,
            "sp": 36
        },
        "weightkg": 6.5,
        "abilities": {
            "0": "Anticipation"
        },
        "baseSpecies": "Wormadam"
    },
    "Wugtrio": {
        "types": [
            "Water"
        ],
        "bs": {
            "hp": 35,
            "at": 100,
            "df": 50,
            "sa": 50,
            "sd": 70,
            "sp": 120
        },
        "weightkg": 5.4,
        "abilities": {
            "0": "Rattled"
        }
    },
    "Wurmple": {
        "types": [
            "Bug"
        ],
        "bs": {
            "hp": 45,
            "at": 45,
            "df": 35,
            "sa": 20,
            "sd": 30,
            "sp": 20
        },
        "weightkg": 3.6,
        "abilities": {
            "0": "Shield Dust"
        }
    },
    "Wynaut": {
        "types": [
            "Psychic"
        ],
        "bs": {
            "hp": 95,
            "at": 23,
            "df": 48,
            "sa": 23,
            "sd": 48,
            "sp": 23
        },
        "weightkg": 14,
        "abilities": {
            "0": "Shadow Tag"
        }
    },
    "Wyrdeer": {
        "types": [
            "Normal",
            "Psychic"
        ],
        "bs": {
            "hp": 103,
            "at": 105,
            "df": 72,
            "sa": 105,
            "sd": 75,
            "sp": 65
        },
        "weightkg": 95.1,
        "abilities": {
            "0": "Intimidate"
        }
    },
    "Xatu": {
        "types": [
            "Psychic",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 75,
            "df": 70,
            "sa": 95,
            "sd": 70,
            "sp": 95
        },
        "weightkg": 15,
        "abilities": {
            "0": "Synchronize"
        }
    },
    "Xerneas": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 126,
            "at": 131,
            "df": 95,
            "sa": 131,
            "sd": 98,
            "sp": 99
        },
        "weightkg": 215,
        "abilities": {
            "0": "Fairy Aura"
        },
        "otherFormes": [
            "Xerneas [Active Mode]"
        ]
    },
    "Xerneas [Active Mode]": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 126,
            "at": 131,
            "df": 95,
            "sa": 131,
            "sd": 98,
            "sp": 99
        },
        "weightkg": 215,
        "abilities": {
            "0": "Fairy Aura"
        },
        "baseSpecies": "Xerneas"
    },
    "Xurkitree": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 83,
            "at": 89,
            "df": 71,
            "sa": 173,
            "sd": 71,
            "sp": 83
        },
        "weightkg": 100,
        "abilities": {
            "0": "Beast Boost"
        }
    },
    "Yamask": {
        "types": [
            "Ghost"
        ],
        "bs": {
            "hp": 38,
            "at": 30,
            "df": 85,
            "sa": 55,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Mummy"
        },
        "otherFormes": [
            "Yamask [Galarian]"
        ]
    },
    "Yamask [Galarian]": {
        "types": [
            "Ground",
            "Ghost"
        ],
        "bs": {
            "hp": 38,
            "at": 55,
            "df": 85,
            "sa": 30,
            "sd": 65,
            "sp": 30
        },
        "weightkg": 1.5,
        "abilities": {
            "0": "Wandering Spirit"
        },
        "baseSpecies": "Yamask"
    },
    "Yamper": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 59,
            "at": 45,
            "df": 50,
            "sa": 40,
            "sd": 50,
            "sp": 26
        },
        "weightkg": 13.5,
        "abilities": {
            "0": "Ball Fetch"
        }
    },
    "Yanma": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 65,
            "at": 65,
            "df": 45,
            "sa": 75,
            "sd": 45,
            "sp": 95
        },
        "weightkg": 38,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Yanmega": {
        "types": [
            "Bug",
            "Flying"
        ],
        "bs": {
            "hp": 86,
            "at": 76,
            "df": 86,
            "sa": 116,
            "sd": 56,
            "sp": 95
        },
        "weightkg": 51.5,
        "abilities": {
            "0": "Compound Eyes"
        }
    },
    "Yungoos": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 48,
            "at": 70,
            "df": 30,
            "sa": 30,
            "sd": 30,
            "sp": 45
        },
        "weightkg": 6,
        "abilities": {
            "0": "Stakeout"
        }
    },
    "Yveltal": {
        "types": [
            "Dark",
            "Flying"
        ],
        "bs": {
            "hp": 126,
            "at": 131,
            "df": 95,
            "sa": 131,
            "sd": 98,
            "sp": 99
        },
        "weightkg": 203,
        "abilities": {
            "0": "Dark Aura"
        }
    },
    "Zacian": {
        "types": [
            "Fairy"
        ],
        "bs": {
            "hp": 92,
            "at": 130,
            "df": 115,
            "sa": 80,
            "sd": 115,
            "sp": 138
        },
        "weightkg": 110,
        "abilities": {
            "0": "Intrepid Sword"
        },
        "otherFormes": [
            "Zacian [Crowned Sword]"
        ]
    },
    "Zacian [Crowned Sword]": {
        "types": [
            "Fairy",
            "Steel"
        ],
        "bs": {
            "hp": 92,
            "at": 170,
            "df": 115,
            "sa": 80,
            "sd": 115,
            "sp": 148
        },
        "weightkg": 355,
        "abilities": {
            "0": "Intrepid Sword"
        },
        "baseSpecies": "Zacian"
    },
    "Zamazenta": {
        "types": [
            "Fighting"
        ],
        "bs": {
            "hp": 92,
            "at": 130,
            "df": 115,
            "sa": 80,
            "sd": 115,
            "sp": 138
        },
        "weightkg": 210,
        "abilities": {
            "0": "Dauntless Shield"
        },
        "otherFormes": [
            "Zamazenta [Crowned Shield]"
        ]
    },
    "Zamazenta [Crowned Shield]": {
        "types": [
            "Fighting",
            "Steel"
        ],
        "bs": {
            "hp": 92,
            "at": 130,
            "df": 145,
            "sa": 80,
            "sd": 145,
            "sp": 128
        },
        "weightkg": 785,
        "abilities": {
            "0": "Dauntless Shield"
        },
        "baseSpecies": "Zamazenta"
    },
    "Zangoose": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 73,
            "at": 115,
            "df": 60,
            "sa": 60,
            "sd": 60,
            "sp": 90
        },
        "weightkg": 40.3,
        "abilities": {
            "0": "Immunity"
        }
    },
    "Zapdos": {
        "types": [
            "Electric",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 90,
            "df": 85,
            "sa": 125,
            "sd": 90,
            "sp": 100
        },
        "weightkg": 52.6,
        "abilities": {
            "0": "Pressure"
        },
        "otherFormes": [
            "Zapdos [Galarian]"
        ]
    },
    "Zapdos [Galarian]": {
        "types": [
            "Fighting",
            "Flying"
        ],
        "bs": {
            "hp": 90,
            "at": 125,
            "df": 90,
            "sa": 85,
            "sd": 90,
            "sp": 100
        },
        "weightkg": 58.2,
        "abilities": {
            "0": "Defiant"
        },
        "baseSpecies": "Zapdos"
    },
    "Zarude": {
        "types": [
            "Dark",
            "Grass"
        ],
        "bs": {
            "hp": 105,
            "at": 120,
            "df": 105,
            "sa": 70,
            "sd": 95,
            "sp": 105
        },
        "weightkg": 70,
        "abilities": {
            "0": "Leaf Guard"
        }
    },
    "Zebstrika": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 75,
            "at": 100,
            "df": 63,
            "sa": 80,
            "sd": 63,
            "sp": 116
        },
        "weightkg": 79.5,
        "abilities": {
            "0": "Heatproof"
        }
    },
    "Zekrom": {
        "types": [
            "Dragon",
            "Electric"
        ],
        "bs": {
            "hp": 100,
            "at": 150,
            "df": 120,
            "sa": 120,
            "sd": 100,
            "sp": 90
        },
        "weightkg": 345,
        "abilities": {
            "0": "Teravolt"
        }
    },
    "Zeraora": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 88,
            "at": 112,
            "df": 75,
            "sa": 102,
            "sd": 80,
            "sp": 143
        },
        "weightkg": 44.5,
        "abilities": {
            "0": "Volt Absorb"
        },
        "otherFormes": [
            "Zeraora [Mega Zeraora]"
        ]
    },
    "Zeraora [Mega Zeraora]": {
        "types": [
            "Electric"
        ],
        "bs": {
            "hp": 88,
            "at": 157,
            "df": 75,
            "sa": 147,
            "sd": 80,
            "sp": 153
        },
        "weightkg": 44.5,
        "abilities": {
            "0": "Volt Absorb"
        },
        "baseSpecies": "Zeraora"
    },
    "Zigzagoon": {
        "types": [
            "Normal"
        ],
        "bs": {
            "hp": 38,
            "at": 30,
            "df": 41,
            "sa": 30,
            "sd": 41,
            "sp": 60
        },
        "weightkg": 17.5,
        "abilities": {
            "0": "Gluttony"
        },
        "otherFormes": [
            "Zigzagoon [Galarian]"
        ]
    },
    "Zigzagoon [Galarian]": {
        "types": [
            "Dark",
            "Normal"
        ],
        "bs": {
            "hp": 38,
            "at": 30,
            "df": 41,
            "sa": 30,
            "sd": 41,
            "sp": 60
        },
        "weightkg": 17.5,
        "abilities": {
            "0": "Quick Feet"
        },
        "baseSpecies": "Zigzagoon"
    },
    "Zoroark": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 60,
            "at": 105,
            "df": 60,
            "sa": 120,
            "sd": 60,
            "sp": 105
        },
        "weightkg": 81.1,
        "abilities": {
            "0": "Illusion"
        },
        "otherFormes": [
            "Zoroark [Hisuian]"
        ]
    },
    "Zoroark [Hisuian]": {
        "types": [
            "Normal",
            "Ghost"
        ],
        "bs": {
            "hp": 55,
            "at": 100,
            "df": 60,
            "sa": 125,
            "sd": 60,
            "sp": 110
        },
        "weightkg": 73,
        "abilities": {
            "0": "Illusion"
        },
        "baseSpecies": "Zoroark"
    },
    "Zorua": {
        "types": [
            "Dark"
        ],
        "bs": {
            "hp": 40,
            "at": 65,
            "df": 40,
            "sa": 80,
            "sd": 40,
            "sp": 65
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Illusion"
        },
        "otherFormes": [
            "Zorua [Hisuian]"
        ]
    },
    "Zorua [Hisuian]": {
        "types": [
            "Normal",
            "Ghost"
        ],
        "bs": {
            "hp": 35,
            "at": 60,
            "df": 40,
            "sa": 85,
            "sd": 40,
            "sp": 70
        },
        "weightkg": 12.5,
        "abilities": {
            "0": "Illusion"
        },
        "baseSpecies": "Zorua"
    },
    "Zubat": {
        "types": [
            "Poison",
            "Flying"
        ],
        "bs": {
            "hp": 40,
            "at": 45,
            "df": 35,
            "sa": 30,
            "sd": 40,
            "sp": 55
        },
        "weightkg": 7.5,
        "abilities": {
            "0": "Inner Focus"
        }
    },
    "Zweilous": {
        "types": [
            "Dark",
            "Dragon"
        ],
        "bs": {
            "hp": 72,
            "at": 85,
            "df": 70,
            "sa": 65,
            "sd": 70,
            "sp": 58
        },
        "weightkg": 50,
        "abilities": {
            "0": "Hustle"
        }
    },
    "Zygarde": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 108,
            "at": 100,
            "df": 121,
            "sa": 81,
            "sd": 95,
            "sp": 95
        },
        "weightkg": 305,
        "abilities": {
            "0": "Aura Break"
        },
        "otherFormes": [
            "Zygarde [10% Forme]",
            "Zygarde [Complete Forme]",
            "Zygarde [Form 3]",
            "Zygarde [Mega Zygarde]",
            "Zygarde [Form 5]"
        ]
    },
    "Zygarde [10% Forme]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 54,
            "at": 100,
            "df": 71,
            "sa": 61,
            "sd": 85,
            "sp": 115
        },
        "weightkg": 33.5,
        "abilities": {
            "0": "Aura Break"
        },
        "baseSpecies": "Zygarde"
    },
    "Zygarde [Complete Forme]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 216,
            "at": 100,
            "df": 121,
            "sa": 91,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 610,
        "abilities": {
            "0": "Power Construct"
        },
        "baseSpecies": "Zygarde"
    },
    "Zygarde [Form 3]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 216,
            "at": 100,
            "df": 121,
            "sa": 91,
            "sd": 95,
            "sp": 85
        },
        "weightkg": 610,
        "abilities": {
            "0": "Power Construct"
        },
        "baseSpecies": "Zygarde"
    },
    "Zygarde [Mega Zygarde]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 216,
            "at": 70,
            "df": 91,
            "sa": 216,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 610,
        "abilities": {
            "0": "Power Construct"
        },
        "baseSpecies": "Zygarde"
    },
    "Zygarde [Form 5]": {
        "types": [
            "Dragon",
            "Ground"
        ],
        "bs": {
            "hp": 216,
            "at": 70,
            "df": 91,
            "sa": 216,
            "sd": 85,
            "sp": 100
        },
        "weightkg": 610,
        "abilities": {
            "0": "Power Construct"
        },
        "baseSpecies": "Zygarde"
    }
};
//# sourceMappingURL=utopia_species.js.map