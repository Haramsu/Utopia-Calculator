import { SpeciesData } from "./species";
export declare const UTOPIA_SPECIES: {
    [name: string]: SpeciesData;
};
