import type { MoveData } from './moves';
export declare const UTOPIA_MOVES: {
    [name: string]: MoveData;
};
